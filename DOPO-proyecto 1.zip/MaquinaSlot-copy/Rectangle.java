import java.awt.*;

/**
 * Un rectangulo que se puede manipular y que se dibuja en un lienzo.
 * 
 * @author  Michael Kolling and David J. Barnes (Modified)
 * @version 1.0  (15 July 2000)()
 */


 
public class Rectangle{

    public static int EDGES = 4;
    
    private int height;
    private int width;
    private int xPosition;
    private int yPosition;
    private String color;
    private boolean isVisible;

    /**
     * Crea un rectangulo en la posicion y con el color predeterminados.
     */
    public Rectangle(){
        height = 30;
        width = 40;
        xPosition = 70;
        yPosition = 15;
        color = "magenta";
        isVisible = false;
    }
    

    /**
     * Hace visible este rectangulo. Si ya era visible, no hace nada.
     */
    public void makeVisible(){
        isVisible = true;
        draw();
    }
    
    /**
     * Hace invisible este rectangulo. Si ya era invisible, no hace nada.
     */
    public void makeInvisible(){
        erase();
        isVisible = false;
    }
    
    /**
     * Mueve el rectangulo algunos pixeles a la derecha.
     */
    public void moveRight(){
        moveHorizontal(20);
    }

    /**
     * Mueve el rectangulo algunos pixeles a la izquierda.
     */
    public void moveLeft(){
        moveHorizontal(-20);
    }

    /**
     * Mueve el rectangulo algunos pixeles hacia arriba.
     */
    public void moveUp(){
        moveVertical(-20);
    }

    /**
     * Mueve el rectangulo algunos pixeles hacia abajo.
     */
    public void moveDown(){
        moveVertical(20);
    }

    /**
     * Mueve el rectangulo horizontalmente.
     * @param distance la distancia deseada en pixeles
     */
    public void moveHorizontal(int distance){
        erase();
        xPosition += distance;
        draw();
    }

    /**
     * Mueve el rectangulo verticalmente.
     * @param distance la distancia deseada en pixeles
     */
    public void moveVertical(int distance){
        erase();
        yPosition += distance;
        draw();
    }

    /**
     * Mueve lentamente el rectangulo horizontalmente.
     * @param distance la distancia deseada en pixeles
     */
    public void slowMoveHorizontal(int distance){
        int delta;

        if(distance < 0) {
            delta = -1;
            distance = -distance;
        } else {
            delta = 1;
        }

        for(int i = 0; i < distance; i++){
            xPosition += delta;
            draw();
        }
    }

    /**
     * Mueve lentamente el rectangulo verticalmente.
     * @param distance la distancia deseada en pixeles
     */
    public void slowMoveVertical(int distance){
        int delta;

        if(distance < 0) {
            delta = -1;
            distance = -distance;
        } else {
            delta = 1;
        }

        for(int i = 0; i < distance; i++){
            yPosition += delta;
            draw();
        }
    }

    /**
     * Cambia el tamano al nuevo valor
     * @param newHeight la nueva altura en pixeles. Debe ser >=0.
     * @param newWidht el nuevo ancho en pixeles. Debe ser >=0.
     */
    public void changeSize(int newHeight, int newWidth) {
        erase();
        height = newHeight;
        width = newWidth;
        draw();
    }
    
    /**
     * Cambia el color. 
     * @param color el nuevo color. Los colores validos son "red", "yellow", "blue", "green",
     * "magenta" and "black".
     */
    public void changeColor(String newColor){
        color = newColor;
        draw();
    }

    /*
     * Dibuja el rectangulo con las especificaciones actuales en pantalla.
     */

    private void draw() {
        if(isVisible) {
            Canvas canvas = Canvas.getCanvas();
            canvas.draw(this, color,
                new java.awt.Rectangle(xPosition, yPosition, 
                                       width, height));
            canvas.wait(10);
        }
    }

    /*
     * Borra el rectangulo de la pantalla.
     */
    private void erase(){
        if(isVisible) {
            Canvas canvas = Canvas.getCanvas();
            canvas.erase(this);
        }
    }
}


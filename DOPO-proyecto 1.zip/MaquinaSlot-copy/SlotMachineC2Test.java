import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * Pruebas de unidad del ciclo 2: swap, lock, unlock, spin(wheel, steps) y
 * spin(setSymbols).
 *
 * Todas las pruebas se ejecutan con la maquina INVISIBLE (nunca se llama a
 * makeVisible), asi no aparecen ventanas ni mensajes.
 *
 * Cada prueba responde a una de dos preguntas:
 * "should"    = que deberia hacer
 * "shouldNot" = que no deberia hacer
 *
 * IMPORTANTE: cambie XxYy por las iniciales de los primeros apellidos de los
 * autores (mas la primera letra del segundo apellido), en orden alfabetico.
 *
 * @author (nombres de los autores)
 * @version (fecha)
 */
public class SlotMachineC2Test
{
    private SlotMachine machine;

    /**
     * Prepara una maquina de 3 ruedas con 3 simbolos cada una:
     * rueda 1: red, green, blue      (muestra red)
     * rueda 2: green, blue, red      (muestra green)
     * rueda 3: blue, red, green      (muestra blue)
     */
    @Before
    public void setUp()
    {
        machine = new SlotMachine();
        machine.addWheel(1);
        machine.addWheel(2);
        machine.addWheel(3);
        String[][] symbols = {{"red", "green", "blue"},
                              {"green", "blue", "red"},
                              {"blue", "red", "green"}};
        for(int wheel = 0; wheel < symbols.length; wheel++)
        {
            for(String color : symbols[wheel])
            {
                machine.addSymbol(wheel + 1, color);
            }
        }
    }

    @After
    public void tearDown()
    {
        machine = null;
    }

    // ---------------------------------------------------------- swap

    @Test
    public void accordingGarzonVargasShouldSwapTwoWheels()
    {
        machine.swap(1, 3);
        assertTrue(machine.ok());
        assertArrayEquals(new String[]{"blue", "green", "red"}, machine.configuration());
    }

    @Test
    public void accordingGarzonVargasShouldClampPositionsWhenSwapping()
    {
        machine.swap(-4, 99);   // se ajustan a 1 y 3
        assertTrue(machine.ok());
        assertArrayEquals(new String[]{"blue", "green", "red"}, machine.configuration());
    }

    @Test
    public void accordingGarzonVargasShouldNotChangeAnythingWhenSwappingWheelWithItself()
    {
        machine.swap(2, 2);
        assertTrue(machine.ok());
        assertArrayEquals(new String[]{"red", "green", "blue"}, machine.configuration());
    }

    @Test
    public void accordingGarzonVargasShouldNotSwapWhenThereAreNoWheels()
    {
        SlotMachine empty = new SlotMachine();
        empty.swap(1, 2);
        assertFalse(empty.ok());
    }

    @Test
    public void accordingGarzonVargasShouldKeepLockedStateWhenSwapping()
    {
        machine.lock(1);
        machine.swap(1, 2);          // la rueda fija queda ahora en la posicion 2
        machine.spin();              // giran las ruedas 1 y 3; la fija (posicion 2) no
        assertArrayEquals(new String[]{"blue", "red", "red"}, machine.configuration());
    }

    // ---------------------------------------------------------- lock / unlock

    @Test
    public void accordingGarzonVargasShouldNotSpinLockedWheelWhenSpinningAll()
    {
        machine.lock(2);
        machine.spin();
        assertTrue(machine.ok());
        assertArrayEquals(new String[]{"green", "green", "red"}, machine.configuration());
    }

    @Test
    public void accordingGarzonVargasShouldNotSpinLockedWheel()
    {
        machine.lock(1);
        machine.spin(1);
        assertFalse(machine.ok());
        assertArrayEquals(new String[]{"red", "green", "blue"}, machine.configuration());
    }

    @Test
    public void accordingGarzonVargasShouldNotPlaceSymbolInLockedWheel()
    {
        machine.lock(1);
        machine.placeSymbol(1, "blue");
        assertFalse(machine.ok());
        assertEquals("red", machine.configuration()[0]);
    }

    @Test
    public void accordingGarzonVargasShouldSpinWheelAgainAfterUnlock()
    {
        machine.lock(1);
        machine.unlock(1);
        assertTrue(machine.ok());
        machine.spin(1);
        assertTrue(machine.ok());
        assertEquals("green", machine.configuration()[0]);
    }

    @Test
    public void accordingGarzonVargasShouldNotLockAWheelThatIsAlreadyLocked()
    {
        machine.lock(1);
        machine.lock(1);
        assertFalse(machine.ok());
    }

    @Test
    public void accordingGarzonVargasShouldNotUnlockAWheelThatIsNotLocked()
    {
        machine.unlock(1);
        assertFalse(machine.ok());
    }

    @Test
    public void accordingGarzonVargasShouldNotLockWhenThereAreNoWheels()
    {
        SlotMachine empty = new SlotMachine();
        empty.lock(1);
        assertFalse(empty.ok());
    }

    // ---------------------------------------------------------- spin(wheel, steps)

    @Test
    public void accordingGarzonVargasShouldRotateWheelSeveralSteps()
    {
        machine.spin(1, 2);          // red -> green -> blue
        assertTrue(machine.ok());
        assertEquals("blue", machine.configuration()[0]);
    }

    @Test
    public void accordingGarzonVargasShouldWrapAroundWhenStepsExceedSymbols()
    {
        machine.spin(1, 4);          // una vuelta completa (3) mas un paso
        assertEquals("green", machine.configuration()[0]);
    }

    @Test
    public void accordingGarzonVargasShouldNotMoveWheelWithZeroSteps()
    {
        machine.spin(1, 0);
        assertTrue(machine.ok());
        assertEquals("red", machine.configuration()[0]);
    }

    @Test
    public void accordingGarzonVargasShouldNotRotateWithNegativeSteps()
    {
        machine.spin(1, -1);
        assertFalse(machine.ok());
        assertEquals("red", machine.configuration()[0]);
    }

    @Test
    public void accordingGarzonVargasShouldNotRotateWheelWithoutSymbols()
    {
        machine.addWheel(4);
        machine.spin(4, 3);
        assertFalse(machine.ok());
    }

    @Test
    public void accordingGarzonVargasShouldNotRotateLockedWheelSeveralSteps()
    {
        machine.lock(1);
        machine.spin(1, 2);
        assertFalse(machine.ok());
        assertEquals("red", machine.configuration()[0]);
    }

    // ---------------------------------------------------------- spin(setSymbols)

    @Test
    public void accordingGarzonVargasShouldLeaveMachineInGivenConfiguration()
    {
        machine.spin(new String[]{"blue", "red", "green"});
        assertTrue(machine.ok());
        assertArrayEquals(new String[]{"blue", "red", "green"}, machine.configuration());
    }

    @Test
    public void accordingGarzonVargasShouldBeJackpotAfterSettingSameSymbolEverywhere()
    {
        machine.spin(new String[]{"red", "red", "red"});
        assertTrue(machine.isJackpot());
    }

    @Test
    public void accordingGarzonVagasShouldNotSetConfigurationWithWrongLength()
    {
        machine.spin(new String[]{"red", "red"});
        assertFalse(machine.ok());
        assertArrayEquals(new String[]{"red", "green", "blue"}, machine.configuration());
    }

    @Test
    public void accordingGarzonVargasShouldNotSetNullConfiguration()
    {
        machine.spin((String[]) null);
        assertFalse(machine.ok());
    }

    @Test
    public void accordingGarzonVargasShouldNotChangeAnyWheelIfConfigurationIsImpossible()
    {
        // la rueda 3 no tiene "purple": no debe cambiar ninguna, ni siquiera la 1 y la 2
        machine.spin(new String[]{"blue", "red", "purple"});
        assertFalse(machine.ok());
        assertArrayEquals(new String[]{"red", "green", "blue"}, machine.configuration());
    }

    @Test
    public void accordingGarzonVargasShouldAcceptLockedWheelThatAlreadyShowsTheSymbol()
    {
        machine.lock(1);             // la rueda 1 muestra red
        machine.spin(new String[]{"red", "blue", "green"});
        assertTrue(machine.ok());
        assertArrayEquals(new String[]{"red", "blue", "green"}, machine.configuration());
    }

    @Test
    public void accordingGarzonVargasShouldNotSetConfigurationIfLockedWheelShowsAnotherSymbol()
    {
        machine.lock(1);             // la rueda 1 muestra red, pero se pide blue
        machine.spin(new String[]{"blue", "blue", "green"});
        assertFalse(machine.ok());
        assertArrayEquals(new String[]{"red", "green", "blue"}, machine.configuration());
    }
}
import java.util.ArrayList;

/**
 * Representa una rueda de la maquina tragamonedas.
 *
 * Una rueda guarda una lista circular de simbolos (colores CSS) y muestra
 * uno solo a la vez. Ademas puede estar fija (lock): una rueda fija se
 * dibuja con una barra roja debajo y SlotMachine no permite girarla.
 *
 * La rueda solo conoce su propia apariencia: no sabe si la maquina es
 * ganadora ni valida las reglas de la maquina (eso lo hace SlotMachine).
 */
public class Wheel
{
    /** Distancia horizontal entre dos ruedas consecutivas. */
    public static final int STEP = 90;
    /** Coordenada x del marco de la primera rueda. */
    public static final int FIRST_X = 90;

    private static final int FRAME_WIDTH = 80;
    private static final int FRAME_HEIGHT = 80;
    private static final int FRAME_Y = 50;
    private static final int SYMBOL_SIZE = 50;
    private static final String FRAME_COLOR = "lightgray";

    // Marca que indica que la rueda esta fija (barra roja bajo el marco).
    private static final int MARK_WIDTH = 40;
    private static final int MARK_HEIGHT = 8;
    private static final int MARK_Y = FRAME_Y + FRAME_HEIGHT + 10;
    private static final String MARK_COLOR = "red";

    // Posicion por omision de las figuras de shapes al crearse.
    private static final int DEFAULT_FRAME_X = 70;
    private static final int DEFAULT_FRAME_Y = 15;
    private static final int DEFAULT_SYMBOL_X = 20;
    private static final int DEFAULT_SYMBOL_Y = 15;

    private Rectangle frame;
    private Circle symbol;
    private Rectangle lockMark;
    private ArrayList<String> colors;
    private int position;
    private int frameX;
    private boolean visible;
    private boolean locked;

    /**
     * Crea una rueda invisible, sin simbolos y suelta.
     *
     * @param order posicion de la rueda en la maquina, empezando en 1
     */
    public Wheel(int order)
    {
        frame = new Rectangle();
        frame.changeSize(FRAME_HEIGHT, FRAME_WIDTH);
        frame.changeColor(FRAME_COLOR);
        frame.moveVertical(FRAME_Y - DEFAULT_FRAME_Y);

        symbol = new Circle();
        symbol.changeSize(SYMBOL_SIZE);
        symbol.moveVertical(FRAME_Y + (FRAME_HEIGHT - SYMBOL_SIZE) / 2 - DEFAULT_SYMBOL_Y);
        symbol.moveHorizontal(DEFAULT_FRAME_X + (FRAME_WIDTH - SYMBOL_SIZE) / 2 - DEFAULT_SYMBOL_X);

        lockMark = new Rectangle();
        lockMark.changeSize(MARK_HEIGHT, MARK_WIDTH);
        lockMark.changeColor(MARK_COLOR);
        lockMark.moveVertical(MARK_Y - DEFAULT_FRAME_Y);
        lockMark.moveHorizontal((FRAME_WIDTH - MARK_WIDTH) / 2);

        frameX = DEFAULT_FRAME_X;
        colors = new ArrayList<String>();
        position = 0;
        visible = false;
        locked = false;
        moveTo(order);
    }

    /**
     * Mueve la rueda a la posicion indicada de la maquina.
     *
     * @param order nueva posicion de la rueda, empezando en 1
     */
    public void moveTo(int order)
    {
        int delta = FIRST_X + (order - 1) * STEP - frameX;
        if(delta != 0)
        {
            frame.moveHorizontal(delta);
            symbol.moveHorizontal(delta);
            lockMark.moveHorizontal(delta);
            frameX += delta;
        }
    }

    /**
     * Hace visible la rueda. Se dibuja el marco y luego el simbolo, para que
     * el simbolo quede encima. La marca de fija solo se ve si la rueda esta fija.
     */
    public void makeVisible()
    {
        visible = true;
        frame.makeVisible();
        if(!colors.isEmpty())
        {
            symbol.makeVisible();
        }
        refreshMark();
    }

    /**
     * Hace invisible la rueda.
     */
    public void makeInvisible()
    {
        visible = false;
        frame.makeInvisible();
        symbol.makeInvisible();
        lockMark.makeInvisible();
    }

    /**
     * Fija la rueda.
     */
    public void lock()
    {
        locked = true;
        refreshMark();
    }

    /**
     * Suelta la rueda.
     */
    public void unlock()
    {
        locked = false;
        refreshMark();
    }

    /**
     * Indica si la rueda esta fija.
     *
     * @return true si la rueda esta fija
     */
    public boolean isLocked()
    {
        return locked;
    }

    /**
     * Indica si la rueda no tiene simbolos.
     *
     * @return true si la rueda esta vacia
     */
    public boolean isEmpty()
    {
        return colors.isEmpty();
    }

    /**
     * Indica si la rueda tiene un simbolo.
     *
     * @param color color CSS del simbolo
     * @return true si la rueda tiene ese simbolo
     */
    public boolean hasSymbol(String color)
    {
        return colors.contains(color);
    }

    /**
     * Agrega un simbolo al final de la rueda.
     *
     * @param color color CSS del simbolo
     * @return false si la rueda ya tenia ese simbolo
     */
    public boolean addSymbol(String color)
    {
        if(colors.contains(color))
        {
            return false;
        }
        colors.add(color);
        if(colors.size() == 1)
        {
            position = 0;
            refresh();
        }
        return true;
    }

    /**
     * Elimina un simbolo de la rueda. Si el simbolo eliminado no era el que
     * se mostraba, la rueda sigue mostrando el mismo.
     *
     * @param color color del simbolo que se quiere eliminar
     * @return false si la rueda no tenia ese simbolo
     */
    public boolean removeSymbol(String color)
    {
        int index = colors.indexOf(color);
        if(index < 0)
        {
            return false;
        }
        colors.remove(index);
        if(index < position)
        {
            position--;
        }
        else if(position >= colors.size())
        {
            position = 0;
        }
        refresh();
        return true;
    }

    /**
     * Gira la rueda hasta que se muestre el simbolo indicado.
     *
     * @param color color del simbolo que debe quedar visible
     * @return false si la rueda no tiene ese simbolo
     */
    public boolean place(String color)
    {
        int index = colors.indexOf(color);
        if(index < 0)
        {
            return false;
        }
        position = index;
        refresh();
        return true;
    }

    /**
     * Gira la rueda una posicion.
     *
     * @return false si la rueda no tiene simbolos
     */
    public boolean spin()
    {
        return rotate(1);
    }

    /**
     * Gira la rueda un numero de pasos de una sola vez, sin mostrar los
     * pasos intermedios. Como la rueda es circular, solo importa el resto
     * de dividir los pasos entre la cantidad de simbolos.
     *
     * @param steps numero de pasos
     * @return false si la rueda no tiene simbolos
     */
    public boolean rotate(int steps)
    {
        if(colors.isEmpty())
        {
            return false;
        }
        position = (int) Math.floorMod((long) position + steps, (long) colors.size());
        refresh();
        return true;
    }

    /**
     * Devuelve el simbolo que se esta mostrando.
     *
     * @return color visible, o null si la rueda no tiene simbolos
     */
    public String getCurrentSymbol()
    {
        if(colors.isEmpty())
        {
            return null;
        }
        return colors.get(position);
    }

    /**
     * Devuelve los simbolos de la rueda en el orden en que estan en ella.
     *
     * @return colores de la rueda
     */
    public String[] getSymbols()
    {
        return colors.toArray(new String[0]);
    }

    /**
     * Actualiza el circulo para que refleje el simbolo actual.
     */
    private void refresh()
    {
        if(colors.isEmpty())
        {
            symbol.makeInvisible();
            return;
        }
        symbol.changeColor(colors.get(position));
        if(visible)
        {
            symbol.makeVisible();
        }
    }

    /**
     * Muestra la marca de fija solo si la rueda es visible y esta fija.
     */
    private void refreshMark()
    {
        if(visible && locked)
        {
            lockMark.makeVisible();
        }
        else
        {
            lockMark.makeInvisible();
        }
    }
}
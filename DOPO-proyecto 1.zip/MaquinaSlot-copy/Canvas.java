import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.util.*;

/**
 * Canvas permite realizar dibujos graficos sencillos en un lienzo.
 * Esta es una modificacion del Canvas general, hecha especialmente para
 * el ejemplo "shapes" de BlueJ. 
 *
 * @author: Bruce Quig
 * @author: Michael Kolling (mik)
 *
 * @version: 1.6 (shapes)
 */
public class Canvas{
    // Nota: la implementacion de esta clase (especialmente el manejo de
    // la identidad y los colores de las figuras) es un poco mas compleja de lo necesario. Esto
    // se hace para mantener sencilla la interfaz y los campos de instancia de los
    // objetos de las figuras de este proyecto con fines educativos.

	private static Canvas canvasSingleton;

	
	private static final Map<String, Color> CSS_COLORS = new HashMap<String, Color>();

	static {
		String[] table = {
			"aliceblue=F0F8FF", "antiquewhite=FAEBD7", "aqua=00FFFF", "aquamarine=7FFFD4",
			"azure=F0FFFF", "beige=F5F5DC", "bisque=FFE4C4", "black=000000",
			"blanchedalmond=FFEBCD", "blue=0000FF", "blueviolet=8A2BE2", "brown=A52A2A",
			"burlywood=DEB887", "cadetblue=5F9EA0", "chartreuse=7FFF00", "chocolate=D2691E",
			"coral=FF7F50", "cornflowerblue=6495ED", "cornsilk=FFF8DC", "crimson=DC143C",
			"cyan=00FFFF", "darkblue=00008B", "darkcyan=008B8B", "darkgoldenrod=B8860B",
			"darkgray=A9A9A9", "darkgreen=006400", "darkgrey=A9A9A9", "darkkhaki=BDB76B",
			"darkmagenta=8B008B", "darkolivegreen=556B2F", "darkorange=FF8C00", "darkorchid=9932CC",
			"darkred=8B0000", "darksalmon=E9967A", "darkseagreen=8FBC8F", "darkslateblue=483D8B",
			"darkslategray=2F4F4F", "darkslategrey=2F4F4F", "darkturquoise=00CED1", "darkviolet=9400D3",
			"deeppink=FF1493", "deepskyblue=00BFFF", "dimgray=696969", "dimgrey=696969",
			"dodgerblue=1E90FF", "firebrick=B22222", "floralwhite=FFFAF0", "forestgreen=228B22",
			"fuchsia=FF00FF", "gainsboro=DCDCDC", "ghostwhite=F8F8FF", "gold=FFD700",
			"goldenrod=DAA520", "gray=808080", "green=008000", "greenyellow=ADFF2F",
			"grey=808080", "honeydew=F0FFF0", "hotpink=FF69B4", "indianred=CD5C5C",
			"indigo=4B0082", "ivory=FFFFF0", "khaki=F0E68C", "lavender=E6E6FA",
			"lavenderblush=FFF0F5", "lawngreen=7CFC00", "lemonchiffon=FFFACD", "lightblue=ADD8E6",
			"lightcoral=F08080", "lightcyan=E0FFFF", "lightgoldenrodyellow=FAFAD2", "lightgray=D3D3D3",
			"lightgreen=90EE90", "lightgrey=D3D3D3", "lightpink=FFB6C1", "lightsalmon=FFA07A",
			"lightseagreen=20B2AA", "lightskyblue=87CEFA", "lightslategray=778899", "lightslategrey=778899",
			"lightsteelblue=B0C4DE", "lightyellow=FFFFE0", "lime=00FF00", "limegreen=32CD32",
			"linen=FAF0E6", "magenta=FF00FF", "maroon=800000", "mediumaquamarine=66CDAA",
			"mediumblue=0000CD", "mediumorchid=BA55D3", "mediumpurple=9370DB", "mediumseagreen=3CB371",
			"mediumslateblue=7B68EE", "mediumspringgreen=00FA9A", "mediumturquoise=48D1CC", "mediumvioletred=C71585",
			"midnightblue=191970", "mintcream=F5FFFA", "mistyrose=FFE4E1", "moccasin=FFE4B5",
			"navajowhite=FFDEAD", "navy=000080", "oldlace=FDF5E6", "olive=808000",
			"olivedrab=6B8E23", "orange=FFA500", "orangered=FF4500", "orchid=DA70D6",
			"palegoldenrod=EEE8AA", "palegreen=98FB98", "paleturquoise=AFEEEE", "palevioletred=DB7093",
			"papayawhip=FFEFD5", "peachpuff=FFDAB9", "peru=CD853F", "pink=FFC0CB",
			"plum=DDA0DD", "powderblue=B0E0E6", "purple=800080", "rebeccapurple=663399",
			"red=FF0000", "rosybrown=BC8F8F", "royalblue=4169E1", "saddlebrown=8B4513",
			"salmon=FA8072", "sandybrown=F4A460", "seagreen=2E8B57", "seashell=FFF5EE",
			"sienna=A0522D", "silver=C0C0C0", "skyblue=87CEEB", "slateblue=6A5ACD",
			"slategray=708090", "slategrey=708090", "snow=FFFAFA", "springgreen=00FF7F",
			"steelblue=4682B4", "tan=D2B48C", "teal=008080", "thistle=D8BFD8",
			"tomato=FF6347", "turquoise=40E0D0", "violet=EE82EE", "wheat=F5DEB3",
			"white=FFFFFF", "whitesmoke=F5F5F5", "yellow=FFFF00", "yellowgreen=9ACD32"
		};
		for(String entry : table) {
			String[] parts = entry.split("=");
			CSS_COLORS.put(parts[0], new Color(Integer.parseInt(parts[1], 16)));
		}
	}

	/**
	 * Indica si un nombre corresponde a un color del estandar CSS.
	 * @param name nombre del color (no distingue mayusculas)
	 * @return true si es un nombre de color CSS valido
	 */
	public static boolean isCssColor(String name){
		return name != null && CSS_COLORS.containsKey(name.trim().toLowerCase());
	}

	/**
	 * Metodo de fabrica para obtener el objeto unico del lienzo.
	 */
	public static Canvas getCanvas(){
		if(canvasSingleton == null) {
			canvasSingleton = new Canvas("Slot Machine", 900, 300, 
										 Color.white);
		}
		canvasSingleton.setVisible(true);
		return canvasSingleton;
	}

	//  ----- parte de la instancia -----

    private JFrame frame;
    private CanvasPane canvas;
    private Graphics2D graphic;
    private Color backgroundColour;
    private Image canvasImage;
    private List <Object> objects;
    private HashMap <Object,ShapeDescription> shapes;
    
    /**
     * Crea un lienzo.
     * @param title titulo que aparece en el marco del lienzo
     * @param width  el ancho deseado del lienzo
     * @param height  la altura deseada del lienzo
     * @param bgClour  el color de fondo deseado del lienzo
     */
    private Canvas(String title, int width, int height, Color bgColour){
        frame = new JFrame();
        canvas = new CanvasPane();
        frame.setContentPane(canvas);
        frame.setTitle(title);
        canvas.setPreferredSize(new Dimension(width, height));
        backgroundColour = bgColour;
        frame.pack();
        objects = new ArrayList <Object>();
        shapes = new HashMap <Object,ShapeDescription>();
    }

    /**
     * Establece la visibilidad del lienzo y lo trae al frente de la pantalla
     * cuando se hace visible. Este metodo tambien puede usarse para traer un lienzo ya
     * visible al frente de otras ventanas.
     * @param visible valor booleano que representa la visibilidad deseada del
     * lienzo (true o false)
     */
    public void setVisible(boolean visible){
        if(graphic == null) {
            // primera vez: crea la imagen fuera de pantalla y la rellena con
            // el color de fondo
            Dimension size = canvas.getSize();
            canvasImage = canvas.createImage(size.width, size.height);
            graphic = (Graphics2D)canvasImage.getGraphics();
            graphic.setColor(backgroundColour);
            graphic.fillRect(0, 0, size.width, size.height);
            graphic.setColor(Color.black);
        }
        frame.setVisible(visible);
    }

    /**
     * Dibuja una figura en el lienzo.
     * @param  referenceObject  un objeto que identifica esta figura
     * @param  color            el color de la figura
     * @param  shape            la figura que se dibujara en el lienzo
     */
     // Nota: esta es una forma poco usual de mantener las figuras
     // Se diseño cuidadosamente para mantener sencillas las interfaces visibles de las figuras
     // de este proyecto con fines educativos.
    public void draw(Object referenceObject, String color, Shape shape){
    	objects.remove(referenceObject);   // por si ya estaba incluida
    	objects.add(referenceObject);      // agrega al final
    	shapes.put(referenceObject, new ShapeDescription(shape, color));
    	redraw();
    }
 
    /**
     * Borra una figura de la pantalla.
     * @param referenceObject figura que se borrara
     */
    public void erase(Object referenceObject){
    	objects.remove(referenceObject);   // por si ya estaba incluida
    	shapes.remove(referenceObject);
    	redraw();
    }

    /**
     * Establece el color de primer plano del lienzo.
     * @param colorString nombre CSS del color; si no es valido se usa negro
     */
    public void setForegroundColor(String colorString){
        Color color = null;
        if(colorString != null) {
            color = CSS_COLORS.get(colorString.trim().toLowerCase());
        }
        graphic.setColor(color == null ? Color.black : color);
    }

    /**
     * Espera una cantidad determinada de milisegundos antes de continuar.
     * Esto permite especificar facilmente una pequena pausa que puede
     * usarse al producir animaciones.
     * @param milliseconds cantidad 
     */
    public void wait(int milliseconds){
        try{
            Thread.sleep(milliseconds);
        } catch (Exception e){
            // se ignora la excepcion por ahora
        }
    }

	/**
	 * Vuelve a dibujar todas las figuras del lienzo.
	 */
	private void redraw(){
		erase();
		for(Iterator i=objects.iterator(); i.hasNext(); ) {
                       shapes.get(i.next()).draw(graphic);
        }
        canvas.repaint();
    }
       
    /**
     * Borra todo el lienzo. (No lo vuelve a pintar.)
     */
    private void erase(){
        Color original = graphic.getColor();
        graphic.setColor(backgroundColour);
        Dimension size = canvas.getSize();
        graphic.fill(new java.awt.Rectangle(0, 0, size.width, size.height));
        graphic.setColor(original);
    }


    /************************************************************************
     * Clase interna CanvasPane: componente real del lienzo contenido en el
     * marco del lienzo. Es esencialmente un JPanel con capacidad adicional para
     * actualizar la imagen dibujada en el.
     */
    private class CanvasPane extends JPanel{
        public void paint(Graphics g){
            g.drawImage(canvasImage, 0, 0, null);
        }
    }
    
    /************************************************************************
     * Clase interna CanvasPane: componente real del lienzo contenido en el
     * marco del lienzo. Es esencialmente un JPanel con capacidad adicional para
     * actualizar la imagen dibujada en el.
     */
    private class ShapeDescription{
    	private Shape shape;
    	private String colorString;

		public ShapeDescription(Shape shape, String color){
    		this.shape = shape;
    		colorString = color;
    	}

		public void draw(Graphics2D graphic){
			setForegroundColor(colorString);
			graphic.draw(shape);
			graphic.fill(shape);
		}
    }

}
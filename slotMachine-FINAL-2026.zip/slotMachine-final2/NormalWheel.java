/**
 * Rueda normal: gira hacia adelante, se deja fijar, intercambiar y eliminar.
 * Se dibuja con el marco gris claro.
 */
public class NormalWheel extends Wheel
{
    /**
     * Crea una rueda normal, invisible, sin simbolos y suelta.
     *
     * @param order posicion de la rueda en la maquina, empezando en 1
     */
    public NormalWheel(int order)
    {
        super(order, "lightgray");
    }

    @Override
    public String getKind()
    {
        return "normal";
    }
}

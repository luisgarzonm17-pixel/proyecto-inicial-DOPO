/**
 * Simbolo normal: siempre se ve, siempre tiene el mismo tamano, no cambia
 * al ser seleccionado y se dibuja como un circulo.
 */
public class NormalSymbol extends Symbol
{
    /**
     * Crea un simbolo normal.
     *
     * @param color color CSS del simbolo
     */
    public NormalSymbol(String color)
    {
        super(color);
    }

    @Override
    public String getKind()
    {
        return "normal";
    }

    @Override
    public SymbolShape getShape()
    {
        return SymbolShape.CIRCLE;
    }
}

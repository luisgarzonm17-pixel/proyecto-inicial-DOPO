import java.util.HashMap;
import java.util.Map;
import java.util.function.IntFunction;

/**
 * Fabrica de ruedas: crea una rueda a partir del nombre de su tipo.
 *
 * Para ofrecer un tipo nuevo de rueda solo hay que crear la clase y
 * agregar una linea al registro. SlotMachine no cambia.
 */
class WheelFactory
{
    private static final Map<String, IntFunction<Wheel>> TYPES =
        new HashMap<String, IntFunction<Wheel>>();

    static
    {
        TYPES.put("normal", NormalWheel::new);
        TYPES.put("lefty", LeftyWheel::new);
        TYPES.put("rebel", RebelWheel::new);
        TYPES.put("reverse", ReverseWheel::new);
    }

    private WheelFactory()
    {
    }

    /**
     * Indica si el tipo de rueda existe.
     *
     * @param type nombre del tipo (no distingue mayusculas)
     * @return true si existe
     */
    static boolean exists(String type)
    {
        return type != null && TYPES.containsKey(type.trim().toLowerCase());
    }

    /**
     * Crea una rueda del tipo indicado.
     *
     * @param type nombre del tipo
     * @param order posicion de la rueda en la maquina, empezando en 1
     * @return la rueda, o null si el tipo no existe
     */
    static Wheel create(String type, int order)
    {
        if(!exists(type))
        {
            return null;
        }
        return TYPES.get(type.trim().toLowerCase()).apply(order);
    }
}

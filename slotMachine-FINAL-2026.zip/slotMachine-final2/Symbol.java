/**
 * Simbolo de una rueda. Es una clase abstracta: se identifica por un color
 * CSS y, por omision, siempre se ve, siempre tiene el mismo tamano y no
 * cambia al ser seleccionado. El simbolo "normal" es NormalSymbol.
 *
 * Es la clase base de todos los tipos de simbolos (NormalSymbol,
 * EphemeralSymbol, ShySymbol, ...). Cada tipo debe indicar su nombre
 * (getKind) y su figura (getShape), y puede redefinir su tamano, su
 * visibilidad y que le pasa al ser seleccionado. Para crear un tipo nuevo
 * basta con extender esta clase y registrarlo en SymbolFactory.
 */
public abstract class Symbol
{
    /** Tamano (en pixeles) de un simbolo que no ha cambiado. */
    public static final int FULL_SIZE = 50;

    private final String color;

    /**
     * Crea un simbolo. Solo la usan las subclases.
     *
     * @param color color CSS (ya validado y en minusculas)
     */
    protected Symbol(String color)
    {
        this.color = color;
    }

    /**
     * Devuelve el color que identifica al simbolo.
     *
     * @return color CSS del simbolo
     */
    public String getColor()
    {
        return color;
    }

    /**
     * Nombre del tipo de simbolo. Cada tipo de simbolo debe definirlo.
     *
     * @return nombre del tipo, por ejemplo "normal"
     */
    public abstract String getKind();

    /**
     * Indica si el simbolo se ve en la rueda cuando es el seleccionado.
     *
     * @return true si se ve
     */
    public boolean isVisible()
    {
        return true;
    }

    /**
     * Tamano con el que se dibuja el simbolo.
     *
     * @return tamano en pixeles
     */
    public int getSize()
    {
        return FULL_SIZE;
    }

    /**
     * Figura con la que se dibuja el simbolo. Cada tipo de simbolo debe
     * definirla.
     *
     * @return figura del simbolo
     */
    public abstract SymbolShape getShape();

    /**
     * Avisa que la rueda dejo este simbolo como el mostrado, una o varias
     * veces. El simbolo normal no cambia.
     *
     * @param times numero de veces que fue seleccionado (mayor que 0)
     */
    public void select(int times)
    {
    }
}

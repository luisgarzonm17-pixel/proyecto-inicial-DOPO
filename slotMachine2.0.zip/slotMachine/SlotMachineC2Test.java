package slotMachine;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import org.junit.Before;
import org.junit.Test;

/**
* Pruebas unitarias para los requisitos del Ciclo 2 de SlotMachine: swap, lock/unlock,
 * spin(wheel, steps) y spin(setSymbols). Todas las pruebas se ejecutan con la máquina
 * en modo INVISIBLE, tal como exige la tarea (sin JOptionPane, sin
 * retrasos de animación y sin dependencia de una interfaz gráfica).
 *
 * Cada comportamiento se prueba desde dos perspectivas, según lo solicitado en la tarea:
 * "qué debería hacer" (should*) y "qué no debería hacer" (shouldNot*).
 *
 * @author  Jose Luis Garzon - Javier Vargas - Proyecto Inicial Ciclo 2
 * @version 1.0 */
public class SlotMachineC2Test{

    private SlotMachine machine;

    /**
     * Construye una pequeña máquina con dos ruedas y tres símbolos cada una,
     * lista para las pruebas del Ciclo 2. Permanece invisible a propósito.
     */
    @Before
    public void setUp(){
        machine = new SlotMachine();
        machine.addWheel(1);
        machine.addWheel(2);
        machine.addSymbol(1, "red");
        machine.addSymbol(1, "green");
        machine.addSymbol(1, "blue");
        machine.addSymbol(2, "yellow");
        machine.addSymbol(2, "cyan");
        machine.addSymbol(2, "magenta");
        // machine intentionally left invisible for all tests
    }

    /* ------------------------- spin(wheel, steps) ------------------------- */

    @Test
    public void shouldRotateWheelForwardByExactSteps(){
        // wheel 1 starts at index 0 ("red"); rotating 2 forward -> index 2 ("blue")
        machine.spin(1, 2);
        assertTrue(machine.ok());
        assertEquals("blue", machine.configuration()[0]);
    }

    @Test
    public void shouldRotateWheelBackwardWithNegativeSteps(){
        // index 0 ("red") rotating -1 -> wraps to last index ("blue")
        machine.spin(1, -1);
        assertTrue(machine.ok());
        assertEquals("blue", machine.configuration()[0]);
    }

    @Test
    public void shouldNotRotateWheelBeyondValidRange(){
        machine.spin(99, 1); // wheel position clamped to the last wheel (2)
        assertTrue(machine.ok());
        assertEquals("cyan", machine.configuration()[1]); // index 0 + 1 -> "cyan"
    }

    /* ------------------------------ lock/unlock ---------------------------- */

    @Test
    public void shouldPreventSpinOnLockedWheel(){
        machine.lock(1);
        String before = machine.configuration()[0];
        machine.spin(1, 1);
        assertFalse(machine.ok());
        assertEquals(before, machine.configuration()[0]); // unchanged
    }

    @Test
    public void shouldAllowSpinAfterUnlock(){
        machine.lock(1);
        machine.unlock(1);
        machine.spin(1, 1);
        assertTrue(machine.ok());
        assertEquals("green", machine.configuration()[0]);
    }

    @Test
    public void shouldSkipLockedWheelsOnSpinAll(){
        machine.lock(1);
        String beforeWheel1 = machine.configuration()[0];
        machine.spin(); // spins all wheels; wheel 1 should stay untouched
        assertTrue(machine.ok());
        assertEquals(beforeWheel1, machine.configuration()[0]);
    }

    /* --------------------------------- swap -------------------------------- */

    @Test
    public void shouldSwapConfigurationsBetweenWheels(){
        String wheel1Before = machine.configuration()[0];
        String wheel2Before = machine.configuration()[1];
        machine.swap(1, 2);
        assertTrue(machine.ok());
        assertEquals(wheel2Before, machine.configuration()[0]);
        assertEquals(wheel1Before, machine.configuration()[1]);
    }

    @Test
    public void shouldNotSwapWithFewerThanTwoWheels(){
        SlotMachine single = new SlotMachine();
        single.addWheel(1);
        single.addSymbol(1, "red");
        single.swap(1, 1);
        assertFalse(single.ok());
    }

    /* --------------------------- spin(setSymbols) --------------------------- */

    @Test
    public void shouldSetExactConfigurationWhenAllSymbolsExist(){
        machine.spin(new String[]{"green", "cyan"});
        assertTrue(machine.ok());
        assertArrayEquals(new String[]{"green", "cyan"}, machine.configuration());
    }

    @Test
    public void shouldNotChangeAnyWheelIfOneTargetSymbolIsMissing(){
        String[] before = machine.configuration();
        machine.spin(new String[]{"green", "purple"}); // "purple" is not on wheel 2
        assertFalse(machine.ok());
        assertArrayEquals(before, machine.configuration()); // nothing changed (all-or-nothing)
    }

    @Test
    public void shouldNotAcceptConfigurationOfWrongLength(){
        machine.spin(new String[]{"green"}); // machine has 2 wheels, not 1
        assertFalse(machine.ok());
    }

    @Test
    public void shouldRespectLockedWheelWhenSettingConfiguration(){
        machine.lock(1);
        String wheel1Before = machine.configuration()[0];
        machine.spin(new String[]{"blue", "cyan"}); // wheel 1 is locked on "red", asking for "blue"
        assertFalse(machine.ok());
        assertEquals(wheel1Before, machine.configuration()[0]);
    }
}

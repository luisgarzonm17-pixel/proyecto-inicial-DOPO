package slotMachine;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;
import org.junit.Before;
import org.junit.Test;

/**
 * Clase de pruebas compartida para el Ciclo 2, creada colectivamente por todo el curso
 * utilizando la wiki del curso. Cada pareja o equipo añade aquí sus propios casos de prueba
 * (no elimine las pruebas de otros equipos). Todas las pruebas deben ejecutarse con la máquina
 * INVISIBLE, según las especificaciones de la tarea.
 *
 * Convención de nombres (según la tarea): el nombre de cada método de prueba debe
 * comenzar con la identificación de sus autores —las iniciales de sus
 * primeros apellidos, con la primera letra del apellido del segundo autor
 * en mayúscula, en orden alfabético— seguido de "Should...".
 * Ejemplo: autores "Diaz" y "Avila" -> "DcAv" es solo el ejemplo dado
 * en el PDF; sustitúyalo por SUS iniciales reales; p. ej., dos autores con
 * apellidos "Perez" y "Gomez" -> "PeGShould...".
 *
 * @author  Jose Luis Garzon - Javier Vargas  - Proyecto Inicial Ciclo 2 (colectivo)
 * @version 1.0
 */
public class SlotMachineCC2Test{

    private SlotMachine machine;

    @Before
    public void setUp(){
        machine = new SlotMachine();
        machine.addWheel(1);
        machine.addSymbol(1, "red");
        machine.addSymbol(1, "blue");
        // machine intentionally left invisible
    }

    /**
     * EJEMPLO — sustituye "example" por las iniciales reales de tu equipo y añade
     * tus propias pruebas a continuación de esta. No elimines las pruebas de tus compañeros de equipo.
     */
    @Test
    public void exampleShouldReflectYourTeamInitialsHere(){
        machine.spin(1, 1);
        assertTrue(machine.ok());
        assertFalse(machine.isJackpot()); // placeholder - replace with a real assertion
    }

    // ---- Team 2: add your test(s) below ----

    // ---- Team 3: add your test(s) below ----
}

package slotMachine;

import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.util.*;

/**
 * Canvas is a class to allow for simple graphical drawing on a canvas.
 * This is a modification of the general purpose Canvas, specially made for
 * the BlueJ "shapes" example. 
 *
 * @author: Bruce Quig
 * @author: Michael Kolling (mik)
 *
 * @version: 1.6 (shapes)
 */
public class Canvas{
    // Note: The implementation of this class (specifically the handling of
    // shape identity and colors) is slightly more complex than necessary. This
    // is done on purpose to keep the interface and instance fields of the
    // shape objects in this project clean and simple for educational purposes.

	private static Canvas canvasSingleton;

	/**
	 * Factory method to get the canvas singleton object.
	 */
	public static Canvas getCanvas(){
		if(canvasSingleton == null) {
			canvasSingleton = new Canvas("BlueJ Shapes Demo", 300, 300, 
										 Color.white);
		}
		canvasSingleton.setVisible(true);
		return canvasSingleton;
	}

	//  ----- instance part -----

    private JFrame frame;
    private CanvasPane canvas;
    private Graphics2D graphic;
    private Color backgroundColour;
    private Image canvasImage;
    private List <Object> objects;
    private HashMap <Object,ShapeDescription> shapes;
    
    /**
     * Create a Canvas.
     * @param title  title to appear in Canvas Frame
     * @param width  the desired width for the canvas
     * @param height  the desired height for the canvas
     * @param bgClour  the desired background colour of the canvas
     */
    private Canvas(String title, int width, int height, Color bgColour){
        frame = new JFrame();
        canvas = new CanvasPane();
        frame.setContentPane(canvas);
        frame.setTitle(title);
        canvas.setPreferredSize(new Dimension(width, height));
        backgroundColour = bgColour;
        frame.pack();
        objects = new ArrayList <Object>();
        shapes = new HashMap <Object,ShapeDescription>();
    }

    /**
     * Set the canvas visibility and brings canvas to the front of screen
     * when made visible. This method can also be used to bring an already
     * visible canvas to the front of other windows.
     * @param visible  boolean value representing the desired visibility of
     * the canvas (true or false) 
     */
    public void setVisible(boolean visible){
        if(graphic == null) {
            // first time: instantiate the offscreen image and fill it with
            // the background colour
            Dimension size = canvas.getSize();
            canvasImage = canvas.createImage(size.width, size.height);
            graphic = (Graphics2D)canvasImage.getGraphics();
            graphic.setColor(backgroundColour);
            graphic.fillRect(0, 0, size.width, size.height);
            graphic.setColor(Color.black);
        }
        frame.setVisible(visible);
    }

    /**
     * Draw a given shape onto the canvas.
     * @param  referenceObject  an object to define identity for this shape
     * @param  color            the color of the shape
     * @param  shape            the shape object to be drawn on the canvas
     */
     // Note: this is a slightly backwards way of maintaining the shape
     // objects. It is carefully designed to keep the visible shape interfaces
     // in this project clean and simple for educational purposes.
    public void draw(Object referenceObject, String color, Shape shape){
    	objects.remove(referenceObject);   // just in case it was already there
    	objects.add(referenceObject);      // add at the end
    	shapes.put(referenceObject, new ShapeDescription(shape, color));
    	redraw();
    }
 
    /**
     * Erase a given shape's from the screen.
     * @param  referenceObject  the shape object to be erased 
     */
    public void erase(Object referenceObject){
    	objects.remove(referenceObject);   // just in case it was already there
    	shapes.remove(referenceObject);
    	redraw();
    }

    /**
     * Set the foreground colour of the Canvas.
     * @param  newColour   the new colour for the foreground of the Canvas 
     */
    public void setForegroundColor(String colorString){
        Color resolved = CSS_COLORS.get(colorString == null ? "" : colorString.trim().toLowerCase());
        graphic.setColor(resolved != null ? resolved : Color.black);
    }

    /* ---------------------------------------------------------------
     * EXTENSIÓN (proyecto slotMachine)
     * El paquete shapes original sólo reconocía 7 nombres de color.
     * El proyecto slotMachine exige que los símbolos usen nombres de
     * color del estándar CSS, así que se agrega una tabla con la
     * paleta de colores con nombre de CSS (CSS Color Module Level 3/4)
     * y setForegroundColor se extiende para resolver contra esa tabla.
     * ------------------------------------------------------------- */
    private static final HashMap<String, Color> CSS_COLORS = buildCssColorTable();

    private static HashMap<String, Color> buildCssColorTable(){
        HashMap<String, Color> table = new HashMap<String, Color>();
        String[] entries = {
            "aliceblue,F0F8FF","antiquewhite,FAEBD7","aqua,00FFFF","aquamarine,7FFFD4",
            "azure,F0FFFF","beige,F5F5DC","bisque,FFE4C4","black,000000",
            "blanchedalmond,FFEBCD","blue,0000FF","blueviolet,8A2BE2","brown,A52A2A",
            "burlywood,DEB887","cadetblue,5F9EA0","chartreuse,7FFF00","chocolate,D2691E",
            "coral,FF7F50","cornflowerblue,6495ED","cornsilk,FFF8DC","crimson,DC143C",
            "cyan,00FFFF","darkblue,00008B","darkcyan,008B8B","darkgoldenrod,B8860B",
            "darkgray,A9A9A9","darkgreen,006400","darkgrey,A9A9A9","darkkhaki,BDB76B",
            "darkmagenta,8B008B","darkolivegreen,556B2F","darkorange,FF8C00","darkorchid,9932CC",
            "darkred,8B0000","darksalmon,E9967A","darkseagreen,8FBC8F","darkslateblue,483D8B",
            "darkslategray,2F4F4F","darkturquoise,00CED1","darkviolet,9400D3","deeppink,FF1493",
            "deepskyblue,00BFFF","dimgray,696969","dodgerblue,1E90FF","firebrick,B22222",
            "floralwhite,FFFAF0","forestgreen,228B22","fuchsia,FF00FF","gainsboro,DCDCDC",
            "ghostwhite,F8F8FF","gold,FFD700","goldenrod,DAA520","gray,808080",
            "green,008000","greenyellow,ADFF2F","honeydew,F0FFF0","hotpink,FF69B4",
            "indianred,CD5C5C","indigo,4B0082","ivory,FFFFF0","khaki,F0E68C",
            "lavender,E6E6FA","lavenderblush,FFF0F5","lawngreen,7CFC00","lemonchiffon,FFFACD",
            "lightblue,ADD8E6","lightcoral,F08080","lightcyan,E0FFFF","lightgoldenrodyellow,FAFAD2",
            "lightgray,D3D3D3","lightgreen,90EE90","lightpink,FFB6C1","lightsalmon,FFA07A",
            "lightseagreen,20B2AA","lightskyblue,87CEFA","lightslategray,778899","lightsteelblue,B0C4DE",
            "lightyellow,FFFFE0","lime,00FF00","limegreen,32CD32","linen,FAF0E6",
            "magenta,FF00FF","maroon,800000","mediumaquamarine,66CDAA","mediumblue,0000CD",
            "mediumorchid,BA55D3","mediumpurple,9370DB","mediumseagreen,3CB371","mediumslateblue,7B68EE",
            "mediumspringgreen,00FA9A","mediumturquoise,48D1CC","mediumvioletred,C71585","midnightblue,191970",
            "mintcream,F5FFFA","mistyrose,FFE4E1","moccasin,FFE4B5","navajowhite,FFDEAD",
            "navy,000080","oldlace,FDF5E6","olive,808000","olivedrab,6B8E23",
            "orange,FFA500","orangered,FF4500","orchid,DA70D6","palegoldenrod,EEE8AA",
            "palegreen,98FB98","paleturquoise,AFEEEE","palevioletred,DB7093","papayawhip,FFEFD5",
            "peachpuff,FFDAB9","peru,CD853F","pink,FFC0CB","plum,DDA0DD",
            "powderblue,B0E0E6","purple,800080","rebeccapurple,663399","red,FF0000",
            "rosybrown,BC8F8F","royalblue,4169E1","saddlebrown,8B4513","salmon,FA8072",
            "sandybrown,F4A460","seagreen,2E8B57","seashell,FFF5EE","sienna,A0522D",
            "silver,C0C0C0","skyblue,87CEEB","slateblue,6A5ACD","slategray,708090",
            "snow,FFFAFA","springgreen,00FF7F","steelblue,4682B4","tan,D2B48C",
            "teal,008080","thistle,D8BFD8","tomato,FF6347","turquoise,40E0D0",
            "violet,EE82EE","wheat,F5DEB3","white,FFFFFF","whitesmoke,F5F5F5",
            "yellow,FFFF00","yellowgreen,9ACD32"
        };
        for(String entry : entries){
            String[] parts = entry.split(",");
            table.put(parts[0], new Color(Integer.parseInt(parts[1], 16)));
        }
        return table;
    }

    /**
     * Wait for a specified number of milliseconds before finishing.
     * This provides an easy way to specify a small delay which can be
     * used when producing animations.
     * @param  milliseconds  the number 
     */
    public void wait(int milliseconds){
        try{
            Thread.sleep(milliseconds);
        } catch (Exception e){
            // ignoring exception at the moment
        }
    }

	/**
	 * Redraw ell shapes currently on the Canvas.
	 */
	private void redraw(){
		erase();
		for(Iterator i=objects.iterator(); i.hasNext(); ) {
                       shapes.get(i.next()).draw(graphic);
        }
        canvas.repaint();
    }
       
    /**
     * Erase the whole canvas. (Does not repaint.)
     */
    private void erase(){
        Color original = graphic.getColor();
        graphic.setColor(backgroundColour);
        Dimension size = canvas.getSize();
        graphic.fill(new java.awt.Rectangle(0, 0, size.width, size.height));
        graphic.setColor(original);
    }


    /************************************************************************
     * Inner class CanvasPane - the actual canvas component contained in the
     * Canvas frame. This is essentially a JPanel with added capability to
     * refresh the image drawn on it.
     */
    private class CanvasPane extends JPanel{
        public void paint(Graphics g){
            g.drawImage(canvasImage, 0, 0, null);
        }
    }
    
    /************************************************************************
     * Inner class CanvasPane - the actual canvas component contained in the
     * Canvas frame. This is essentially a JPanel with added capability to
     * refresh the image drawn on it.
     */
    private class ShapeDescription{
    	private Shape shape;
    	private String colorString;

		public ShapeDescription(Shape shape, String color){
    		this.shape = shape;
    		colorString = color;
    	}

		public void draw(Graphics2D graphic){
			setForegroundColor(colorString);
			graphic.draw(shape);
			graphic.fill(shape);
		}
    }

}

package slotMachine;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Una rueda (Wheel) es uno de los rodillos de la máquina tragamonedas. Contiene una lista ordenada de
 * símbolos (identificados por nombres de colores CSS) y muestra exactamente uno de ellos
 * a la vez a través de una "ventana", representada visualmente por un círculo (el
 * símbolo) dibujado sobre un rectángulo (el marco de la ventana).
 *
 * Esta clase es una clase auxiliar o de apoyo para SlotMachine; no forma
 * parte del diagrama de clases requerido por la tarea, pero reutiliza
 * los componentes del paquete `shapes` según lo estipulado.
 *
 * @author  Jose Luis Garzon - Javier Vargas  - Proyecto Inicial Ciclo 1
 * @version 1.0
 */
public class Wheel{

    /** Constantes visuales compartidas por todas las ruedas. */
    private static final int FRAME_WIDTH  = 50;
    private static final int FRAME_HEIGHT = 70;
    private static final int GAP          = 15;
    private static final int START_X      = 30;
    private static final int START_Y      = 60;
    private static final int SYMBOL_SIZE  = 34;

    private static final String NORMAL_FRAME_COLOR = "gray";
    private static final String WIN_FRAME_COLOR     = "gold";

    private final List<String> colors;
    private int position;              // index (0-based) of the visible symbol
    private final Rectangle frame;
    private final Circle symbolView;
    private boolean visible;
    private boolean locked;
    private static final Random RANDOM = new Random();

    /**
     * Crea una rueda nueva y vacía situada en el orden indicado entre las
     * ruedas de la máquina.
     * @param order Posición de esta rueda (empezando por 1) entre las ruedas de la máquina.
     */
    public Wheel(int order){
        colors = new ArrayList<String>();
        position = 0;
        visible = false;
        frame = new Rectangle();
        frame.changeSize(FRAME_HEIGHT, FRAME_WIDTH);
        symbolView = new Circle();
        symbolView.changeSize(SYMBOL_SIZE);
        relocate(order);
        frame.changeColor(NORMAL_FRAME_COLOR);
    }

    /**
     * Recalcula la posición horizontal de esta rueda en el lienzo (se utiliza
     * cuando se añaden o eliminan ruedas de la máquina).
     * @param order Posición de esta rueda (empezando por 1) entre las ruedas de la máquina.
     */
    public void relocate(int order){
        int x = START_X + (order - 1) * (FRAME_WIDTH + GAP);
        frame.moveTo(x, START_Y);
        symbolView.moveTo(x + (FRAME_WIDTH - SYMBOL_SIZE) / 2,
                           START_Y + (FRAME_HEIGHT - SYMBOL_SIZE) / 2);
    }

    /**
     * Añade un símbolo (color) al final de esta rueda.
     * @param color un nombre de color CSS
     */
    public void addSymbol(String color){
        colors.add(color);
        if(colors.size() == 1){
            position = 0;
        }
        refreshView();
    }

    /**
     * Remove the given symbol (color) from this wheel, if present.
     * @param color a CSS color name
     * @return true if the symbol was found and removed
     */
    public boolean removeSymbol(String color){
        int index = colors.indexOf(color);
        if(index == -1){
            return false;
        }
        colors.remove(index);
        if(position >= colors.size() && position > 0){
            position = colors.size() - 1;
        }
        refreshView();
        return true;
    }

    /**
     * Make the given symbol (color) the one currently shown in the window.
     * @param color a CSS color name
     * @return true if the symbol exists on this wheel and was placed
     */
    public boolean placeSymbol(String color){
        int index = colors.indexOf(color);
        if(index == -1){
            return false;
        }
        position = index;
        refreshView();
        return true;
    }

    /**
     * Gira la rueda hasta un símbolo aleatorio.
     * @return false si la rueda no tiene símbolos hacia los cuales girar.
     */
    public boolean spin(){
        if(colors.isEmpty()){
            return false;
        }
        if(colors.size() > 1){
            int newPosition;
            do{
                newPosition = RANDOM.nextInt(colors.size());
            } while(newPosition == position);
            position = newPosition;
        }
        refreshView();
        return true;
    }

    /**
     * @param color un nombre de color CSS
     * @return true si esta rueda ya tiene un símbolo de ese color
     */
    public boolean containsSymbol(String color){
        return colors.contains(color);
    }

    /** @return el color que se muestra actualmente en la ventana, o null si está vacía*/
    public String currentColor(){
        return colors.isEmpty() ? null : colors.get(position);
    }

    /** @return los colores de los símbolos de esta rueda, en orden de rueda comenzando en 1 */
    public String[] getColors(){
        return colors.toArray(new String[0]);
    }

    /** @return el número de símbolos en esta rueda */
    public int size(){
        return colors.size();
    }

    /** Haz visible la representación visual de esta rueda. */
    public void makeVisible(){
        visible = true;
        frame.makeVisible();
        refreshView();
    }

    /** Haz invisible la representación visual de esta rueda.. */
    public void makeInvisible(){
        visible = false;
        symbolView.makeInvisible();
        frame.makeInvisible();
    }

    /**
     * Resaltar (o quitar el resaltado de) el marco de esta rueda para indicar una
     * configuración ganadora o un premio mayor (jackpot).
     * @param winning true para resaltar esta rueda como parte de una victoria.
     */
    public void setWinning(boolean winning){
        frame.changeColor(winning ? WIN_FRAME_COLOR : NORMAL_FRAME_COLOR);
        // Re-draw the symbol so it stays on top of the freshly re-drawn frame.
        refreshView();
    }

    /**
     * Gira esta rueda el número de pasos indicado (Ciclo 2, requisito 11).
     * Un valor positivo avanza por la lista de símbolos; un valor negativo
     * retrocede, siguiendo la convención del problema I de la ICPC. Si
     * la rueda está visible actualmente, el movimiento se anima paso a
     * paso (requisito de usabilidad 1 del Ciclo 2); de lo contrario,
     * la rueda salta directamente al símbolo final.
     * @param steps el número de posiciones a girar (puede ser negativo)
     * @return false si la rueda no tiene símbolos por los que girar
     */
    public boolean rotate(int steps){
        if(colors.isEmpty()){
            return false;
        }
        int size = colors.size();
        int direction = steps < 0 ? -1 : 1;
        int magnitude = Math.abs(steps) % size;
        for(int i = 0; i < magnitude; i++){
            position = ((position + direction) % size + size) % size;
            refreshView();
            if(visible){
                Canvas.getCanvas().wait(150);
            }
        }
        return true;
    }

    /** Fix (hold) this wheel so its visible symbol cannot be changed. */
    public void lock(){
        locked = true;
    }

    /** Libera una rueda previamente fijada, permitiendo que su símbolo vuelva a cambiar. */
    public void unlock(){
        locked = false;
    }

    /** @return true si esta rueda está actualmente fija (bloqueada o retenida) */
    public boolean isLocked(){
        return locked;
    }

    /** Eliminar permanentemente los elementos visuales de esta rueda (se utiliza cuando se elimina la rueda) */
    public void delete(){
        makeInvisible();
    }

    /** Actualiza el círculo del símbolo para que coincida con el estado actual de color y visibilidad. */
    private void refreshView(){
        if(colors.isEmpty()){
            symbolView.makeInvisible();
            return;
        }
        symbolView.changeColor(currentColor());
        if(visible){
            symbolView.makeVisible();
        }
    }
}

package slotMachine;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import javax.swing.JOptionPane;

/**
 * SlotMachine simula una máquina tragamonedas de casino compuesta por un número variable
 * de rodillos; cada uno contiene un número variable de símbolos identificados por
 * nombres de colores CSS. Esta clase solo construye y manipula el simulador;
 * no intenta ganar el premio mayor (eso queda para un ciclo posterior).
 *
 * Notas de diseño / suposiciones (documentadas porque el enunciado las deja
 * abiertas a propósito):
 * <ul>
 *   <li>Todo parámetro "pos" utiliza una indexación basada en 1 y se ajusta al
 *       rango válido: los valores inferiores a 1 se convierten en 1, y los valores
 *       superiores al máximo se convierten en el máximo (según lo requerido).</li>
 *   <li>{@link #addSymbol(int, String)} añade el color al rodillo en
 *       la posición indicada; un rodillo no puede contener el mismo color
 *       dos veces, pero el mismo color puede aparecer en rodillos diferentes.</li>
 *   <li>{@link #delSymbol(String)} elimina el color especificado de todos
 *       los rodillos donde aparezca (es una operación que afecta a toda la máquina,
 *       ya que no recibe una posición de rodillo).</li>
 *   <li>{@link #symbols()} devuelve los colores de todos los símbolos definidos en
 *       la máquina, rodillo por rodillo; los símbolos de cada rodillo se listan
 *       comenzando desde la posición 1.</li>
 *   <li>{@link #distinctSymbols()} devuelve el número de colores distintos
 *       actualmente visibles (es decir, colores distintos en {@link #configuration()}).</li>
 *   <li><b>Ciclo 2:</b> {@link #lock(int)} bloquea lo que muestra un rodillo.
 *       Un rodillo bloqueado no puede ser modificado por {@link #spin(int)}, {@link #spin(int,int)},
 *       {@link #placeSymbol(int,String)} o {@link #spin(String[])} hasta que
 *       se desbloquee con {@link #unlock(int)}; {@link #spin()} (todos los rodillos)
 *       simplemente omite los rodillos bloqueados en lugar de fallar. El bloqueo no
 *       impide {@link #addSymbol}/{@link #delSymbol} (estos gestionan qué
 *       símbolos existen, no cuál se muestra) ni {@link #swap(int,int)}
 *       (el intercambio solo cambia la posición de una rueda, no su símbolo).</li>
 *   <li><b>Ciclo 2:</b> {@link #spin(String[])} funciona bajo el principio de «todo o nada»: cada
 *       rueda se valida antes de que se modifique cualquiera de ellas.</li>
 * </ul>
 *
 * @author  Jose Luis Garzón - Javier Vargas  - Proyecto Inicial Ciclo 1
 * @version 1.0
 
 */
public class SlotMachine{

    private final List<Wheel> wheels;
    private boolean visible;
    private boolean ok;

    /**
     * Crea una nueva máquina tragamonedas sin rodillos, invisible por defecto.
     */
    public SlotMachine(){
        wheels = new ArrayList<Wheel>();
        visible = false;
        ok = true;
    }

    /**
     * Añade una rueda nueva y vacía en la posición indicada. @param pos Posición (basada en 1) para la nueva rueda.
     */
    public void addWheel(int pos){
        int p = clamp(pos, 1, wheels.size() + 1);
        Wheel wheel = new Wheel(p);
        wheels.add(p - 1, wheel);
        relocateAll();
        if(visible){
            wheel.makeVisible();
        }
        updateWinState();
        ok = true;
    }

    /**
     * * Elimina la rueda en la posición indicada.
     * @param pos Posición (basada en 1) de la rueda que se va a eliminar.
    
     */
    public void delWheel(int pos){
        if(wheels.isEmpty()){
            fail("No hay ruedas para eliminar.");
            return;
        }
        int p = clamp(pos, 1, wheels.size());
        Wheel wheel = wheels.remove(p - 1);
        wheel.delete();
        relocateAll();
        updateWinState();
        ok = true;
    }

    /**
     * Añade un nuevo símbolo (color) a la rueda en la posición indicada.
     * @param pos posición de la rueda de destino (basada en índice 1)
     * @param color nombre de color CSS para el nuevo símbolo
     */
    public void addSymbol(int pos, String color){
        if(wheels.isEmpty()){
            fail("No hay ruedas a las cuales agregar un símbolo.");
            return;
        }
        Wheel wheel = wheels.get(clamp(pos, 1, wheels.size()) - 1);
        if(color == null || color.isBlank()){
            fail("El color del símbolo no puede estar vacío.");
            return;
        }
        if(wheel.containsSymbol(color)){
            fail("Esa rueda ya tiene un símbolo de ese color.");
            return;
        }
        wheel.addSymbol(color);
        updateWinState();
        ok = true;
    }

    /**
     * Elimina el símbolo (color) especificado de todas las ruedas en las que aparezca.
     * @param symbol un nombre de color CSS que identifica el símbolo a eliminar
     */
    public void delSymbol(String symbol){
        boolean removedAny = false;
        for(Wheel wheel : wheels){
            if(wheel.removeSymbol(symbol)){
                removedAny = true;
            }
        }
        if(!removedAny){
            fail("Ninguna rueda tiene un símbolo de ese color.");
            return;
        }
        updateWinState();
        ok = true;
    }

    /**
     * Haz que la rueda indicada muestre un símbolo (color) específico en su ventana.
     * @param wheel posición de la rueda objetivo (basada en índice 1)
     * @param symbol nombre de color CSS que ya debe existir en dicha rueda
     */
    public void placeSymbol(int wheel, String symbol){
        if(wheels.isEmpty()){
            fail("No hay ruedas en la máquina.");
            return;
        }
        Wheel target = wheels.get(clamp(wheel, 1, wheels.size()) - 1);
        if(target.isLocked()){
            fail("Esa rueda está fija (lock); suéltela antes de cambiar su símbolo.");
            return;
        }
        if(!target.placeSymbol(symbol)){
            fail("Esa rueda no tiene un símbolo de ese color.");
            return;
        }
        updateWinState();
        ok = true;
    }

    /**
     * * Gira una sola rueda hasta obtener un símbolo aleatorio.
     * @param wheel Posición de la rueda a girar (basada en índice 1)
    
     */
    public void spin(int wheel){
        if(wheels.isEmpty()){
            fail("No hay ruedas para girar.");
            return;
        }
        Wheel target = wheels.get(clamp(wheel, 1, wheels.size()) - 1);
        if(target.isLocked()){
            fail("Esa rueda está fija (lock); suéltela antes de girarla.");
            return;
        }
        if(!target.spin()){
            fail("Esa rueda no tiene símbolos para girar.");
            return;
        }
        updateWinState();
        ok = true;
    }

    /**
     * Rotate a single wheel by an exact number of steps (Ciclo 2, requisito 11).
     * A positive value rotates forward, a negative value rotates backward.
     * If the simulator is visible, the movement is shown step by step.
     * @param wheel 1-based position of the wheel to rotate
     * @param steps number of positions to rotate (may be negative)
     */
    public void spin(int wheel, int steps){
        if(wheels.isEmpty()){
            fail("No hay ruedas para girar.");
            return;
        }
        Wheel target = wheels.get(clamp(wheel, 1, wheels.size()) - 1);
        if(target.isLocked()){
            fail("Esa rueda está fija (lock); suéltela antes de girarla.");
            return;
        }
        if(!target.rotate(steps)){
            fail("Esa rueda no tiene símbolos para girar.");
            return;
        }
        updateWinState();
        ok = true;
    }

    /**
     * Dejar la máquina mostrando una configuración exacta en una sola operación (Ciclo 2,
     * requisito 12). La operación es de todo o nada: si alguna rueda no puede
     * mostrar el símbolo solicitado (símbolo ausente o rueda bloqueada que
     * debería cambiar), no se modifica nada.
     * @param setSymbols un color objetivo por rueda, de izquierda a derecha
     */
    public void spin(String[] setSymbols){
        if(setSymbols == null || setSymbols.length != wheels.size()){
            fail("La configuración dada no coincide con el número de ruedas.");
            return;
        }
        for(int i = 0; i < wheels.size(); i++){
            Wheel wheel = wheels.get(i);
            String target = setSymbols[i];
            if(!wheel.containsSymbol(target)){
                fail("La rueda " + (i + 1) + " no tiene un símbolo de ese color.");
                return;
            }
            if(wheel.isLocked() && !target.equals(wheel.currentColor())){
                fail("La rueda " + (i + 1) + " está fija (lock) en otro símbolo.");
                return;
            }
        }
        for(int i = 0; i < wheels.size(); i++){
            wheels.get(i).placeSymbol(setSymbols[i]);
        }
        updateWinState();
        ok = true;
    }

    public void spin(){
        if(wheels.isEmpty()){
            fail("No hay ruedas para girar.");
            return;
        }
        for(Wheel wheel : wheels){
            if(!wheel.isLocked()){
                wheel.spin();
            }
        }
        updateWinState();
        ok = true;
    }

    /**
     * Intercambia las posiciones de dos ruedas (Ciclo 2, requisito 9). Las
     * ruedas conservan sus propios símbolos y estado de bloqueo; solo cambia su posición
     * (y, por tanto, su ubicación en pantalla).
     * @param wheel1 Posición de la primera rueda (basada en índice 1)
     * @param wheel2 Posición de la segunda rueda (basada en índice 1)
     */
    public void swap(int wheel1, int wheel2){
        if(wheels.size() < 2){
            fail("Se necesitan al menos 2 ruedas para intercambiar.");
            return;
        }
        int p1 = clamp(wheel1, 1, wheels.size());
        int p2 = clamp(wheel2, 1, wheels.size());
        Wheel temp = wheels.get(p1 - 1);
        wheels.set(p1 - 1, wheels.get(p2 - 1));
        wheels.set(p2 - 1, temp);
        relocateAll();
        updateWinState();
        ok = true;
    }

    /**
     * Bloquea (fija) una rueda de modo que su símbolo visible no pueda ser modificado por
     * {@link #spin}, {@link #placeSymbol} o {@link #spin(String[])}
     * hasta que se desbloquee mediante {@link #unlock} (Ciclo 2, requisito 10).
     * @param wheel posición de la rueda a bloquear (basada en índice 1)
     */
    public void lock(int wheel){
        if(wheels.isEmpty()){
            fail("No hay ruedas para fijar.");
            return;
        }
        wheels.get(clamp(wheel, 1, wheels.size()) - 1).lock();
        ok = true;
    }

    /**
     * Libera una rueda previamente fijada.
     * @param wheel Posición (basada en 1) de la rueda que se va a liberar.
     */
    public void unlock(int wheel){
        if(wheels.isEmpty()){
            fail("No hay ruedas para soltar.");
            return;
        }
        wheels.get(clamp(wheel, 1, wheels.size()) - 1).unlock();
        ok = true;
    }

    /**
     * @return los colores de cada símbolo definido en la máquina, rueda por
     * rueda; los símbolos de cada rueda se enumeran comenzando en la posición 1
     */
    public String[] symbols(){
        List<String> all = new ArrayList<String>();
        for(Wheel wheel : wheels){
            for(String color : wheel.getColors()){
                all.add(color);
            }
        }
        ok = true;
        return all.toArray(new String[0]);
    }

    /**
     * @return el número de colores distintos actualmente visibles en la máquina
     */
    public int distinctSymbols(){
        ok = true;
        return new HashSet<String>(java.util.Arrays.asList(configuration())).size();
    }

    /**
     *@return los colores de los símbolos visibles en todos los rodillos, ordenados
     *         de izquierda a derecha
     */
    public String[] configuration(){
        String[] cfg = new String[wheels.size()];
        for(int i = 0; i < wheels.size(); i++){
            cfg[i] = wheels.get(i).currentColor();
        }
        ok = true;
        return cfg;
    }

    /**
     * @return true si la máquina tiene al menos una rueda y todas las ruedas
     *         muestran el mismo símbolo no nulo.     */
    public boolean isJackpot(){
        ok = true;
        return currentIsJackpot();
    }

    /** Hace visible todo el simulador (y cada rueda). */
    public void makeVisible(){
        visible = true;
        for(Wheel wheel : wheels){
            wheel.makeVisible();
        }
        updateWinState();
        ok = true;
    }

    /** Haz que todo el simulador (y cada rueda) sea invisible. */
    public void makeInvisible(){
        visible = false;
        for(Wheel wheel : wheels){
            wheel.makeInvisible();
        }
        ok = true;
    }

    /**
     ** Finalizar el simulador: oculta y muestra todos los elementos visuales.

     * (Cerrar la ventana completa de la aplicación, si corresponde, es una decisión que se deja
     * al controlador/interfaz de usuario que se desarrollará en un ciclo futuro).
     */
    public void exit(){
        makeInvisible();
        wheels.clear();
        ok = true;
    }

    /** @return true si la última operación invocada en este objeto se realizó correctamente */
    public boolean ok(){
        return ok;
    }

    /* ------------------------- private helpers ------------------------- */

    private boolean currentIsJackpot(){
        if(wheels.isEmpty()){
            return false;
        }
        String first = wheels.get(0).currentColor();
        if(first == null){
            return false;
        }
        for(Wheel wheel : wheels){
            if(!first.equals(wheel.currentColor())){
                return false;
            }
        }
        return true;
    }

    private void relocateAll(){
        for(int i = 0; i < wheels.size(); i++){
            wheels.get(i).relocate(i + 1);
        }
    }

    private void updateWinState(){
        boolean win = currentIsJackpot();
        for(Wheel wheel : wheels){
            wheel.setWinning(win);
        }
    }

    private int clamp(int value, int min, int max){
        if(value < min){
            return min;
        }
        if(value > max){
            return max;
        }
        return value;
    }

    private void fail(String message){
        ok = false;
        if(visible){
            JOptionPane.showMessageDialog(null, message, "Slot Machine",
                JOptionPane.WARNING_MESSAGE);
        }
    }
}

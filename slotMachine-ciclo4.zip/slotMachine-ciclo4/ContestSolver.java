import java.util.ArrayList;

/**
 * Resuelve el problema de la maraton (2025 ICPC World Finals, Problem I).
 *
 * El solucionador solo conoce lo que conoceria un concursante: el numero de
 * ruedas n y la respuesta del amigo, es decir, distinctSymbols(). De la
 * maquina usa unicamente spin(wheel, steps) y distinctSymbols(); la maquina
 * se crea afuera con SlotMachine(n) y nunca se hace visible aqui.
 *
 * Idea del algoritmo. Sea a_i el desplazamiento de la rueda i. Si todas las
 * demas ruedas quedan quietas y la rueda i recorre todas las posiciones, el
 * numero de simbolos distintos solo vale k en las posiciones que ya estan
 * ocupadas por otra rueda y k+1 en las demas. Asi, un barrido de n giros
 * revela el conjunto A - a_i de simbolos presentes, medido desde la rueda i.
 *
 * Con el barrido de todas las ruedas se conocen las diferencias a_i - a_1,
 * salvo un posible periodo p (cuando A se repite al desplazarlo p posiciones).
 * Se alinean las ruedas modulo ese periodo y se repite el proceso, pero ahora
 * solo con las posiciones multiplos de p. Si A son todas las posiciones del
 * subgrupo (no hay informacion), se rompe la simetria sacando una rueda de
 * el con un giro de una posicion.
 *
 * Costo: a lo sumo unos 3 n^2 acciones (7500 para n = 50; el limite es 10000).
 */
class ContestSolver
{
    /** Maximo de acciones que acepta la maraton. */
    static final int MAX_ACTIONS = 10000;

    private final SlotMachine machine;
    private final int n;
    private final ArrayList<int[]> actions;
    private int distinct;
    /** Distancia (en posiciones reales) entre las posiciones que se exploran. */
    private int step;
    /** Cantidad de posiciones que se exploran por rueda (n / step). */
    private int size;

    /**
     * Crea un solucionador.
     *
     * @param machine maquina creada con SlotMachine(n), invisible
     * @param n numero de ruedas y de simbolos
     */
    ContestSolver(SlotMachine machine, int n)
    {
        this.machine = machine;
        this.n = n;
        actions = new ArrayList<int[]>();
        step = 1;
        size = n;
    }

    /**
     * Gira ruedas hasta que todas muestren el mismo simbolo.
     *
     * @return acciones {i, j}: girar la rueda i (desde 1) j posiciones,
     *         con 1 <= j <= n - 1
     */
    int[][] solve()
    {
        distinct = machine.distinctSymbols();
        while(distinct > 1 && actions.size() < MAX_ACTIONS)
        {
            boolean[][] seen = explore();
            if(distinct > 1)
            {
                int period = period(seen[0]);
                align(seen, period);
                narrow(period);
            }
        }
        return actions.toArray(new int[0][]);
    }

    /**
     * Barre todas las ruedas y guarda, por rueda, que posiciones estan
     * ocupadas por algun simbolo (visto desde esa rueda). Se detiene si en
     * medio del barrido se gana.
     */
    private boolean[][] explore()
    {
        boolean[][] seen = new boolean[n][];
        for(int wheel = 1; wheel <= n && distinct > 1; wheel++)
        {
            int[] counts = sweep(wheel);
            if(distinct > 1)
            {
                seen[wheel - 1] = occupied(counts);
            }
        }
        return seen;
    }

    /**
     * Gira una rueda por todas sus posiciones (de a step) y la deja donde
     * estaba. counts[r] es el numero de simbolos distintos con la rueda r
     * posiciones adelante.
     */
    private int[] sweep(int wheel)
    {
        int[] counts = new int[size];
        counts[0] = distinct;
        for(int r = 1; r < size && distinct > 1; r++)
        {
            counts[r] = rotate(wheel, step);
        }
        if(distinct > 1)
        {
            rotate(wheel, step);
        }
        return counts;
    }

    /**
     * Posiciones ocupadas por algun simbolo, visto desde la rueda barrida:
     * son las de menor cuenta, y siempre la propia posicion (r = 0).
     */
    private boolean[] occupied(int[] counts)
    {
        int min = counts[0];
        for(int count : counts)
        {
            min = Math.min(min, count);
        }
        boolean[] seen = new boolean[counts.length];
        for(int r = 0; r < counts.length; r++)
        {
            seen[r] = counts[r] == min;
        }
        seen[0] = true;
        return seen;
    }

    /**
     * Menor desplazamiento p > 0 que deja igual el conjunto base, o size si
     * no hay ninguno (conjunto sin periodo).
     */
    private int period(boolean[] base)
    {
        for(int p = 1; p < size; p++)
        {
            if(matches(base, base, p))
            {
                return p;
            }
        }
        return size;
    }

    /**
     * Indica si a[x] == b[x + shift] para toda posicion x (circular).
     */
    private boolean matches(boolean[] a, boolean[] b, int shift)
    {
        for(int x = 0; x < size; x++)
        {
            if(a[x] != b[(x + shift) % size])
            {
                return false;
            }
        }
        return true;
    }

    /**
     * Diferencia (a_i - a_1) / step entre una rueda y la primera, o -1 si no
     * hay. Es unica salvo multiplos del periodo.
     */
    private int offset(boolean[] wheelSet, boolean[] firstSet)
    {
        for(int t = 0; t < size; t++)
        {
            if(matches(wheelSet, firstSet, t))
            {
                return t;
            }
        }
        return -1;
    }

    /**
     * Deja todas las ruedas igual que la primera, salvo multiplos del periodo.
     * Como el resultado no cambia en un multiplo del periodo, se gira por
     * el camino mas corto.
     */
    private void align(boolean[][] seen, int period)
    {
        for(int wheel = 2; wheel <= n && distinct > 1; wheel++)
        {
            int t = offset(seen[wheel - 1], seen[0]) % period;
            if(t > period / 2)
            {
                t -= period;
            }
            if(t != 0)
            {
                rotate(wheel, -t * step);
            }
        }
    }

    /**
     * Prepara la siguiente ronda. Si hay periodo, se explora solo en el
     * subgrupo de posiciones multiplos del periodo. Si no hay informacion
     * (periodo 1: estan todas las posiciones), se rompe la simetria
     * girando una posicion la primera rueda y se vuelve a explorar todo.
     */
    private void narrow(int period)
    {
        if(distinct == 1 || period == size)
        {
            return;
        }
        if(period == 1)
        {
            rotate(1, 1);
            step = 1;
            size = n;
        }
        else
        {
            step = step * period;
            size = size / period;
        }
    }

    /**
     * Ejecuta una accion: gira la rueda j posiciones y consulta cuantos
     * simbolos distintos se ven ahora. La accion se guarda con el giro
     * equivalente entre 1 y n - 1 (nunca negativo ni cero).
     */
    private int rotate(int wheel, int j)
    {
        int steps = Math.floorMod(j, n);
        actions.add(new int[]{wheel, steps});
        machine.spin(wheel, steps);
        distinct = machine.distinctSymbols();
        return distinct;
    }
}

import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

/**
 * Fabrica de simbolos: crea un simbolo a partir del nombre de su tipo.
 *
 * Para ofrecer un tipo nuevo de simbolo solo hay que crear la clase y
 * agregar una linea al registro. SlotMachine no cambia.
 */
class SymbolFactory
{
    private static final Map<String, Function<String, Symbol>> TYPES =
        new HashMap<String, Function<String, Symbol>>();

    static
    {
        TYPES.put("normal", Symbol::new);
        TYPES.put("ephemeral", EphemeralSymbol::new);
        TYPES.put("shy", ShySymbol::new);
    }

    private SymbolFactory()
    {
    }

    /**
     * Indica si el tipo de simbolo existe.
     *
     * @param type nombre del tipo (no distingue mayusculas)
     * @return true si existe
     */
    static boolean exists(String type)
    {
        return type != null && TYPES.containsKey(type.trim().toLowerCase());
    }

    /**
     * Crea un simbolo del tipo indicado.
     *
     * @param type nombre del tipo
     * @param color color CSS del simbolo
     * @return el simbolo, o null si el tipo no existe
     */
    static Symbol create(String type, String color)
    {
        if(!exists(type))
        {
            return null;
        }
        return TYPES.get(type.trim().toLowerCase()).apply(color);
    }
}

import static org.junit.Assert.*;
import org.junit.Test;

/**
 * Pruebas de unidad compartidas del ciclo 4 (creacion colectiva en el wiki).
 *
 * Cada grupo aporta como minimo dos casos. El nombre de cada prueba lleva la
 * identificacion de los autores (iniciales de los primeros apellidos, mas la
 * primera letra del segundo, en orden alfabetico). Todas usan la maquina
 * INVISIBLE.
 *
 * @author (nombres de los autores)
 * @version (fecha)
 */
public class SlotMachineCC4Test
{
    @Test
    public void accordingGarzonVargasShouldNotLetARebelWheelBeLockedSwappedOrDeleted()
    {
        SlotMachine machine = new SlotMachine();
        machine.addWheel("rebel", 1);
        machine.addWheel("normal", 2);
        machine.lock(1);
        assertFalse(machine.ok());
        machine.swap(1, 2);
        assertFalse(machine.ok());
        machine.delWheel(1);
        assertFalse(machine.ok());
        assertArrayEquals(new String[]{"rebel", "normal"}, machine.wheelTypes());
    }

    @Test
    public void accordingGarzonVargasShouldMakeALeftyWheelCopyItsLeftNeighbor()
    {
        SlotMachine machine = new SlotMachine();
        machine.addWheel("normal", 1);
        machine.addWheel("lefty", 2);
        for(String color : new String[]{"red", "green", "blue"})
        {
            machine.addSymbol(1, color);
            machine.addSymbol(2, color);
        }
        machine.spin(1, 2);                   // la rueda 1 muestra blue
        machine.spin(2);                      // la zurda copia a blue
        assertArrayEquals(new String[]{"blue", "blue"}, machine.configuration());
        assertTrue(machine.isJackpot());
    }
}

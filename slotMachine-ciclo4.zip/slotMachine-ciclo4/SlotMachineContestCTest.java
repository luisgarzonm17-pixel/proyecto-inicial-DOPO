import static org.junit.Assert.*;
import org.junit.Assume;
import org.junit.Ignore;
import org.junit.Test;
import java.awt.GraphicsEnvironment;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/**
 * Pruebas de unidad compartidas del ciclo 3 (creacion colectiva).
 *
 * Reune las pruebas propuestas por todos los grupos, adaptadas a JUnit 4 y a
 * la API real (solve devuelve int[][]; SlotMachine(n) es aleatoria). El nombre
 * de cada prueba conserva la identificacion de su grupo.
 *
 * Las pruebas que llaman a simulate abren el lienzo, asi que solo se ejecutan
 * si hay pantalla (en un entorno sin pantalla se omiten). Las demas usan la
 * maquina invisible.
 *
 * Las pruebas marcadas con @Ignore se contradicen con el enunciado o con otras
 * pruebas del curso (ver el motivo en cada una y docs/PRUEBAS_COMPARTIDAS.md).
 *
 * @author (nombres de los autores)
 * @version (fecha)
 */
public class SlotMachineContestCTest
{
    private static final int LIMIT = 10000;
    private SlotMachineContest contest = new SlotMachineContest();

    private void needsScreen()
    {
        Assume.assumeFalse(GraphicsEnvironment.isHeadless());
    }

    // ===================================================== nuestro grupo

    /** Reproduce la "Sample Interaction 2" del enunciado de la maraton. */
    @Test
    public void accordingGarzonVargasShouldWinWithTheContestSampleInteraction()
    {
        SlotMachine machine = new SlotMachine(3);
        String[] colors = Arrays.copyOf(machine.symbols(), 3);
        machine.spin(new String[]{colors[0], colors[2], colors[1]});
        assertEquals(3, machine.distinctSymbols());
        machine.spin(2, Math.floorMod(-1, 3));
        assertEquals(2, machine.distinctSymbols());
        machine.spin(3, Math.floorMod(-1, 3));
        assertEquals(2, machine.distinctSymbols());
        machine.spin(2, Math.floorMod(-1, 3));
        assertEquals(1, machine.distinctSymbols());
        assertTrue(machine.isJackpot());
    }

    @Test
    public void accordingGarzonVargasShouldFinishWithEveryWheelShowingTheSameSymbol()
    {
        SlotMachine machine = new SlotMachine(10);
        SlotMachineContest.solve(10, machine);
        String[] shown = machine.configuration();
        assertEquals(10, shown.length);
        for(String symbol : shown)
        {
            assertEquals(shown[0], symbol);
        }
    }

    @Test
    public void accordingGarzonVargasShouldNotChangeWheelsOrSymbolsWhileSolving()
    {
        SlotMachine machine = new SlotMachine(7);
        String[] before = machine.symbols();
        SlotMachineContest.solve(7, machine);
        assertArrayEquals(before, machine.symbols());
        assertTrue(machine.ok());
    }

    // ===================================================== CardozoB-DiazB

    /** Una maquina de una rueda ya gana: se resuelve sin mover nada. */
    @Test
    public void shouldSolveAMachineWithOneWheel()
    {
        int[][] actions = contest.solve(1);
        assertEquals(1, contest.getMachine().distinctSymbols());
        assertEquals(0, actions.length);
    }

    @Ignore("Contradice a CortazarJ-MartinezC: con n ruedas y n simbolos por "
          + "rueda, symbols() devuelve n*n colores (n=5 -> 25), no n.")
    @Test
    public void shouldCreateAMachineWithAsManySymbolsAsWheels()
    {
        int n = 5;
        contest.solve(n);
        assertEquals(n, contest.getMachine().symbols().length);
    }

    // ===================================================== IbarraC-PovedaG

    @Test
    public void accordingIcPgShouldStayUnderActionLimit()
    {
        int[][] actions = SlotMachineContest.solve(50);
        assertTrue("Used " + actions.length + " actions, exceeds the 10000 limit",
                   actions.length <= LIMIT);
    }

    // ===================================================== GomezB-CarreroC

    @Ignore("Es imposible: gana con n acciones solo si se conoce de antemano "
          + "la configuracion; la maraton obliga a explorar con distinctSymbols().")
    @Test
    public void accordingCcGbShouldtestSolveNumberOfMovements()
    {
        int[][] solution = SlotMachineContest.solve(5);
        assertEquals(5, solution.length);
    }

    @Ignore("Contradice el enunciado: SlotMachine(n) se inicializa al azar y "
          + "nunca en estado ganador, asi que no puede mostrar todo 'red'.")
    @Test
    public void accordingCcGbShouldtestAllWheelsHaveSameSymbolOrder()
    {
        String[] configuration = new SlotMachine(3).configuration();
        assertEquals("red", configuration[0]);
        assertEquals("red", configuration[1]);
        assertEquals("red", configuration[2]);
    }

    // ===================================================== CortazarJ-MartinezC

    @Test
    public void accordingCjMcShouldCreateEqualWheelsAndSymbolsPerWheel()
    {
        SlotMachine sm = new SlotMachine(5);
        assertEquals(5, sm.configuration().length);
        assertEquals(25, sm.symbols().length);
    }

    @Ignore("Es imposible en general: sin conocer la configuracion hay que "
          + "explorar con distinctSymbols(), y eso cuesta mas de n acciones.")
    @Test
    public void accordingCjMcShouldProposeAtMostOneActionPerValidWheel()
    {
        int n = 4;
        int[][] actions = SlotMachineContest.solve(n);
        assertTrue(actions.length <= n);
        for(int[] action : actions)
        {
            assertTrue(action[0] >= 1 && action[0] <= n);
        }
    }

    // ===================================================== CarreñoG-CastañoP

    @Test
    public void carrenoCastanoShouldOnlyUseExistingWheels()
    {
        int n = 8;
        for(int[] action : SlotMachineContest.solve(n))
        {
            assertTrue(action[0] >= 1 && action[0] <= n);
        }
    }

    @Test
    public void carrenoCastanoShouldNotIncludeZeroStepActions()
    {
        for(int[] action : SlotMachineContest.solve(8))
        {
            assertNotEquals(0, action[1]);
        }
    }

    @Test
    public void carrenoCastanoShouldNotExceedTheActionLimit()
    {
        assertTrue(SlotMachineContest.solve(50).length <= LIMIT);
    }

    // ===================================================== CañonA-PaezP

    @Test
    public void accordingCaPpshouldReturnValidMovesStructure()
    {
        int[][] moves = contest.solve(3);
        assertNotNull(moves);
        for(int[] move : moves)
        {
            assertEquals(2, move.length);
        }
    }

    @Test
    public void accordingCaPpshouldRunSimulationWithoutErrors()
    {
        needsScreen();
        contest.simulate(3);
    }

    // ===================================================== Murillo

    @Test
    public void accordingMurtestSolveWhenAlreadyJackpot()
    {
        assertNotNull(SlotMachineContest.solve(4));
    }

    @Test
    public void accordingMurtestSolveDontHaceSpin0()
    {
        int n = 4;
        int[][] moves = SlotMachineContest.solve(n);
        assertNotNull(moves);
        assertTrue("Se supero el limite maximo de 10,000 acciones para n = " + n,
                   moves.length <= LIMIT);
        for(int[] move : moves)
        {
            assertNotEquals(0, move[1]);
        }
    }

    // ===================================================== BustosL-GomezG

    @Test
    public void accordingSharedShouldNotHaveNegativeSteps()
    {
        for(int[] move : SlotMachineContest.solve(5))
        {
            assertTrue(move[1] >= 0);
        }
    }

    @Ignore("Contradice a CardozoB-DiazB y CuervoC-InfanteC: una maquina de una "
          + "sola rueda ya gana, asi que la solucion no tiene ninguna accion.")
    @Test
    public void accordingSharedShouldSolveOneWheelMachine()
    {
        int[][] solution = SlotMachineContest.solve(1);
        assertNotNull(solution);
        assertEquals(1, solution.length);
        assertEquals(1, solution[0][0]);
    }

    // ===================================================== DiazR-RojasM

    @Test
    public void accordingDrRmShouldReturnNonEmptyMovesWhenNotInJackpot()
    {
        int n = 4;
        SlotMachine sM = new SlotMachine(n);
        int[][] moves = SlotMachineContest.solve(n);
        if(!sM.isJackpot())
        {
            assertTrue(moves.length > 0);
        }
    }

    @Test
    public void accordingDrRmShouldNotCreateWheelAndSymbolWithNegativeNumber()
    {
        SlotMachine sM = new SlotMachine(-3);
        assertEquals(0, sM.configuration().length);
        assertEquals(0, sM.symbols().length);
    }

    // ===================================================== ForeroM-SalinasN

    @Ignore("Es imposible: la cantidad de acciones depende de la configuracion "
          + "inicial; no hay una solucion de exactamente n acciones para todo n.")
    @Test
    public void shouldWorkforEveryWhee()
    {
        for(int n : new int[]{6, 3, 4})
        {
            assertEquals(n, SlotMachineContest.solve(n).length);
        }
    }

    // ===================================================== CuervoC-InfanteC

    @Test
    public void accordingCcIcsolveShouldReturnAnEmptyPlanForOneWheel()
    {
        int[][] result = contest.solve(1);
        assertNotNull(result);
        assertEquals(0, result.length);
    }

    @Ignore("Depende de una solucion particular: obliga a que TODA accion gire "
          + "exactamente 1 paso. El enunciado permite cualquier j entre -10^9 y 10^9.")
    @Test
    public void accordingCcIcsolveShouldReturnActionsWithValidWheelAndStepValues()
    {
        for(int[] action : contest.solve(3))
        {
            assertEquals(2, action.length);
            assertTrue(action[0] >= 1 && action[0] <= 3);
            assertEquals(1, action[1]);
        }
    }

    // ===================================================== DavilaO-OrozcoL

    @Test
    public void accordingDoOlshouldNotRunAndReturnEmptyWhenLessThanThreeWheels()
    {
        int[][] actions = contest.solve(2);
        assertNotNull("El resultado no debe ser nulo", actions);
        assertEquals("con menos de 3 ruedas no se corre: 0 acciones", 0, actions.length);
    }

    @Test
    public void accordingDoOlsolverShouldScaleEfficientlyWithMaximumWheels()
    {
        int[][] actions = contest.solve(50);
        assertTrue("El escalado fallo para N=50", actions.length <= LIMIT);
    }

    // ===================================================== BUSTOS-ZORRO

    @Ignore("Contradice a CortazarJ-MartinezC: symbols() devuelve n*n colores "
          + "(n por rueda), no n en total.")
    @Test
    public void bustosZorroShouldCreateAMachineWithAsManySymbolsAsWheels()
    {
        int n = 5;
        contest.solve(n);
        assertEquals(n, contest.getMachine().symbols().length);
    }

    @Test
    public void shouldCreateAMachineWithDifferentColors()
    {
        int n = 5;
        contest.solve(n);
        Set<String> colors = new HashSet<String>(
            Arrays.asList(contest.getMachine().symbols()));
        assertEquals(n, colors.size());
    }

    // ===================================================== Quintero-Rodriguez

    @Test
    public void shouldSolveThreeWheels()
    {
        int[][] solution = contest.solve(3);
        assertNotNull(solution);
        assertTrue(solution.length > 0);
    }

    @Test
    public void shouldSimulateThreeWheels()
    {
        needsScreen();
        contest.solve(3);
        contest.simulate(3);
    }

    // ===================================================== GonzalezM-LesmesA

    @Test
    public void accordingGmLaShouldExecuteSimulationSuccessfullyForMediumSize()
    {
        needsScreen();
        SlotMachineContest.simulate(5);
    }

    @Test
    public void accordingGmLaShouldReturnValidStructureForMaximumWheels()
    {
        int[][] actions = SlotMachineContest.solve(50);
        assertNotNull("el arreglo de acciones para 50 ruedas no debe ser nulo", actions);
        for(int[] action : actions)
        {
            assertEquals("cada accion debe tener exactamente dos elementos", 2, action.length);
        }
    }
}

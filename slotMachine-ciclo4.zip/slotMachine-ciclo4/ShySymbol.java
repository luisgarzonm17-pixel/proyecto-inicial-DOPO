/**
 * Simbolo timido: cada vez que la rueda lo selecciona alterna entre visible
 * e invisible. Se dibuja como un cuadrado. Mientras esta invisible, la rueda
 * no muestra ningun simbolo y no aporta color a la configuracion.
 */
public class ShySymbol extends Symbol
{
    private boolean visible;

    /**
     * Crea un simbolo timido, visible.
     *
     * @param color color CSS del simbolo
     */
    public ShySymbol(String color)
    {
        super(color);
        visible = true;
    }

    @Override
    public String getKind()
    {
        return "shy";
    }

    @Override
    public boolean isVisible()
    {
        return visible;
    }

    @Override
    public SymbolShape getShape()
    {
        return SymbolShape.SQUARE;
    }

    @Override
    public void select(int times)
    {
        if(times % 2 != 0)
        {
            visible = !visible;
        }
    }
}

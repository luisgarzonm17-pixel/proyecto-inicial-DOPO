/**
 * Solucion y simulacion del problema de la maraton "Slot Machine"
 * (2025 ICPC World Finals, Problem I).
 *
 * La maquina tiene n ruedas y n simbolos, inicializada al azar. SlotMachine
 * se usa aqui como la testing tool de la maraton: para resolver solo se
 * emplean SlotMachine(n), spin(wheel, steps) y distinctSymbols(). Para
 * simular solo se agregan makeVisible() y makeInvisible().
 *
 * La maquina permanece invisible en solve y es visible en simulate.
 */
public class SlotMachineContest
{
    /** Minimo y maximo de ruedas del problema de la maraton. */
    private static final int MIN_WHEELS = 3;
    private static final int MAX_WHEELS = 50;
    /** Ruedas que caben en el lienzo (900 px de ancho, 90 px por rueda). */
    private static final int MAX_VISIBLE_WHEELS = 8;

    /** Ultima maquina usada por solve o simulate. */
    private static SlotMachine lastMachine;

    /**
     * Resuelve el problema para una maquina nueva de n ruedas y n simbolos,
     * inicializada al azar. La maquina permanece invisible.
     *
     * @param n numero de ruedas y de simbolos
     * @return acciones {i, j} necesarias para ganar: girar la rueda i
     *         (desde 1) j posiciones, con 1 <= j <= n - 1. Si n esta fuera
     *         del problema (3 a 50) no se ejecuta nada y se devuelve vacio
     */
    public static int[][] solve(int n)
    {
        return solve(n, new SlotMachine(n));
    }

    /**
     * Resuelve el problema sobre una maquina ya creada con SlotMachine(n).
     * Al terminar la maquina queda en estado ganador.
     *
     * @param n numero de ruedas y de simbolos de la maquina
     * @param machine maquina creada con SlotMachine(n), invisible
     * @return acciones {i, j} necesarias para ganar
     */
    public static int[][] solve(int n, SlotMachine machine)
    {
        lastMachine = machine;
        if(n < MIN_WHEELS || n > MAX_WHEELS)
        {
            return new int[0][];
        }
        return new ContestSolver(machine, n).solve();
    }

    /**
     * Consulta la ultima maquina que uso solve o simulate.
     *
     * @return la maquina, o null si aun no se ha usado ninguna
     */
    public SlotMachine getMachine()
    {
        return lastMachine;
    }

    /**
     * Indica si una maquina de n ruedas cabe en el lienzo para simularla.
     *
     * @param n numero de ruedas
     * @return true si 3 <= n <= 8
     */
    public static boolean canSimulate(int n)
    {
        return n >= MIN_WHEELS && n <= MAX_VISIBLE_WHEELS;
    }

    /**
     * Simula la solucion mostrando, rueda por rueda, el giro neto que lleva
     * la maquina de su configuracion inicial a la ganadora. Si no cabe en
     * el lienzo (ver canSimulate) no hace nada.
     *
     * @param n numero de ruedas y de simbolos
     */
    public static void simulate(int n)
    {
        simulate(n, false);
    }

    /**
     * Simula la solucion. Se resuelve con la maquina invisible, se devuelve
     * la maquina a su configuracion inicial, se hace visible y se repite.
     *
     * @param n numero de ruedas y de simbolos
     * @param everyAction true para mostrar todas las acciones de solve
     *        (incluidas las de exploracion); false para mostrar solo el
     *        giro neto de cada rueda
     */
    public static void simulate(int n, boolean everyAction)
    {
        if(!canSimulate(n))
        {
            System.out.println("No se puede simular: el lienzo solo permite "
                + "de " + MIN_WHEELS + " a " + MAX_VISIBLE_WHEELS + " ruedas.");
            return;
        }
        SlotMachine machine = new SlotMachine(n);
        int[][] actions = solve(n, machine);
        int[] net = netRotation(actions, n);
        rewind(machine, net, n);
        machine.makeVisible();
        if(everyAction)
        {
            replay(machine, actions, n);
        }
        else
        {
            replay(machine, net);
        }
    }

    /**
     * Giro neto de cada rueda (entre 0 y n - 1) al aplicar todas las acciones.
     */
    private static int[] netRotation(int[][] actions, int n)
    {
        int[] net = new int[n];
        for(int[] action : actions)
        {
            net[action[0] - 1] = (net[action[0] - 1]
                                  + Math.floorMod(action[1], n)) % n;
        }
        return net;
    }

    /**
     * Devuelve la maquina (invisible) a su configuracion inicial deshaciendo
     * el giro neto de cada rueda.
     */
    private static void rewind(SlotMachine machine, int[] net, int n)
    {
        for(int wheel = 1; wheel <= n; wheel++)
        {
            if(net[wheel - 1] > 0)
            {
                machine.spin(wheel, n - net[wheel - 1]);
            }
        }
    }

    /**
     * Aplica el giro neto de cada rueda, de izquierda a derecha.
     */
    private static void replay(SlotMachine machine, int[] net)
    {
        for(int wheel = 1; wheel <= net.length; wheel++)
        {
            if(net[wheel - 1] > 0)
            {
                machine.spin(wheel, net[wheel - 1]);
            }
        }
    }

    /**
     * Aplica una por una todas las acciones de la solucion.
     */
    private static void replay(SlotMachine machine, int[][] actions, int n)
    {
        for(int[] action : actions)
        {
            machine.spin(action[0], Math.floorMod(action[1], n));
        }
    }
}

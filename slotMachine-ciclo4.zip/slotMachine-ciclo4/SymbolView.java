/**
 * Dibujo del simbolo que muestra una rueda. Tiene un circulo, un cuadrado y
 * un triangulo (de shapes) y muestra solo el que corresponde a la figura del
 * simbolo actual, centrado en su casilla y con su color y tamano.
 */
class SymbolView
{
    // Posicion por omision de las figuras de shapes al crearse.
    private static final int CIRCLE_X = 20, CIRCLE_Y = 15;
    private static final int SQUARE_X = 70, SQUARE_Y = 15;
    private static final int TRIANGLE_X = 140, TRIANGLE_Y = 15;

    private Circle circle = new Circle();
    private Rectangle square = new Rectangle();
    private Triangle triangle = new Triangle();
    private int circleX = CIRCLE_X, circleY = CIRCLE_Y;
    private int squareX = SQUARE_X, squareY = SQUARE_Y;
    private int triangleX = TRIANGLE_X, triangleY = TRIANGLE_Y;
    private int left;
    private int top;
    private boolean drawn;

    /**
     * Crea el dibujo, invisible.
     *
     * @param left coordenada x de la casilla del simbolo
     * @param top coordenada y de la casilla del simbolo
     */
    SymbolView(int left, int top)
    {
        this.left = left;
        this.top = top;
        drawn = false;
    }

    /**
     * Mueve la casilla a la derecha (o izquierda si es negativo).
     * No redibuja: se debe llamar a render despues.
     *
     * @param distance pixeles que se mueve
     */
    void moveBox(int distance)
    {
        left += distance;
    }

    /**
     * Dibuja el simbolo, o borra el dibujo si no hay nada que mostrar.
     *
     * @param symbol simbolo a mostrar, o null si la rueda esta vacia
     * @param wheelVisible true si la rueda esta visible
     */
    void render(Symbol symbol, boolean wheelVisible)
    {
        if(!wheelVisible || symbol == null || !symbol.isVisible())
        {
            hide();
            return;
        }
        hide();
        int size = symbol.getSize();
        int x = left + (Symbol.FULL_SIZE - size) / 2;
        int y = top + (Symbol.FULL_SIZE - size) / 2;
        String color = symbol.getColor();
        switch(symbol.getShape())
        {
            case SQUARE:
                square.moveHorizontal(x - squareX);
                square.moveVertical(y - squareY);
                squareX = x;
                squareY = y;
                square.changeSize(size, size);
                square.changeColor(color);
                square.makeVisible();
                break;
            case TRIANGLE:
                triangle.moveHorizontal(x + size / 2 - triangleX);
                triangle.moveVertical(y - triangleY);
                triangleX = x + size / 2;
                triangleY = y;
                triangle.changeSize(size, size);
                triangle.changeColor(color);
                triangle.makeVisible();
                break;
            default:
                circle.moveHorizontal(x - circleX);
                circle.moveVertical(y - circleY);
                circleX = x;
                circleY = y;
                circle.changeSize(size);
                circle.changeColor(color);
                circle.makeVisible();
                break;
        }
        drawn = true;
    }

    /**
     * Borra del lienzo las tres figuras.
     */
    void hide()
    {
        if(drawn)
        {
            circle.makeInvisible();
            square.makeInvisible();
            triangle.makeInvisible();
            drawn = false;
        }
    }
}

import java.util.ArrayList;

/**
 * Decoracion de la maquina tragamonedas: luces en la parte superior, una
 * palanca al lado derecho y una base con bandeja de premios.
 *
 * Se construye con las figuras de shapes (Rectangle y Circle) y se ajusta al
 * ancho del cuerpo de la maquina. Cuando la maquina gana, las luces y la
 * perilla de la palanca cambian de color.
 */
class MachineDecor
{
    // Posicion por omision de las figuras de shapes al crearse.
    private static final int DEFAULT_RECT_X = 70;
    private static final int DEFAULT_RECT_Y = 15;
    private static final int DEFAULT_CIRCLE_X = 20;
    private static final int DEFAULT_CIRCLE_Y = 15;

    /** Posicion del cuerpo de la maquina (la misma de su Rectangle). */
    private static final int BODY_X = 70;
    private static final int BODY_Y = 15;

    private static final int LIGHT_SIZE = 12;
    private static final int LIGHT_Y = BODY_Y + 11;
    private static final int MIN_LIGHTS = 4;
    private static final int MAX_LIGHTS = 8;
    private static final String[] LIGHTS = {"yellow", "orange"};
    private static final String[] LIGHTS_WON = {"white", "red"};
    private static final String KNOB = "red";
    private static final String KNOB_WON = "lime";

    private ArrayList<Rectangle> parts;
    private ArrayList<Circle> lights;
    private Circle knob;
    private int builtWidth;

    /**
     * Crea la decoracion, todavia sin figuras.
     */
    MachineDecor()
    {
        parts = new ArrayList<Rectangle>();
        lights = new ArrayList<Circle>();
        builtWidth = -1;
    }

    /**
     * Dibuja la decoracion para un cuerpo del ancho y alto indicados. Se debe
     * llamar despues de dibujar el cuerpo y antes de dibujar las ruedas.
     *
     * @param bodyWidth ancho del cuerpo de la maquina
     * @param bodyHeight alto del cuerpo de la maquina
     * @param won true si la maquina esta en estado ganador
     */
    void show(int bodyWidth, int bodyHeight, boolean won)
    {
        if(bodyWidth != builtWidth)
        {
            hide();
            build(bodyWidth, bodyHeight);
        }
        paintColors(won);
        for(Rectangle part : parts)
        {
            part.makeVisible();
        }
        knob.makeVisible();
        for(Circle light : lights)
        {
            light.makeVisible();
        }
    }

    /**
     * Borra la decoracion del lienzo.
     */
    void hide()
    {
        for(Rectangle part : parts)
        {
            part.makeInvisible();
        }
        for(Circle light : lights)
        {
            light.makeInvisible();
        }
        if(knob != null)
        {
            knob.makeInvisible();
        }
    }

    /**
     * Crea las figuras: base, bandeja, brazo y palo de la palanca, perilla y
     * luces, repartidas segun el ancho del cuerpo.
     */
    private void build(int width, int height)
    {
        int right = BODY_X + width;
        int bottom = BODY_Y + height;
        parts.clear();
        lights.clear();
        parts.add(rectangle(BODY_X - 12, bottom, width + 24, 18, "dimgray"));
        int tray = Math.min(80, width / 2);
        parts.add(rectangle(BODY_X + (width - tray) / 2, bottom + 5, tray, 8, "black"));
        parts.add(rectangle(right, 95, 14, 8, "gray"));
        parts.add(rectangle(right + 14, 50, 8, 53, "gray"));
        knob = circle(right + 5, 24, 26, KNOB);
        buildLights(width);
        builtWidth = width;
    }

    /**
     * Crea las luces, repartidas de forma pareja a lo ancho del cuerpo.
     */
    private void buildLights(int width)
    {
        int count = Math.max(MIN_LIGHTS, Math.min(MAX_LIGHTS, width / Wheel.STEP + 2));
        for(int i = 0; i < count; i++)
        {
            int center = BODY_X + (2 * i + 1) * width / (2 * count);
            lights.add(circle(center - LIGHT_SIZE / 2, LIGHT_Y, LIGHT_SIZE, LIGHTS[0]));
        }
    }

    /**
     * Pinta las luces alternando dos colores y la perilla segun el estado.
     */
    private void paintColors(boolean won)
    {
        String[] colors = won ? LIGHTS_WON : LIGHTS;
        for(int i = 0; i < lights.size(); i++)
        {
            lights.get(i).changeColor(colors[i % colors.length]);
        }
        knob.changeColor(won ? KNOB_WON : KNOB);
    }

    /**
     * Crea un rectangulo en la posicion absoluta indicada.
     */
    private Rectangle rectangle(int x, int y, int width, int height, String color)
    {
        Rectangle rectangle = new Rectangle();
        rectangle.moveHorizontal(x - DEFAULT_RECT_X);
        rectangle.moveVertical(y - DEFAULT_RECT_Y);
        rectangle.changeSize(height, width);
        rectangle.changeColor(color);
        return rectangle;
    }

    /**
     * Crea un circulo en la posicion absoluta indicada.
     */
    private Circle circle(int x, int y, int diameter, String color)
    {
        Circle circle = new Circle();
        circle.moveHorizontal(x - DEFAULT_CIRCLE_X);
        circle.moveVertical(y - DEFAULT_CIRCLE_Y);
        circle.changeSize(diameter);
        circle.changeColor(color);
        return circle;
    }
}

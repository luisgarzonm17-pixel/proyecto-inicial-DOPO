# Diseño – Ciclo 3 (Solución y simulación del problema de la maratón)

Este documento contiene lo que hay que **agregar al `.asta`** (Astah) y las decisiones de diseño del ciclo.

## 1. Diagrama de clases (agregar a `SlotMachine3.asta`)

```mermaid
classDiagram
    class SlotMachine {
        +SlotMachine()
        +SlotMachine(n : int)
        +addWheel(pos : int) void
        +delWheel(pos : int) void
        +swap(wheel1 : int, wheel2 : int) void
        +lock(wheel : int) void
        +unlock(wheel : int) void
        +addSymbol(pos : int, color : String) void
        +delSymbol(symbol : String) void
        +placeSymbol(wheel : int, symbol : String) void
        +spin(wheel : int) void
        +spin(wheel : int, steps : int) void
        +spin(setSymbols : String[]) void
        +spin() void
        +symbols() String[]
        +distinctSymbols() int
        +configuration() String[]
        +isJackpot() boolean
        +makeVisible() void
        +makeInvisible() void
        +exit() void
        +ok() boolean
        -shuffle(n : int) void
        -PALETTE : String[]
        -RANDOM : Random
        -decor : MachineDecor
    }
    class SlotMachineContest {
        +solve(n : int)$ int[][]
        +solve(n : int, machine : SlotMachine)$ int[][]
        +simulate(n : int)$ void
        +simulate(n : int, everyAction : boolean)$ void
        +canSimulate(n : int)$ boolean
        +getMachine() SlotMachine
        -MIN_WHEELS : int
        -MAX_WHEELS : int
        -MAX_VISIBLE_WHEELS : int
        -lastMachine : SlotMachine
        -netRotation(actions : int[][], n : int)$ int[]
        -rewind(machine : SlotMachine, net : int[], n : int)$ void
        -replay(machine : SlotMachine, net : int[])$ void
        -replay(machine : SlotMachine, actions : int[][], n : int)$ void
    }
    class ContestSolver {
        ~MAX_ACTIONS : int
        -n : int
        -distinct : int
        -step : int
        -size : int
        -actions : ArrayList~int[]~
        ~solve() int[][]
        -explore() boolean[][]
        -sweep(wheel : int) int[]
        -occupied(counts : int[]) boolean[]
        -period(base : boolean[]) int
        -matches(a : boolean[], b : boolean[], shift : int) boolean
        -offset(wheelSet : boolean[], firstSet : boolean[]) int
        -align(seen : boolean[][], period : int) void
        -narrow(period : int) void
        -rotate(wheel : int, j : int) int
    }
    class MachineDecor {
        -builtWidth : int
        -parts : ArrayList~Rectangle~
        -lights : ArrayList~Circle~
        -knob : Circle
        ~show(bodyWidth : int, bodyHeight : int, won : boolean) void
        ~hide() void
        -build(width : int, height : int) void
        -buildLights(width : int) void
        -paintColors(won : boolean) void
    }
    SlotMachine ..> MachineDecor : crea
    MachineDecor --> Rectangle
    MachineDecor --> Circle
    SlotMachineContest ..> SlotMachine : usa (testing tool)
    SlotMachineContest ..> ContestSolver : crea
    ContestSolver --> SlotMachine : machine
    SlotMachine --> Wheel
    SlotMachine --> Rectangle
    Wheel --> Rectangle
    Wheel --> Circle
```

Las clases de pruebas (`SlotMachineContestTest`, `SlotMachineContestCTest`) dependen de `SlotMachine` y `SlotMachineContest`.

## 2. Diagramas de secuencia (crear en Astah dentro de cada método, nombre por omisión)

### `SlotMachine(n : int)`
```mermaid
sequenceDiagram
    participant U as Usuario
    participant M as SlotMachine
    U->>M: SlotMachine(n)
    M->>M: this()
    alt n < 1 o n > 50
        M->>M: fail(mensaje)
    else
        loop wheel = 1..n
            M->>M: addWheel(wheel)
            loop symbol = 0..n-1
                M->>M: addSymbol(wheel, PALETTE[symbol])
            end
        end
        M->>M: shuffle(n)
        loop mientras isWinning()
            M->>M: spin(wheel, random) por cada rueda
        end
    end
```

### `SlotMachineContest.solve(n : int)`
```mermaid
sequenceDiagram
    participant U as Usuario
    participant C as SlotMachineContest
    participant M as SlotMachine
    participant S as ContestSolver
    U->>C: solve(n)
    C->>M: new SlotMachine(n)
    C->>S: new ContestSolver(machine, n)
    C->>S: solve()
    S->>M: distinctSymbols()
    loop mientras distinct > 1
        S->>S: explore()
        loop cada rueda, cada posicion
            S->>M: spin(wheel, step)
            S->>M: distinctSymbols()
        end
        S->>S: period(seen[0])
        S->>S: align(seen, period)
        loop cada rueda
            S->>M: spin(wheel, steps)
            S->>M: distinctSymbols()
        end
        S->>S: narrow(period)
    end
    S-->>C: acciones {i, j}
    C-->>U: int[][]
```

### `SlotMachineContest.simulate(n : int)`
```mermaid
sequenceDiagram
    participant U as Usuario
    participant C as SlotMachineContest
    participant M as SlotMachine
    U->>C: simulate(n)
    alt no cabe en el lienzo
        C-->>U: mensaje en consola
    else
        C->>M: new SlotMachine(n)
        C->>C: solve(n, machine)   (invisible)
        C->>C: netRotation(actions, n)
        C->>M: spin(wheel, n - net)  (devuelve a la configuracion inicial)
        C->>M: makeVisible()
        loop cada rueda con giro neto
            C->>M: spin(wheel, net)  (paso a paso)
        end
    end
```

## 3. Cómo se resuelve el problema (resumen para sustentar)

Sea `a_i` el desplazamiento de la rueda `i`. Con las demás quietas, si la rueda `i` recorre sus `n` posiciones,
`distinctSymbols()` vale `k` cuando cae en un símbolo que ya tiene otra rueda y `k+1` en los demás.
**Un barrido de `n` giros revela el conjunto `A − a_i` de símbolos presentes, visto desde la rueda `i`.**

1. Se barren todas las ruedas (`n²` acciones; cada rueda vuelve a su sitio).
2. Comparando los conjuntos se obtiene `a_i − a_1` para cada rueda, salvo un periodo `p` si el conjunto `A` se repite al desplazarlo `p`.
3. Se alinean las ruedas con la primera módulo `p` (≤ `n−1` acciones). Si no hay periodo, ya ganó.
4. Si hay periodo, todas quedan en un subgrupo de tamaño `n/p`: se repite el proceso solo con las posiciones múltiplos de `p` (más barato, `n·(n/p)`).
5. Si están **todas** las posiciones del subgrupo ocupadas no hay información: se rompe la simetría girando una posición la rueda 1 y se vuelve a explorar; el conjunto ya no es periódico y la siguiente ronda gana.

Costo en el peor caso ≈ `3n²` (≈ 7500 para `n = 50`); el máximo medido fue **6300** (límite: 10000).

## 4. Decisiones de diseño y cambios a ciclos anteriores

| Decisión | Motivo |
|---|---|
| `distinctSymbols()` ahora cuenta los símbolos **visibles** (los de `configuration()`) | En la maratón el amigo informa los distintos que *ve*. Antes contaba todos los colores de la máquina y siempre daba `n`, inútil como *testing tool*. |
| `solve(n, machine)` además de `solve(n)` | Permite probar con configuraciones iniciales fijas (extensión; `solve(n)` sigue como pide el diseño). |
| `ContestSolver` (clase nueva, paquete) | Mantiene `SlotMachineContest` simple y cada método en menos de una pantalla. |
| `simulate` devuelve la máquina a su configuración inicial con el giro neto inverso | Solo usa `spin(wheel, steps)`, `makeVisible()` y `makeInvisible()`; no necesita métodos extra en `SlotMachine`. |
| `simulate` muestra el giro neto por rueda; `simulate(n, true)` muestra todas las acciones | Las ~`n²` acciones de exploración tardarían minutos con el movimiento paso a paso. |
| `canSimulate(n)`: de 3 a 8 ruedas | El lienzo mide 900 px y cada rueda usa 90 px. Es el "si es posible" del requisito 15. |
| `solve` nunca llama `makeVisible()` | Requisito de diseño 4. |
| `solve(n)` con n fuera de 3..50 devuelve `{}` sin ejecutar nada | Es el dominio de la maratón (3 ≤ n ≤ 50). Una máquina de 1 rueda ya gana. |
| Las acciones devueltas siempre tienen 1 ≤ j ≤ n−1 | Evita pasos negativos o cero; el giro es equivalente módulo n. |
| `getMachine()` devuelve la última máquina usada por `solve`/`simulate` | Lo necesitan varias pruebas compartidas del curso. |
| `MachineDecor` (clase nueva, paquete) | Decoración: luces, palanca y base, hechas solo con `Rectangle` y `Circle` de shapes. Reutiliza el ancho del cuerpo y cambia de color al ganar. |

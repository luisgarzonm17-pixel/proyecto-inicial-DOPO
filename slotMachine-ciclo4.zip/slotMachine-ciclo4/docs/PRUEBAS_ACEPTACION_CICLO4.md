# Pruebas de aceptación – Ciclo 4

Se ejecutan desde BlueJ: clic derecho sobre la clase `SlotMachineAcceptance` → método estático → *Get to bench* en el resultado.
Con la máquina en el banco de objetos se invocan los métodos pedidos.

## Aceptación 1 – Tipos de ruedas (req. 16, 17, 19)

| Paso | Acción | Resultado esperado |
|---|---|---|
| 1 | `SlotMachineAcceptance.wheelTypes()` | 4 ruedas con marcos de colores distintos: **gris** (normal), **azul claro** (lefty), **rojo oscuro** (rebel), **naranja** (reverse). |
| 2 | `lock(3)` (rebelde) | Aparece un mensaje «no se deja fijar»; no aparece la barra roja bajo la rueda; `ok()` = false. |
| 3 | `swap(3, 1)` y `delWheel(3)` | Mensajes de error; las ruedas no se mueven ni se eliminan. |
| 4 | `spin(1, 2)` y luego `spin(2)` | La rueda 1 pasa a `blue` y la zurda (rueda 2) **copia ese color**: las dos muestran `blue`. |
| 5 | `spin(4)` (inversa; muestra `green`) | La rueda gira **hacia atrás**: pasa a `red` (una normal pasaría a `blue`). |
| 6 | `lock(1)` y `swap(1, 2)` | Las ruedas normales **sí** se dejan: la 1 muestra la barra roja y las ruedas 1 y 2 cambian de lugar. Se suelta con `unlock(...)`. |

## Aceptación 2 – Tipos de símbolos (req. 16, 18)

| Paso | Acción | Resultado esperado |
|---|---|---|
| 1 | `SlotMachineAcceptance.symbolTypes()` | 3 ruedas; los símbolos se distinguen: **círculo** (normal), **triángulo** (efímero), **cuadrado** (tímido). |
| 2 | `spin()` varias veces | El círculo solo cambia de color; el **triángulo se encoge** cada vez que vuelve a aparecer, hasta quedar como un punto; el **cuadrado desaparece** (marco vacío) y reaparece cada segunda vez que se selecciona. |
| 3 | `configuration()` cuando el cuadrado está oculto | El arreglo tiene un color menos (el tímido invisible no aporta). |
| 4 | `isJackpot()` con el cuadrado oculto | `false`, aunque las otras ruedas muestren el mismo color. |
| 5 | `spin(2, 3)` visible | El triángulo cambia de símbolo **paso a paso**. |

# Pruebas de aceptación – Ciclo 3

Ambas se ejecutan desde BlueJ (clic derecho sobre la clase → método estático).

## Aceptación 1 – Simular la solución (requisitos 13 y 15)

**Objetivo:** mostrar que una máquina de n ruedas y n símbolos, aleatoria, se lleva al estado ganador.

| Paso | Acción | Resultado esperado |
|---|---|---|
| 1 | `SlotMachineContest.simulate(4)` | Se abre el lienzo con 4 ruedas; cada una muestra un color distinto o repetido, **no** todos iguales. |
| 2 | Observar la animación | Las ruedas giran de izquierda a derecha, **paso a paso** (un color por vez). |
| 3 | Al terminar | Las 4 ruedas muestran el mismo color, el cuerpo cambia de azul (`navy`) a **dorado** (`gold`), las luces superiores pasan a blanco/rojo y la perilla de la palanca a verde. |
| 3b | Antes de empezar | La máquina tiene **decoración**: luces amarillas/naranja arriba, palanca roja a la derecha y base gris con bandeja negra. |
| 4 | Repetir con `simulate(6)` | Mismo comportamiento con otra configuración inicial (es aleatoria). |
| 5 | `SlotMachineContest.simulate(50)` | No abre el lienzo; en la consola dice que solo se pueden simular de 3 a 8 ruedas. |
| 6 (opcional) | `SlotMachineContest.simulate(3, true)` | Muestra **todas** las acciones de la solución, no solo el giro neto. |

## Aceptación 2 – Resolver el problema de la maratón (requisito 14)

**Objetivo:** mostrar que `solve` gana en el límite de la maratón, sin ventanas.

| Paso | Acción | Resultado esperado |
|---|---|---|
| 1 | `int[][] r = SlotMachineContest.solve(50)` | No se abre ninguna ventana (la máquina es invisible). Termina en pocos segundos. |
| 2 | Inspeccionar `r` | Es una lista de pares `{i, j}` con `1 ≤ i ≤ 50`, `|j| ≤ 10⁹`; `r.length` es **≤ 10000** (típicamente ~2550 para n = 50; máx. medido 6300). |
| 3 | Ejecutar `SlotMachineContestTest` | Todas las pruebas en verde, incluida la que resuelve **todas** las configuraciones posibles para n = 3, 4 y 5. |
| 4 | Ejecutar `SlotMachineContestCTest` | En verde, incluida la *Sample Interaction 2* del enunciado de la maratón. |

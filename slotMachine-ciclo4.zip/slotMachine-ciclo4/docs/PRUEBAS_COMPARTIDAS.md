# Pruebas compartidas del curso (`SlotMachineContestCTest`)

Se implementaron **todas** las pruebas de los grupos para el ciclo 3, adaptadas a JUnit 4 y a la API real
(`solve` devuelve `int[][]`, `SlotMachine(n)` es aleatoria, `distinctSymbols()` cuenta los símbolos visibles).

Resultado de la ejecución completa (`SlotMachineC2Test` + `SlotMachineContestTest` + `SlotMachineContestCTest`):
**67 pasan, 0 fallan, 8 con `@Ignore`, 3 que abren el lienzo (se omiten si no hay pantalla).**

## Cambios hechos al proyecto para que las pruebas pasen
| Prueba(s) | Cambio |
|---|---|
| Davila-Orozco: `solve(2)` debe devolver vacío | `solve(n)` con n fuera de 3..50 devuelve `{}` (dominio de la maratón). |
| BustosL-GomezG: ningún paso negativo | Las acciones se devuelven con 1 ≤ j ≤ n−1. |
| Cardozo-Diaz, Bustos-Zorro, Quintero, CañonA-PaezP: `contest.getMachine()` | Se agregó `getMachine()`. |
| Cardozo-Diaz / Cuervo-Infante: `solve(1)` | Devuelve `{}` (una rueda ya gana). |
| Las que llaman `simulate` | Abren el lienzo; se ejecutan solo con pantalla (`Assume`). |

## Pruebas con `@Ignore` (no pueden pasar sin violar el enunciado o a otra prueba)
| Grupo | Prueba | Por qué no puede pasar |
|---|---|---|
| Cardozo-Diaz y Bustos-Zorro | `symbols().length == n` | Contradice a **Cortazar-Martinez** (`symbols().length == 25` para n = 5): cada una de las n ruedas tiene n símbolos. |
| Gomez-Carrero | `solve(5).length == 5` | No se puede ganar siempre con exactamente n acciones sin conocer la configuración; hay que explorar con `distinctSymbols()`. |
| Gomez-Carrero | `SlotMachine(3)` muestra todo `red` | El enunciado exige inicialización aleatoria y nunca ganadora. |
| Cortazar-Martinez | `solve(4).length <= 4` | Igual que arriba: explorar cuesta más de n acciones. |
| Forero-Salinas | `solve(n).length == n` para 6, 3 y 4 | Igual que arriba. |
| BustosL-GomezG | `solve(1)` tiene una acción con rueda 1 | Contradice a **Cardozo-Diaz, Cuervo-Infante y Davila-Orozco** (una rueda ya gana: 0 acciones). |
| Cuervo-Infante | toda acción gira exactamente 1 paso | Depende de una solución particular; el enunciado permite cualquier j. |

**Recomendación:** llevar esta tabla al profesor/wiki: son contradicciones entre las propuestas, no fallas del proyecto.

# Diseño – Ciclo 4 (Refactoring y extensión: tipos de ruedas y de símbolos)

Qué hay que **agregar al `.asta`** (Astah) y las decisiones de diseño del ciclo.

## 1. Diagrama de clases (agregar a `SlotMachine4.asta`)

```mermaid
classDiagram
    class SlotMachine {
        +addWheel(pos : int) void
        +addWheel(type : String, pos : int) void
        +addSymbol(pos : int, color : String) void
        +addSymbol(type : String, pos : int, color : String) void
        +wheelTypes() String[]
        +symbolSizes() int[]
        -canSwap(index : int) boolean
        -update() void
    }
    class Wheel {
        +getKind() String
        +canLock() boolean
        +canSwap() boolean
        +canDelete() boolean
        +rotate(steps : int) boolean
        #direction() int
        #getLeft() Wheel
        ~setLeft(w : Wheel) void
        +addSymbol(s : Symbol) boolean
        +place(color : String) boolean
        +getCurrentColor() String
        +getCurrentSymbol() String
        +getCurrentSize() int
        -symbols : ArrayList~Symbol~
        -advance(steps : int) void
    }
    class LeftyWheel { +rotate(steps : int) boolean }
    class RebelWheel { +canLock() boolean
 +canSwap() boolean
 +canDelete() boolean }
    class ReverseWheel { #direction() int }
    class Symbol {
        +getColor() String
        +getKind() String
        +isVisible() boolean
        +getSize() int
        +getShape() SymbolShape
        +select(times : int) void
    }
    class EphemeralSymbol { -size : int
 +select(times : int) void }
    class ShySymbol { -visible : boolean
 +select(times : int) void }
    class SymbolShape { <<enumeration>> CIRCLE
 SQUARE
 TRIANGLE }
    class SymbolView { ~render(s : Symbol, visible : boolean) void
 ~hide() void }
    class WheelFactory { ~create(type : String, order : int)$ Wheel }
    class SymbolFactory { ~create(type : String, color : String)$ Symbol }
    SlotMachine o-- Wheel
    SlotMachine ..> WheelFactory
    SlotMachine ..> SymbolFactory
    Wheel <|-- LeftyWheel
    Wheel <|-- RebelWheel
    Wheel <|-- ReverseWheel
    Wheel o-- Symbol
    Wheel --> SymbolView
    Wheel --> Rectangle
    Wheel --> "0..1" Wheel : left
    Symbol <|-- EphemeralSymbol
    Symbol <|-- ShySymbol
    Symbol --> SymbolShape
    SymbolView --> Circle
    SymbolView --> Rectangle
    SymbolView --> Triangle
    WheelFactory ..> Wheel
    SymbolFactory ..> Symbol
```

(`SlotMachineContest`, `ContestSolver` y `MachineDecor` no cambian.)

## 2. Diagramas de secuencia (crear en Astah dentro del método, nombre por omisión)

### `SlotMachine.addWheel(type, pos)`
```mermaid
sequenceDiagram
    participant M as SlotMachine
    participant F as WheelFactory
    participant W as Wheel (tipo)
    M->>F: create(type, pos)
    alt tipo no existe
        F-->>M: null
        M->>M: fail("el tipo no existe")
    else
        F->>W: new LeftyWheel / RebelWheel / ...
        F-->>M: wheel
        M->>M: wheels.add(pos - 1, wheel)
        M->>M: update()  (acomoda y asigna la vecina izquierda)
    end
```

### `SlotMachine.lock(wheel)` (polimorfismo)
```mermaid
sequenceDiagram
    participant M as SlotMachine
    participant W as Wheel
    M->>M: selectWheel(wheel)
    M->>W: canLock()
    alt RebelWheel devuelve false
        M->>M: fail("no se deja fijar")
    else
        M->>W: lock()
    end
```

### `SlotMachine.spin(wheel, steps)` con rueda zurda
```mermaid
sequenceDiagram
    participant M as SlotMachine
    participant L as LeftyWheel
    participant N as Wheel (vecina)
    participant S as Symbol
    M->>L: rotate(steps)
    L->>N: getCurrentColor()
    alt la zurda tiene ese color
        L->>L: place(color)
        L->>S: select(1)
    else
        L->>L: super.rotate(steps) -> advance(steps)
    end
    M->>M: update()
```

### `Wheel.rotate(steps)` con símbolos efímeros / tímidos
```mermaid
sequenceDiagram
    participant W as Wheel
    participant S as Symbol (Ephemeral o Shy)
    participant V as SymbolView
    W->>W: advance(steps)
    loop cada símbolo al que se llega
        W->>S: select(veces)
    end
    W->>V: render(simboloActual, visible)
    V->>S: getShape(), getSize(), getColor(), isVisible()
```

## 3. Decisiones de diseño

| Decisión | Motivo |
|---|---|
| `Wheel` es la clase base y los tipos la extienden (`LeftyWheel`, `RebelWheel`, `ReverseWheel`) | Req. 16: manejar tipos de ruedas. Cada tipo redefine solo lo que lo hace distinto. |
| `SlotMachine` **no usa `instanceof`**: pregunta `canLock()`, `canSwap()`, `canDelete()` | Polimorfismo: agregar un tipo no obliga a tocar `SlotMachine`. |
| `Symbol` (normal) es la clase base; `EphemeralSymbol` y `ShySymbol` redefinen `getSize`, `isVisible`, `getShape` y `select` | Req. 16 y 18. |
| `WheelFactory` y `SymbolFactory` con un registro (`Map`) | Un tipo nuevo = una clase + **una línea** en la fábrica (extensibilidad). |
| `addWheel(pos)` y `addSymbol(pos, color)` siguen existiendo y crean el tipo "normal" | Compatibilidad con los ciclos 1–3 (no se rompe ninguna prueba). |
| «Seleccionado» = la rueda cae sobre el símbolo en un paso de giro (`spin`, `spin(steps)`) o lo coloca (`placeSymbol`, `spin(setSymbols)`) y no era ya el mostrado | Un solo criterio para efímero y tímido. |
| `Wheel.advance` cuenta las selecciones sin recorrer los pasos | `spin(wheel, steps)` da el mismo resultado visible o invisible, y es inmediato aunque `steps` sea enorme. |
| Efímero: pierde 8 px por selección hasta quedar en 2 px (un punto) | Req. 18. |
| Tímido: alterna visible/invisible; invisible ⇒ la rueda muestra el marco vacío, no aporta color a `configuration()` ni cuenta para `isJackpot()` | Coherente con el ciclo 1: «configuration retorna los colores de los símbolos **visibles**». |
| Zurda: copia el **color actual** de la rueda de la izquierda (si lo tiene; si no, o si es la primera, gira normal) | «Copiar el estado» sin destruir los símbolos propios. En `spin()` las ruedas giran de izquierda a derecha, así que copia el estado ya girado. |
| `SlotMachine.update()` asigna a cada rueda su vecina izquierda | La zurda se entera de un `swap`, `addWheel` o `delWheel`. |
| Rebelde: `lock`, `swap` y `delWheel` fallan (`ok() == false`, mensaje si está visible); girar sí se puede | Req. 17. `swap` con una rebelde no cambia nada, aunque la otra sea normal. |
| Nuevo tipo (req. 19): `ReverseWheel`, gira al revés | Muestra la extensibilidad: 1 clase de ~30 líneas y 1 línea en la fábrica. |
| Distinción visual: marco gris (normal), azul claro (lefty), rojo oscuro (rebel), naranja (reverse); símbolo círculo (normal), triángulo (efímero), cuadrado (tímido) | Requisito de usabilidad del ciclo 4. |
| `SymbolView` (clase nueva) dibuja la figura con *shapes* | Mantiene `Wheel` simple; ninguna clase de *shapes* se modificó. |
| `wheelTypes()` y `symbolSizes()` en `SlotMachine` | Extensiones de consulta para poder probar sin abrir el lienzo. |
| `SlotMachine(n)`, `solve` y `simulate` solo usan elementos normales | No cambian; el ciclo 3 sigue intacto. |

# Retrospectiva del proyecto – Slot Machine (Ciclos 1, 2, 3 y 4)

> **Autores:** [COMPLETAR nombres]  
> Los campos marcados **[COMPLETAR]** dependen de datos del equipo (horas, reflexiones) que no están en el código.

---

## Ciclo 4 – Refactoring y extensión: tipos de ruedas y de símbolos

### 1. ¿Cuáles fueron los mini-ciclos definidos? Justifíquenlos.

| # | Mini-ciclo | Justificación |
|---|---|---|
| 4.1 | Refactoring sin cambiar el comportamiento: `Wheel` guarda objetos `Symbol` (antes `String`), con el símbolo normal | Es la base de todo; si las 70 pruebas anteriores siguen en verde, el cambio es seguro. |
| 4.2 | Jerarquía de ruedas: ganchos `canLock/canSwap/canDelete`, `rotate`, `direction`; `LeftyWheel`, `RebelWheel` (req. 16, 17) | Las ruedas dependen de 4.1 y permiten probar el polimorfismo con poco código. |
| 4.3 | Jerarquía de símbolos: `EphemeralSymbol`, `ShySymbol` y `SymbolView` (req. 16, 18) | Los símbolos cambian cómo se dibuja la rueda; se hace después de que las ruedas estén estables. |
| 4.4 | Fábricas `WheelFactory` / `SymbolFactory` y los métodos `addWheel(type, pos)` y `addSymbol(type, pos, color)` | Dejan a `SlotMachine` cerrado a la modificación: un tipo nuevo no la toca (extensibilidad). |
| 4.5 | Nuevo tipo propuesto por el equipo: `ReverseWheel` (req. 19) | Sirve de prueba de la extensibilidad: se agregó con una clase y una línea en la fábrica. |
| 4.6 | Usabilidad: marco de color por tipo de rueda y figura por tipo de símbolo | Requisito de usabilidad del ciclo. |
| 4.7 | Pruebas propias, compartidas, aceptación y documentación | Cierre y evidencia. |

### 2. ¿Cuál es el estado actual del proyecto en términos de mini-ciclos? ¿Por qué?

| Mini-ciclo | Estado | Evidencia |
|---|---|---|
| 4.1 | ✅ Terminado | Las 70 pruebas anteriores siguen en verde |
| 4.2 | ✅ Terminado | Pruebas `…Rebel…`, `…Lefty…`, `…Reverse…` en `SlotMachineC4Test` |
| 4.3 | ✅ Terminado | Pruebas `…Ephemeral…`, `…Shy…`; el giro por pasos y el giro de una vez dan el mismo resultado |
| 4.4 | ✅ Terminado | Pruebas de tipos desconocidos y de mayúsculas/minúsculas |
| 4.5 | ✅ Terminado | `ReverseWheel` (≈ 30 líneas) |
| 4.6 | ✅ Terminado (verificado con capturas del lienzo) | `SlotMachineAcceptance.wheelTypes()` y `symbolTypes()` |
| 4.7 | 🔶 Casi terminado | Pendiente: **actualizar Astah** (ver `DISENO_CICLO4.md`), completar `[COMPLETAR]` y publicar en Git |

Resultado de las pruebas: **106 pasan** (70 anteriores + 34 de `SlotMachineC4Test` + 2 de `SlotMachineCC4Test`), 8 con `@Ignore` heredadas del ciclo 3.

### 3. ¿Cuál fue el tiempo total invertido por cada uno? (Horas/Hombre)

**[COMPLETAR]** — Integrante 1: __ h · Integrante 2: __ h

### 4. ¿Cuál consideran fue el mayor logro? ¿Por qué?

Que agregar tipos nuevos no obligó a modificar `SlotMachine`: la rueda inversa (req. 19) se hizo con una clase nueva y una línea en `WheelFactory`. Eso confirma que el refactoring (4.1–4.4) logró la **extensibilidad** que se pide en todos los ciclos.

### 5. ¿Cuál consideran que fue el mayor problema técnico? ¿Qué hicieron para resolverlo?

- **Qué significa «seleccionado» para los símbolos efímero y tímido.** Si `spin(wheel, steps)` solo contaba el último símbolo, el resultado visible (paso a paso) y el invisible (de una vez) serían distintos. Se definió que cada paso en que la rueda cae en un símbolo lo selecciona, y `Wheel.advance` calcula cuántas veces se seleccionó cada uno **sin recorrer los pasos** (así `spin(1, 10⁹)` sigue siendo inmediato).
- **Dibujar tres figuras distintas** (círculo, triángulo, cuadrado) centradas aunque el símbolo cambie de tamaño: se creó `SymbolView`, que decide cuál figura de *shapes* se ve.
- **`lefty` y la rueda de la izquierda:** `SlotMachine.update()` ahora le informa a cada rueda cuál es su vecina de la izquierda (se actualiza tras `swap`, `addWheel` y `delWheel`).

### 6. ¿Qué hicieron bien como equipo? ¿Qué se comprometen a hacer para mejorar los resultados?

**[COMPLETAR]**

### 7. Considerando las prácticas XP incluidas en los laboratorios, ¿cuál fue la más útil? ¿Por qué?

**[COMPLETAR]** — Sugerencia con evidencia en este ciclo: *refactoring con pruebas*: las 70 pruebas anteriores permitieron cambiar `Wheel` por dentro (de `String` a `Symbol`) sin miedo.

### 8. ¿Qué referencias usaron? ¿Cuál fue la más útil?

- Gamma, E., Helm, R., Johnson, R. & Vlissides, J. (1994). *Design Patterns* (Factory Method, Template Method). Addison-Wesley.
- Oracle. *The Java Tutorials: Polymorphism; Enums*.
- Kölling, M. & Barnes, D. J. (2000). Proyecto *shapes* (material de BlueJ).
- **[COMPLETAR]** otras referencias del equipo.

---

## Ciclo 3 – Solución y simulación del problema de la maratón

### 1. ¿Cuáles fueron los mini-ciclos definidos? Justifíquenlos.

| # | Mini-ciclo | Justificación |
|---|---|---|
| 3.1 | `SlotMachine(n)`: n ruedas, n símbolos, orden común, giro aleatorio sin ganar (req. 13) | Es la *testing tool*; sin ella no se puede probar nada de lo demás. |
| 3.2 | Corregir `distinctSymbols()` para contar solo los símbolos visibles | Se descubrió al empezar 3.3: contaba todos los colores y siempre daba `n`. El "amigo" de la maratón cuenta lo que ve. |
| 3.3 | Diseño del algoritmo en papel y prueba exhaustiva de la idea | La maratón limita a 10 000 acciones; había que demostrar el costo antes de programar. |
| 3.4 | `ContestSolver` y `SlotMachineContest.solve` (req. 14) | Implementación del algoritmo usando solo `SlotMachine(n)`, `spin(wheel, steps)` y `distinctSymbols()`. |
| 3.5 | `simulate` y `canSimulate` (req. 15) | Depende de que `solve` ya funcione. |
| 3.6 | Decoración de la máquina (`MachineDecor`) | Mejora de usabilidad sin tocar la lógica; se hizo después de tener `solve` y `simulate` estables. |
| 3.7 | Integrar las pruebas compartidas del curso | Verificar el comportamiento esperado por todos los grupos y detectar contradicciones. |
| 3.8 | Pruebas propias, aceptación y documentación | Cierre y evidencia. |

### 2. ¿Cuál es el estado actual del proyecto en términos de mini-ciclos? ¿Por qué?

| Mini-ciclo | Estado | Evidencia |
|---|---|---|
| 3.1 | ✅ Terminado | Pruebas `ShouldCreate…` / `ShouldNotCreate…` |
| 3.2 | ✅ Terminado | `ShouldCountOnlyVisibleSymbolsAsDistinct`; las pruebas del ciclo 2 siguen en verde |
| 3.3 | ✅ Terminado | Ver `DISENO_CICLO3.md`, sección 3 |
| 3.4 | ✅ Terminado | Resuelve todas las configuraciones posibles para n ≤ 6 y miles de casos hasta n = 50; máximo medido 6300 acciones |
| 3.5 | ✅ Terminado (lógica verificada) | Verificado el regreso a la configuración inicial y la reproducción. **[COMPLETAR: confirmar la animación en pantalla en BlueJ]** |
| 3.6 | ✅ Terminado (verificado con una vista previa renderizada) | `docs`/imágenes de la decoración |
| 3.7 | ✅ Terminado | 67 pruebas verdes; 8 con `@Ignore` por contradecirse (ver `PRUEBAS_COMPARTIDAS.md`) |
| 3.8 | 🔶 Casi terminado | Pendiente: **actualizar el diagrama en Astah** (ver `DISENO_CICLO3.md`) y publicar en Git. |

### 3. ¿Cuál fue el tiempo total invertido por cada uno? (Horas/Hombre)

**[COMPLETAR]** — Integrante 1: __ h · Integrante 2: __ h

### 4. ¿Cuál consideran fue el mayor logro? ¿Por qué?

Resolver el problema con un algoritmo que **siempre** gana (no depende del azar) y cuyo costo está acotado: ≈ n² acciones en el caso típico y ≈ 3n² en el peor (6300 medidas de las 10 000 permitidas para n = 50). Se comprobó probando **todas** las máquinas posibles para n ≤ 6.

### 5. ¿Cuál consideran que fue el mayor problema técnico? ¿Qué hicieron para resolverlo?

Dos:
- **`distinctSymbols()` no servía** como testing tool (contaba todos los colores de la máquina). Se redefinió para contar los símbolos visibles.
- **Casos sin información:** cuando todos los símbolos están a la vista (p. ej. todas las ruedas distintas) o el conjunto se repite periódicamente, un barrido no distingue qué rueda es cuál. Se resolvió explorando por subgrupos y rompiendo la simetría con un giro de una posición.

### 6. ¿Qué hicieron bien como equipo? ¿Qué se comprometen a hacer para mejorar los resultados?

**[COMPLETAR]**

### 7. Considerando las prácticas XP incluidas en los laboratorios, ¿cuál fue la más útil? ¿Por qué?

**[COMPLETAR]** — Sugerencia con evidencia en este ciclo: *pruebas primero / refactoring*: las pruebas del ciclo 2 detectaron que el cambio en `distinctSymbols()` no rompía nada.

### 8. ¿Qué referencias usaron? ¿Cuál fue la más útil?

- ICPC Foundation. (2025). *Problem I: Slot Machine*. The 2025 ICPC World Finals, Baku.
- Kölling, M. & Barnes, D. J. (2000). Proyecto *shapes* (material de BlueJ).
- Oracle. *Java Platform SE API: `Math.floorMod`, `java.util.Random`*.
- **[COMPLETAR]** otras referencias del equipo.

---

## Ciclo 2 – Refactoring y extensión (swap, lock, unlock, spin con pasos y configuración)

**[COMPLETAR: pegar aquí la retrospectiva entregada en el ciclo 2, con los mini-ciclos y su estado.]**

## Ciclo 1 – Simulador básico

**[COMPLETAR: pegar aquí la retrospectiva entregada en el ciclo 1, con los mini-ciclos y su estado.]**

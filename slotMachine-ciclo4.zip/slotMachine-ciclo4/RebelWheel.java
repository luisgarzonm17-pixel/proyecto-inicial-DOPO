/**
 * Rueda rebelde: no se deja fijar, ni intercambiar, ni eliminar.
 * Se dibuja con el marco rojo oscuro.
 */
public class RebelWheel extends Wheel
{
    /**
     * Crea una rueda rebelde, invisible, sin simbolos y suelta.
     *
     * @param order posicion de la rueda en la maquina, empezando en 1
     */
    public RebelWheel(int order)
    {
        super(order, "maroon");
    }

    @Override
    public String getKind()
    {
        return "rebel";
    }

    @Override
    public boolean canLock()
    {
        return false;
    }

    @Override
    public boolean canSwap()
    {
        return false;
    }

    @Override
    public boolean canDelete()
    {
        return false;
    }
}

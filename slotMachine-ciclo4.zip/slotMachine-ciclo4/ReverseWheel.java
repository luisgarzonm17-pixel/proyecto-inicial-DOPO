/**
 * Rueda inversa (tipo nuevo propuesto por el equipo): gira al reves, es
 * decir, cada paso muestra el simbolo anterior en lugar del siguiente.
 * Se dibuja con el marco naranja.
 */
public class ReverseWheel extends Wheel
{
    /**
     * Crea una rueda inversa, invisible, sin simbolos y suelta.
     *
     * @param order posicion de la rueda en la maquina, empezando en 1
     */
    public ReverseWheel(int order)
    {
        super(order, "orange");
    }

    @Override
    public String getKind()
    {
        return "reverse";
    }

    @Override
    protected int direction()
    {
        return -1;
    }
}

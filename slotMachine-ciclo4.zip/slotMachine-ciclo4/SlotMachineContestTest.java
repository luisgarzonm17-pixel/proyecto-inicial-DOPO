import static org.junit.Assert.*;
import org.junit.Test;
import java.util.Arrays;
import java.util.HashSet;

/**
 * Pruebas de unidad del ciclo 3: SlotMachine(n), solve y simulate.
 *
 * Todas las pruebas se ejecutan con la maquina INVISIBLE (nunca se llama a
 * makeVisible), asi no aparecen ventanas ni mensajes.
 *
 * Cada prueba responde a una de dos preguntas:
 * "should"    = que deberia hacer
 * "shouldNot" = que no deberia hacer
 *
 * @author (nombres de los autores)
 * @version (fecha)
 */
public class SlotMachineContestTest
{
    private static final int MAX_ACTIONS = 10000;
    private static final int MAX_J = 1000000000;

    /**
     * Crea una maquina de n ruedas que muestra, en la rueda i, el simbolo
     * numero offsets[i] de la lista comun de simbolos.
     */
    private SlotMachine machineWith(int n, int[] offsets)
    {
        SlotMachine machine = new SlotMachine(n);
        String[] colors = Arrays.copyOf(machine.symbols(), n);
        String[] shown = new String[n];
        for(int i = 0; i < n; i++)
        {
            shown[i] = colors[offsets[i]];
        }
        machine.spin(shown);
        return machine;
    }

    /**
     * Resuelve la maquina y verifica que quede ganadora, que las acciones
     * sean validas y que no pasen del limite de la maraton.
     */
    private int[][] solveAndCheck(int n, int[] offsets)
    {
        SlotMachine machine = machineWith(n, offsets);
        int[][] actions = SlotMachineContest.solve(n, machine);
        assertTrue(machine.isJackpot());
        assertTrue(actions.length <= MAX_ACTIONS);
        for(int[] action : actions)
        {
            assertTrue(action[0] >= 1 && action[0] <= n);
            assertTrue(Math.abs(action[1]) <= MAX_J);
        }
        return actions;
    }

    // ---------------------------------------------------------- SlotMachine(n)

    @Test
    public void accordingGarzonVargasShouldCreateMachineWithNWheelsAndNSymbols()
    {
        SlotMachine machine = new SlotMachine(5);
        assertTrue(machine.ok());
        assertEquals(25, machine.symbols().length);
        assertEquals(5, machine.configuration().length);
    }

    @Test
    public void accordingGarzonVargasShouldCreateEveryWheelWithTheSameSymbolsInTheSameOrder()
    {
        SlotMachine machine = new SlotMachine(4);
        String[] all = machine.symbols();
        String[] first = Arrays.copyOfRange(all, 0, 4);
        assertEquals(4, new HashSet<String>(Arrays.asList(first)).size());
        for(int wheel = 1; wheel < 4; wheel++)
        {
            assertArrayEquals(first, Arrays.copyOfRange(all, wheel * 4, wheel * 4 + 4));
        }
    }

    @Test
    public void accordingGarzonVargasShouldCreateMachineWithMaximumSize()
    {
        SlotMachine machine = new SlotMachine(50);
        assertTrue(machine.ok());
        assertEquals(2500, machine.symbols().length);
        assertEquals(50, machine.configuration().length);
    }

    @Test
    public void accordingGarzonVargasShouldNotCreateMachineThatAlreadyWins()
    {
        for(int n = 2; n <= 10; n++)
        {
            for(int i = 0; i < 100; i++)
            {
                assertFalse(new SlotMachine(n).isJackpot());
            }
        }
    }

    @Test
    public void accordingGarzonVargasShouldNotCreateMachineWithMoreThan50Wheels()
    {
        SlotMachine machine = new SlotMachine(51);
        assertFalse(machine.ok());
        assertEquals(0, machine.symbols().length);
    }

    @Test
    public void accordingGarzonVargasShouldNotCreateMachineWithoutWheels()
    {
        assertFalse(new SlotMachine(0).ok());
        assertFalse(new SlotMachine(-3).ok());
    }

    // ---------------------------------------------------------- distinctSymbols

    @Test
    public void accordingGarzonVargasShouldCountOnlyVisibleSymbolsAsDistinct()
    {
        SlotMachine machine = machineWith(4, new int[]{0, 0, 1, 1});
        assertEquals(2, machine.distinctSymbols());
        machine.spin(new String[]{"red", "red", "red", "red"});
        assertEquals(1, machine.distinctSymbols());
    }

    // ---------------------------------------------------------- solve

    @Test
    public void accordingGarzonVargasShouldSolveRandomMachines()
    {
        for(int n = 3; n <= 50; n++)
        {
            SlotMachine machine = new SlotMachine(n);
            int[][] actions = SlotMachineContest.solve(n, machine);
            assertTrue(machine.isJackpot());
            assertTrue(actions.length > 0);
            assertTrue(actions.length <= MAX_ACTIONS);
        }
    }

    @Test
    public void accordingGarzonVargasShouldSolveWithoutParameterMachine()
    {
        int[][] actions = SlotMachineContest.solve(6);
        assertNotNull(actions);
        assertTrue(actions.length > 0);
        assertTrue(actions.length <= MAX_ACTIONS);
    }

    @Test
    public void accordingGarzonVargasShouldSolveEveryPossibleMachineUpToFiveWheels()
    {
        for(int n = 3; n <= 5; n++)
        {
            int[] offsets = new int[n];
            int total = (int) Math.pow(n, n);
            for(int code = 0; code < total; code++)
            {
                int rest = code;
                boolean allEqual = true;
                for(int i = 0; i < n; i++)
                {
                    offsets[i] = rest % n;
                    rest /= n;
                    allEqual = allEqual && offsets[i] == offsets[0];
                }
                if(!allEqual)
                {
                    solveAndCheck(n, offsets);
                }
            }
        }
    }

    @Test
    public void accordingGarzonVargasShouldSolveWhenAllSymbolsAreDifferent()
    {
        int[] offsets = new int[50];
        for(int i = 0; i < 50; i++)
        {
            offsets[i] = (i * 7) % 50;           // 7 y 50 son primos relativos
        }
        solveAndCheck(50, offsets);
    }

    @Test
    public void accordingGarzonVargasShouldSolveWhenWheelsFormTwoOppositeGroups()
    {
        solveAndCheck(6, new int[]{0, 3, 0, 3, 0, 3});
        solveAndCheck(8, new int[]{4, 0, 0, 4, 4, 4, 0, 4});
    }

    @Test
    public void accordingGarzonVargasShouldSolveWhenSymbolsRepeatPeriodically()
    {
        solveAndCheck(6, new int[]{0, 2, 4, 0, 2, 4});
        solveAndCheck(9, new int[]{0, 3, 6, 0, 3, 6, 0, 3, 6});
        solveAndCheck(50, periodic(50, 2));
        solveAndCheck(48, periodic(48, 6));
    }

    private int[] periodic(int n, int d)
    {
        int[] offsets = new int[n];
        for(int i = 0; i < n; i++)
        {
            offsets[i] = (i * d) % n;
        }
        return offsets;
    }

    @Test
    public void accordingGarzonVargasShouldSolveWhenOnlyOneWheelIsDifferent()
    {
        int[] offsets = new int[50];
        offsets[0] = 1;
        solveAndCheck(50, offsets);
        offsets = new int[50];
        offsets[49] = 25;
        solveAndCheck(50, offsets);
    }

    @Test
    public void accordingGarzonVargasShouldReturnActionsThatWinOnTheSameInitialMachine()
    {
        int[] offsets = {3, 1, 4, 1, 5, 2, 6};
        int[][] actions = solveAndCheck(7, offsets);
        SlotMachine copy = machineWith(7, offsets);
        for(int[] action : actions)
        {
            copy.spin(action[0], Math.floorMod(action[1], 7));
        }
        assertTrue(copy.isJackpot());
    }

    @Test
    public void accordingGarzonVargasShouldReturnOnlyPositiveStepsBelowN()
    {
        for(int n = 3; n <= 20; n++)
        {
            for(int[] action : SlotMachineContest.solve(n))
            {
                assertTrue(action[1] >= 1 && action[1] <= n - 1);
            }
        }
    }

    @Test
    public void accordingGarzonVargasShouldNotSolveOutsideTheContestRange()
    {
        assertEquals(0, SlotMachineContest.solve(2).length);
        assertEquals(0, SlotMachineContest.solve(1).length);
        assertEquals(0, SlotMachineContest.solve(51).length);
    }

    @Test
    public void accordingGarzonVargasShouldNotUseMoreActionsThanTheContestAllows()
    {
        for(int i = 0; i < 20; i++)
        {
            assertTrue(SlotMachineContest.solve(50).length <= MAX_ACTIONS);
        }
    }

    @Test
    public void accordingGarzonVargasShouldNotReturnActionsWhenMachineAlreadyWins()
    {
        SlotMachine machine = machineWith(4, new int[]{2, 2, 2, 2});
        assertEquals(0, SlotMachineContest.solve(4, machine).length);
        assertTrue(machine.isJackpot());
    }

    // ---------------------------------------------------------- simulate

    @Test
    public void accordingGarzonVargasShouldOnlySimulateMachinesThatFitTheCanvas()
    {
        assertTrue(SlotMachineContest.canSimulate(3));
        assertFalse(SlotMachineContest.canSimulate(2));
        assertTrue(SlotMachineContest.canSimulate(8));
        assertFalse(SlotMachineContest.canSimulate(9));
        assertFalse(SlotMachineContest.canSimulate(50));
        assertFalse(SlotMachineContest.canSimulate(1));
    }

    @Test
    public void accordingGarzonVargasShouldNotSimulateMachineThatDoesNotFit()
    {
        // No abre el lienzo ni lanza excepciones (la prueba corre sin ventanas).
        SlotMachineContest.simulate(50);
        SlotMachineContest.simulate(9, true);
    }
}

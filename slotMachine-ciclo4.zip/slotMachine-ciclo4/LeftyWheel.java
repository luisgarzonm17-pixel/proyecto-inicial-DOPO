/**
 * Rueda zurda: si tiene una rueda a su izquierda, al girar copia su estado,
 * es decir, queda mostrando el mismo color que la rueda de la izquierda.
 * Si esa rueda no tiene el color (o no hay rueda a la izquierda) gira como
 * una rueda normal. Se dibuja con el marco azul.
 */
public class LeftyWheel extends Wheel
{
    /**
     * Crea una rueda zurda, invisible, sin simbolos y suelta.
     *
     * @param order posicion de la rueda en la maquina, empezando en 1
     */
    public LeftyWheel(int order)
    {
        super(order, "lightblue");
    }

    @Override
    public String getKind()
    {
        return "lefty";
    }

    @Override
    public boolean rotate(int steps)
    {
        Wheel neighbor = getLeft();
        if(steps > 0 && neighbor != null && !isEmpty())
        {
            String copied = neighbor.getCurrentColor();
            if(copied != null && hasSymbol(copied))
            {
                place(copied);
                return true;
            }
        }
        return super.rotate(steps);
    }
}

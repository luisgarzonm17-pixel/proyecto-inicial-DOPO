import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * Pruebas de unidad del ciclo 4: tipos de ruedas (normal, lefty, rebel,
 * reverse) y tipos de simbolos (normal, ephemeral, shy).
 *
 * Todas las pruebas se ejecutan con la maquina INVISIBLE.
 *
 * "should"    = que deberia hacer
 * "shouldNot" = que no deberia hacer
 *
 * @author (nombres de los autores)
 * @version (fecha)
 */
public class SlotMachineC4Test
{
    private SlotMachine machine;

    @Before
    public void setUp()
    {
        machine = new SlotMachine();
    }

    @After
    public void tearDown()
    {
        machine.makeInvisible();
    }

    /** Agrega a la rueda los colores indicados como simbolos normales. */
    private void fill(int wheel, String... colors)
    {
        for(String color : colors)
        {
            machine.addSymbol(wheel, color);
        }
    }

    // ---------------------------------------------------------------- tipos

    @Test
    public void accordingGarzonVargasShouldCreateWheelsOfEachType()
    {
        machine.addWheel("normal", 1);
        machine.addWheel("lefty", 2);
        machine.addWheel("rebel", 3);
        machine.addWheel("reverse", 4);
        assertTrue(machine.ok());
        assertArrayEquals(new String[]{"normal", "lefty", "rebel", "reverse"},
                          machine.wheelTypes());
    }

    @Test
    public void accordingGarzonVargasShouldCreateNormalWheelWithTheOldMethod()
    {
        machine.addWheel(1);
        assertArrayEquals(new String[]{"normal"}, machine.wheelTypes());
    }

    @Test
    public void accordingGarzonVargasShouldNotCreateWheelOfUnknownType()
    {
        machine.addWheel("flying", 1);
        assertFalse(machine.ok());
        assertEquals(0, machine.wheelTypes().length);
    }

    @Test
    public void accordingGarzonVargasShouldIgnoreCaseInTypeNames()
    {
        machine.addWheel("REBEL", 1);
        machine.addSymbol("Shy", 1, "red");
        assertTrue(machine.ok());
        assertArrayEquals(new String[]{"rebel"}, machine.wheelTypes());
    }

    @Test
    public void accordingGarzonVargasShouldNotCreateSymbolOfUnknownType()
    {
        machine.addWheel(1);
        machine.addSymbol("ghost", 1, "red");
        assertFalse(machine.ok());
        assertEquals(0, machine.symbols().length);
    }

    @Test
    public void accordingGarzonVargasShouldNotAddSymbolWithInvalidColorWhateverItsType()
    {
        machine.addWheel(1);
        machine.addSymbol("ephemeral", 1, "notacolor");
        assertFalse(machine.ok());
        assertEquals(0, machine.symbols().length);
    }

    // ---------------------------------------------------------------- rebel

    @Test
    public void accordingGarzonVargasShouldNotLockRebelWheel()
    {
        machine.addWheel("rebel", 1);
        fill(1, "red", "green");
        machine.lock(1);
        assertFalse(machine.ok());
        machine.spin(1);
        assertTrue(machine.ok());
        assertArrayEquals(new String[]{"green"}, machine.configuration());
    }

    @Test
    public void accordingGarzonVargasShouldNotSwapRebelWheel()
    {
        machine.addWheel("rebel", 1);
        machine.addWheel("normal", 2);
        fill(1, "red");
        fill(2, "green");
        machine.swap(1, 2);
        assertFalse(machine.ok());
        assertArrayEquals(new String[]{"rebel", "normal"}, machine.wheelTypes());
        assertArrayEquals(new String[]{"red", "green"}, machine.configuration());
    }

    @Test
    public void accordingGarzonVargasShouldNotDeleteRebelWheel()
    {
        machine.addWheel("rebel", 1);
        machine.delWheel(1);
        assertFalse(machine.ok());
        assertEquals(1, machine.wheelTypes().length);
    }

    @Test
    public void accordingGarzonVargasShouldSpinRebelWheelLikeANormalOne()
    {
        machine.addWheel("rebel", 1);
        fill(1, "red", "green", "blue");
        machine.spin(1, 2);
        assertArrayEquals(new String[]{"blue"}, machine.configuration());
    }

    @Test
    public void accordingGarzonVargasShouldKeepDeletingAndSwappingNormalWheels()
    {
        machine.addWheel("rebel", 1);
        machine.addWheel("normal", 2);
        machine.addWheel("lefty", 3);
        machine.swap(2, 3);
        assertTrue(machine.ok());
        assertArrayEquals(new String[]{"rebel", "lefty", "normal"}, machine.wheelTypes());
        machine.delWheel(3);
        assertTrue(machine.ok());
        assertEquals(2, machine.wheelTypes().length);
    }

    @Test
    public void accordingGarzonVargasShouldNotSwapRebelWheelEvenIfTheOtherIsLocked()
    {
        machine.addWheel("normal", 1);
        machine.addWheel("rebel", 2);
        machine.lock(1);
        machine.swap(1, 2);
        assertFalse(machine.ok());
        assertArrayEquals(new String[]{"normal", "rebel"}, machine.wheelTypes());
    }

    // ---------------------------------------------------------------- lefty

    private void leftyMachine()
    {
        machine.addWheel("normal", 1);
        machine.addWheel("lefty", 2);
        fill(1, "red", "green", "blue");
        fill(2, "blue", "red", "green");
    }

    @Test
    public void accordingGarzonVargasShouldCopyTheLeftWheelWhenLeftyWheelSpins()
    {
        leftyMachine();
        assertArrayEquals(new String[]{"red", "blue"}, machine.configuration());
        machine.spin(2);
        assertArrayEquals(new String[]{"red", "red"}, machine.configuration());
        assertTrue(machine.isJackpot());
    }

    @Test
    public void accordingGarzonVargasShouldCopyTheNewStateWhenAllWheelsSpin()
    {
        leftyMachine();
        machine.spin();
        assertArrayEquals(new String[]{"green", "green"}, machine.configuration());
    }

    @Test
    public void accordingGarzonVargasShouldCopyWhenLeftyWheelSpinsSeveralSteps()
    {
        leftyMachine();
        machine.spin(1, 2);
        machine.spin(2, 5);
        assertArrayEquals(new String[]{"blue", "blue"}, machine.configuration());
    }

    @Test
    public void accordingGarzonVargasShouldSpinNormallyWhenLeftyWheelIsFirst()
    {
        machine.addWheel("lefty", 1);
        fill(1, "red", "green", "blue");
        machine.spin(1);
        assertArrayEquals(new String[]{"green"}, machine.configuration());
    }

    @Test
    public void accordingGarzonVargasShouldSpinNormallyWhenLeftWheelHasADifferentSymbol()
    {
        machine.addWheel("normal", 1);
        machine.addWheel("lefty", 2);
        fill(1, "red");
        fill(2, "green", "blue");
        machine.spin(2);
        assertArrayEquals(new String[]{"red", "blue"}, machine.configuration());
    }

    @Test
    public void accordingGarzonVargasShouldCopyTheNewLeftNeighborAfterSwapping()
    {
        leftyMachine();
        machine.addWheel("normal", 3);
        fill(3, "green", "blue", "red");
        machine.swap(1, 3);
        machine.spin(2);
        assertArrayEquals(new String[]{"green", "green", "red"}, machine.configuration());
    }

    @Test
    public void accordingGarzonVargasShouldNotCopyWhenLeftyWheelIsLocked()
    {
        leftyMachine();
        machine.lock(2);
        machine.spin(2);
        assertFalse(machine.ok());
        assertArrayEquals(new String[]{"red", "blue"}, machine.configuration());
    }

    // -------------------------------------------------------------- reverse

    @Test
    public void accordingGarzonVargasShouldSpinBackwardsInReverseWheel()
    {
        machine.addWheel("reverse", 1);
        fill(1, "red", "green", "blue");
        machine.spin(1);
        assertArrayEquals(new String[]{"blue"}, machine.configuration());
        machine.spin(1, 2);
        assertArrayEquals(new String[]{"red"}, machine.configuration());
    }

    // ------------------------------------------------------------ ephemeral

    @Test
    public void accordingGarzonVargasShouldShrinkEphemeralSymbolInEachSpin()
    {
        machine.addWheel(1);
        machine.addSymbol("ephemeral", 1, "red");
        assertEquals(50, machine.symbolSizes()[0]);
        machine.spin(1);
        int first = machine.symbolSizes()[0];
        machine.spin(1);
        int second = machine.symbolSizes()[0];
        assertTrue(first < 50);
        assertTrue(second < first);
    }

    @Test
    public void accordingGarzonVargasShouldLeaveEphemeralSymbolAsADot()
    {
        machine.addWheel(1);
        machine.addSymbol("ephemeral", 1, "red");
        for(int i = 0; i < 50; i++)
        {
            machine.spin(1);
        }
        assertEquals(2, machine.symbolSizes()[0]);
        machine.spin(1);
        assertEquals(2, machine.symbolSizes()[0]);
        assertArrayEquals(new String[]{"red"}, machine.configuration());
    }

    @Test
    public void accordingGarzonVargasShouldShrinkEphemeralSymbolOnlyWhenSelected()
    {
        machine.addWheel(1);
        machine.addSymbol("ephemeral", 1, "red");
        machine.addSymbol("normal", 1, "blue");
        machine.spin(1);                      // muestra blue: red no se toca
        machine.spin(1);                      // vuelve a red: se encoge una vez
        int once = machine.symbolSizes()[0];
        assertTrue(once < 50);
        machine.spin(1, 2);                   // blue y red de nuevo: otra vez
        assertTrue(machine.symbolSizes()[0] < once);
    }

    @Test
    public void accordingGarzonVargasShouldShrinkTheSameWhenSpinningStepByStepOrAtOnce()
    {
        SlotMachine other = new SlotMachine();
        machine.addWheel(1);
        other.addWheel(1);
        for(SlotMachine m : new SlotMachine[]{machine, other})
        {
            m.addSymbol("ephemeral", 1, "red");
            m.addSymbol("ephemeral", 1, "blue");
        }
        for(int i = 0; i < 5; i++)
        {
            machine.spin(1);
        }
        other.spin(1, 5);
        assertEquals(machine.symbolSizes()[0], other.symbolSizes()[0]);
        assertArrayEquals(machine.configuration(), other.configuration());
    }

    @Test
    public void accordingGarzonVargasShouldNotShrinkNormalSymbols()
    {
        machine.addWheel(1);
        fill(1, "red", "blue");
        machine.spin(1, 7);
        assertEquals(50, machine.symbolSizes()[0]);
    }

    // ------------------------------------------------------------------ shy

    @Test
    public void accordingGarzonVargasShouldHideShySymbolWhenSelected()
    {
        machine.addWheel(1);
        machine.addSymbol("shy", 1, "red");
        machine.addSymbol(1, "blue");
        assertArrayEquals(new String[]{"red"}, machine.configuration());
        machine.spin(1);
        machine.spin(1);                      // red vuelve a ser seleccionado
        assertEquals(0, machine.configuration().length);
        assertEquals(0, machine.symbolSizes()[0]);
    }

    @Test
    public void accordingGarzonVargasShouldShowShySymbolAgainWhenSelectedAgain()
    {
        machine.addWheel(1);
        machine.addSymbol("shy", 1, "red");
        machine.addSymbol(1, "blue");
        machine.spin(1, 2);                   // oculto
        machine.spin(1, 2);                   // visible de nuevo
        assertArrayEquals(new String[]{"red"}, machine.configuration());
    }

    @Test
    public void accordingGarzonVargasShouldAlternateShySymbolWhenPlaced()
    {
        machine.addWheel(1);
        machine.addSymbol(1, "blue");
        machine.addSymbol("shy", 1, "red");
        machine.placeSymbol(1, "red");
        assertEquals(0, machine.configuration().length);
        machine.placeSymbol(1, "blue");
        machine.placeSymbol(1, "red");
        assertArrayEquals(new String[]{"red"}, machine.configuration());
    }

    @Test
    public void accordingGarzonVargasShouldCountSelectionsOfFullLapsInShySymbols()
    {
        machine.addWheel(1);
        machine.addSymbol("shy", 1, "red");
        machine.addSymbol(1, "blue");
        machine.spin(1, 4);                   // red seleccionado 2 veces: igual
        assertArrayEquals(new String[]{"red"}, machine.configuration());
        machine.spin(1, 2);                   // red seleccionado 1 vez: oculto
        assertEquals(0, machine.configuration().length);
    }

    @Test
    public void accordingGarzonVargasShouldNotCountHiddenShySymbolForJackpot()
    {
        machine.addWheel(1);
        machine.addWheel(2);
        machine.addSymbol("shy", 1, "red");
        machine.addSymbol(1, "blue");
        fill(2, "red", "blue");
        assertTrue(machine.isJackpot());
        machine.spin(1, 2);                   // red de la rueda 1 se oculta
        machine.spin(2, 0);
        assertFalse(machine.isJackpot());
        assertEquals(1, machine.configuration().length);
    }

    @Test
    public void accordingGarzonVargasShouldKeepSymbolsOfEveryTypeInSymbols()
    {
        machine.addWheel(1);
        machine.addSymbol("shy", 1, "red");
        machine.addSymbol("ephemeral", 1, "green");
        machine.addSymbol(1, "blue");
        assertArrayEquals(new String[]{"red", "green", "blue"}, machine.symbols());
    }

    @Test
    public void accordingGarzonVargasShouldNotAddTwoSymbolsWithTheSameColorWhateverTheirType()
    {
        machine.addWheel(1);
        machine.addSymbol("shy", 1, "red");
        machine.addSymbol("ephemeral", 1, "red");
        assertFalse(machine.ok());
        assertEquals(1, machine.symbols().length);
    }

    // ---------------------------------------------------- tipos combinados

    @Test
    public void accordingGarzonVargasShouldCreateTheContestMachineOfNormalElements()
    {
        SlotMachine contest = new SlotMachine(5);
        for(String type : contest.wheelTypes())
        {
            assertEquals("normal", type);
        }
        for(int size : contest.symbolSizes())
        {
            assertEquals(50, size);
        }
    }

    @Test
    public void accordingGarzonVargasShouldLetLeftyCopyAShySymbolState()
    {
        machine.addWheel("normal", 1);
        machine.addWheel("lefty", 2);
        fill(1, "red", "blue");
        machine.addSymbol(2, "blue");
        machine.addSymbol("shy", 2, "red");
        machine.spin(2, 1);                   // copia red: red se selecciona -> oculto
        assertArrayEquals(new String[]{"red"}, machine.configuration());
        assertEquals(0, machine.symbolSizes()[1]);
    }
}

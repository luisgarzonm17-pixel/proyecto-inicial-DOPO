/**
 * Figuras con las que se puede dibujar un simbolo en una rueda.
 * Cada tipo de simbolo usa una figura distinta para que se distingan
 * a simple vista (requisito de usabilidad del ciclo 4).
 */
public enum SymbolShape
{
    CIRCLE, SQUARE, TRIANGLE
}

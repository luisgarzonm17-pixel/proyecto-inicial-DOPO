import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Random;
import javax.swing.JOptionPane;

/**
 * Simulador de una maquina tragamonedas.
 *
 * La maquina tiene ruedas y cada rueda tiene simbolos identificados por un
 * color CSS. Las posiciones se numeran desde 1; si una posicion esta fuera de
 * rango se ajusta al limite mas cercano. Cuando una accion no se puede
 * realizar, ok() devuelve false y, si la maquina es visible, se avisa con un
 * JOptionPane.
 *
 * Una rueda puede estar fija (lock). Una rueda fija no gira: ni con spin,
 * ni con placeSymbol, ni al dejar la maquina en una configuracion dada.
 *
 * Hay varios tipos de ruedas ("normal", "lefty", "rebel", "reverse") y de
 * simbolos ("normal", "ephemeral", "shy"); ver WheelFactory y SymbolFactory.
 * Una rueda rebelde no se deja fijar, intercambiar ni eliminar.
 *
 * Con SlotMachine(n) se crea la maquina del problema de la maraton: n ruedas
 * y n simbolos, con los simbolos en el mismo orden en todas las ruedas y cada
 * rueda mostrando un simbolo al azar (nunca una configuracion ganadora).
 */
public class SlotMachine
{
    private static final int BODY_HEIGHT = 150;
    private static final int BODY_MARGIN = 30;
    private static final String NORMAL_COLOR = "navy";
    private static final String JACKPOT_COLOR = "gold";
    /** Pausa (milisegundos) entre paso y paso cuando se gira con animacion. */
    private static final int STEP_DELAY = 300;

    /** Colores CSS usados como simbolos al crear una maquina de n ruedas. */
    private static final String[] PALETTE = {
        "red", "green", "blue", "yellow", "orange", "purple", "cyan",
        "magenta", "brown", "black", "pink", "gray", "lime", "navy", "teal",
        "maroon", "olive", "gold", "silver", "coral", "salmon", "violet",
        "indigo", "turquoise", "khaki", "orchid", "tan", "crimson", "skyblue",
        "chocolate", "plum", "tomato", "seagreen", "steelblue", "slateblue",
        "sienna", "springgreen", "darkorange", "deeppink", "dodgerblue",
        "firebrick", "forestgreen", "goldenrod", "hotpink", "limegreen",
        "mediumpurple", "royalblue", "darkcyan", "chartreuse", "lightsalmon"
    };
    private static final Random RANDOM = new Random();

    private Rectangle body;
    private MachineDecor decor;
    private ArrayList<Wheel> wheels;
    private boolean visible;
    private boolean ok;

    /**
     * Crea una maquina tragamonedas invisible y sin ruedas.
     */
    public SlotMachine()
    {
        body = new Rectangle();
        body.changeColor(NORMAL_COLOR);
        decor = new MachineDecor();
        wheels = new ArrayList<Wheel>();
        visible = false;
        ok = true;
        update();
    }

    /**
     * Crea una maquina invisible de n ruedas y n simbolos. Los simbolos son
     * los n primeros colores de una paleta fija y aparecen en el mismo orden
     * en todas las ruedas. Cada rueda queda mostrando un simbolo al azar, de
     * modo que la maquina nunca nace en estado ganador.
     *
     * Si n no esta entre 1 y el numero de colores disponibles (50), la
     * maquina queda sin ruedas y ok() devuelve false.
     *
     * @param n numero de ruedas y de simbolos por rueda
     */
    public SlotMachine(int n)
    {
        this();
        if(n < 1 || n > PALETTE.length)
        {
            fail("La maquina debe tener entre 1 y " + PALETTE.length + " ruedas.");
            return;
        }
        for(int wheel = 1; wheel <= n; wheel++)
        {
            addWheel(wheel);
            for(int symbol = 0; symbol < n; symbol++)
            {
                addSymbol(wheel, PALETTE[symbol]);
            }
        }
        shuffle(n);
        ok = true;
    }

    /**
     * Agrega una rueda vacia en la posicion indicada. Las ruedas que estaban
     * desde esa posicion se desplazan a la derecha.
     *
     * @param pos posicion de la nueva rueda, empezando en 1
     */
    public void addWheel(int pos)
    {
        addWheel("normal", pos);
    }

    /**
     * Agrega una rueda vacia de un tipo dado en la posicion indicada. Los
     * tipos son "normal", "lefty", "rebel" y "reverse". Si el tipo no existe,
     * no se agrega nada.
     *
     * @param type tipo de rueda (no distingue mayusculas)
     * @param pos posicion de la nueva rueda, empezando en 1
     */
    public void addWheel(String type, int pos)
    {
        ok = true;
        pos = clamp(pos, wheels.size() + 1);
        Wheel wheel = WheelFactory.create(type, pos);
        if(wheel == null)
        {
            fail("El tipo de rueda \"" + type + "\" no existe.");
            return;
        }
        wheels.add(pos - 1, wheel);
        update();
    }

    /**
     * Elimina la rueda de la posicion indicada.
     *
     * @param pos posicion de la rueda, empezando en 1
     */
    public void delWheel(int pos)
    {
        ok = true;
        if(wheels.isEmpty())
        {
            fail("La maquina no tiene ruedas.");
            return;
        }
        Wheel wheel = wheels.get(clamp(pos, wheels.size()) - 1);
        if(!wheel.canDelete())
        {
            fail("La rueda " + wheel.getKind() + " no se deja eliminar.");
            return;
        }
        wheels.remove(wheel);
        wheel.makeInvisible();
        update();
    }

    /**
     * Intercambia de lugar dos ruedas. Cada rueda conserva sus simbolos, el
     * simbolo que muestra y si esta fija o no. Si las dos posiciones son la
     * misma rueda no pasa nada. Si alguna es rebelde, no se intercambia nada.
     *
     * @param wheel1 posicion de la primera rueda, empezando en 1
     * @param wheel2 posicion de la segunda rueda, empezando en 1
     */
    public void swap(int wheel1, int wheel2)
    {
        ok = true;
        if(wheels.isEmpty())
        {
            fail("La maquina no tiene ruedas.");
            return;
        }
        int first = clamp(wheel1, wheels.size()) - 1;
        int second = clamp(wheel2, wheels.size()) - 1;
        if(first != second && !(canSwap(first) && canSwap(second)))
        {
            return;
        }
        Collections.swap(wheels, first, second);
        update();
    }

    /**
     * Fija una rueda: mientras este fija no puede girar.
     *
     * @param wheel posicion de la rueda, empezando en 1
     */
    public void lock(int wheel)
    {
        ok = true;
        Wheel selected = selectWheel(wheel);
        if(selected == null)
        {
            return;
        }
        if(!selected.canLock())
        {
            fail("La rueda " + selected.getKind() + " no se deja fijar.");
            return;
        }
        if(selected.isLocked())
        {
            fail("La rueda ya esta fija.");
            return;
        }
        selected.lock();
    }

    /**
     * Suelta una rueda fija para que pueda volver a girar.
     *
     * @param wheel posicion de la rueda, empezando en 1
     */
    public void unlock(int wheel)
    {
        ok = true;
        Wheel selected = selectWheel(wheel);
        if(selected == null)
        {
            return;
        }
        if(!selected.isLocked())
        {
            fail("La rueda no esta fija.");
            return;
        }
        selected.unlock();
    }

    /**
     * Agrega un simbolo al final de una rueda.
     *
     * @param pos posicion de la rueda, empezando en 1
     * @param color color CSS del simbolo
     */
    public void addSymbol(int pos, String color)
    {
        addSymbol("normal", pos, color);
    }

    /**
     * Agrega un simbolo de un tipo dado al final de una rueda. Los tipos son
     * "normal", "ephemeral" y "shy". Si el tipo no existe, no se agrega nada.
     *
     * @param type tipo de simbolo (no distingue mayusculas)
     * @param pos posicion de la rueda, empezando en 1
     * @param color color CSS del simbolo
     */
    public void addSymbol(String type, int pos, String color)
    {
        ok = true;
        Wheel wheel = selectWheel(pos);
        if(wheel == null)
        {
            return;
        }
        String normal = normalize(color);
        if(!SymbolFactory.exists(type))
        {
            fail("El tipo de simbolo \"" + type + "\" no existe.");
        }
        else if(normal == null)
        {
            fail("El color no es un color CSS valido.");
        }
        else if(!wheel.addSymbol(SymbolFactory.create(type, normal)))
        {
            fail("Ese simbolo ya existe en la rueda.");
        }
        update();
    }

    /**
     * Elimina un simbolo de todas las ruedas que lo tengan.
     *
     * @param symbol color del simbolo
     */
    public void delSymbol(String symbol)
    {
        ok = true;
        String color = normalize(symbol);
        boolean found = false;
        for(Wheel wheel : wheels)
        {
            found = wheel.removeSymbol(color) || found;
        }
        if(!found)
        {
            fail("Ese simbolo no existe en la maquina.");
        }
        update();
    }

    /**
     * Gira una rueda hasta que muestre el simbolo indicado. No funciona si
     * la rueda esta fija.
     *
     * @param wheel posicion de la rueda, empezando en 1
     * @param symbol color del simbolo que debe quedar visible
     */
    public void placeSymbol(int wheel, String symbol)
    {
        ok = true;
        Wheel selected = selectWheel(wheel);
        if(selected == null || isLockedWheel(selected))
        {
            return;
        }
        if(!selected.place(normalize(symbol)))
        {
            fail("La rueda no tiene ese simbolo.");
        }
        update();
    }

    /**
     * Gira una rueda una posicion. No funciona si la rueda esta fija.
     *
     * @param wheel posicion de la rueda, empezando en 1
     */
    public void spin(int wheel)
    {
        ok = true;
        Wheel selected = selectWheel(wheel);
        if(selected == null || isLockedWheel(selected))
        {
            return;
        }
        if(!selected.spin())
        {
            fail("La rueda no tiene simbolos.");
        }
        update();
    }

    /**
     * Gira una rueda un numero de pasos. Si la maquina esta visible, el
     * movimiento se muestra paso a paso; si esta invisible, se calcula el
     * resultado de una sola vez. No funciona si la rueda esta fija.
     *
     * @param wheel posicion de la rueda, empezando en 1
     * @param steps numero de pasos (no puede ser negativo)
     */
    public void spin(int wheel, int steps)
    {
        ok = true;
        Wheel selected = selectWheel(wheel);
        if(selected == null || isLockedWheel(selected))
        {
            return;
        }
        if(steps < 0)
        {
            fail("El numero de pasos no puede ser negativo.");
            return;
        }
        if(selected.isEmpty())
        {
            fail("La rueda no tiene simbolos.");
            return;
        }
        if(visible)
        {
            spinStepByStep(selected, steps);
        }
        else
        {
            selected.rotate(steps);
        }
        update();
    }

    /**
     * Deja la maquina en una configuracion dada: cada rueda gira hasta
     * mostrar el color que le corresponde. Se indica un color por cada rueda,
     * de izquierda a derecha. Si alguna rueda no puede quedar como se pide,
     * no se cambia ninguna.
     *
     * @param setSymbols colores que debe mostrar cada rueda
     */
    public void spin(String[] setSymbols)
    {
        ok = true;
        if(!canSet(setSymbols))
        {
            return;
        }
        for(int i = 0; i < wheels.size(); i++)
        {
            wheels.get(i).place(normalize(setSymbols[i]));
        }
        update();
    }

    /**
     * Gira todas las ruedas una posicion. Las ruedas sin simbolos y las
     * ruedas fijas no cambian.
     */
    public void spin()
    {
        ok = true;
        if(wheels.isEmpty())
        {
            fail("La maquina no tiene ruedas.");
            return;
        }
        for(Wheel wheel : wheels)
        {
            if(!wheel.isLocked())
            {
                wheel.spin();
            }
        }
        update();
    }

    /**
     * Consulta los colores de todos los simbolos de la maquina, rueda por
     * rueda, en el orden en que estan en cada una.
     *
     * @return colores de los simbolos
     */
    public String[] symbols()
    {
        ok = true;
        ArrayList<String> all = new ArrayList<String>();
        for(Wheel wheel : wheels)
        {
            for(String symbol : wheel.getSymbols())
            {
                all.add(symbol);
            }
        }
        return all.toArray(new String[0]);
    }

    /**
     * Cuenta los colores distintos que se ven en la maquina, es decir, los
     * distintos entre los simbolos visibles de todas las ruedas. Es lo que
     * el "amigo" le informa a quien gira las ruedas en la maraton.
     *
     * @return cantidad de simbolos distintos visibles
     */
    public int distinctSymbols()
    {
        ok = true;
        HashSet<String> distinct = new HashSet<String>();
        for(String symbol : configuration())
        {
            distinct.add(symbol);
        }
        return distinct.size();
    }

    /**
     * Consulta el simbolo visible de cada rueda, de izquierda a derecha.
     * Las ruedas sin simbolos no aportan ningun color.
     *
     * @return colores de los simbolos visibles
     */
    public String[] configuration()
    {
        ok = true;
        ArrayList<String> shown = new ArrayList<String>();
        for(Wheel wheel : wheels)
        {
            if(wheel.getCurrentSymbol() != null)
            {
                shown.add(wheel.getCurrentSymbol());
            }
        }
        return shown.toArray(new String[0]);
    }

    /**
     * Consulta el tipo de cada rueda, de izquierda a derecha.
     *
     * @return tipos de rueda ("normal", "lefty", "rebel", "reverse")
     */
    public String[] wheelTypes()
    {
        ok = true;
        String[] types = new String[wheels.size()];
        for(int i = 0; i < types.length; i++)
        {
            types[i] = wheels.get(i).getKind();
        }
        return types;
    }

    /**
     * Consulta el tamano del simbolo que muestra cada rueda, de izquierda a
     * derecha. Sirve para ver a los simbolos efimeros encogerse.
     *
     * @return tamanos en pixeles; 0 si la rueda no muestra ningun simbolo
     */
    public int[] symbolSizes()
    {
        ok = true;
        int[] sizes = new int[wheels.size()];
        for(int i = 0; i < sizes.length; i++)
        {
            sizes[i] = wheels.get(i).getCurrentSize();
        }
        return sizes;
    }

    /**
     * Indica si la configuracion es ganadora: todas las ruedas muestran el
     * mismo simbolo.
     *
     * @return true si la maquina esta en estado ganador
     */
    public boolean isJackpot()
    {
        ok = true;
        return isWinning();
    }

    /**
     * Hace visible la maquina y todas sus ruedas.
     */
    public void makeVisible()
    {
        ok = true;
        visible = true;
        paint();
    }

    /**
     * Hace invisible la maquina. Sigue funcionando en modo invisible.
     */
    public void makeInvisible()
    {
        ok = true;
        visible = false;
        body.makeInvisible();
        decor.hide();
        for(Wheel wheel : wheels)
        {
            wheel.makeInvisible();
        }
    }

    /**
     * Termina el simulador.
     */
    public void exit()
    {
        makeInvisible();
        System.exit(0);
    }

    /**
     * Indica si se pudo realizar la ultima operacion.
     *
     * @return true si la ultima operacion se realizo
     */
    public boolean ok()
    {
        return ok;
    }

    /**
     * Ajusta una posicion al rango [1, max].
     */
    private int clamp(int pos, int max)
    {
        return Math.max(1, Math.min(pos, max));
    }

    /**
     * Devuelve la rueda de la posicion (ajustada), o null si no hay ruedas.
     */
    private Wheel selectWheel(int pos)
    {
        if(wheels.isEmpty())
        {
            fail("La maquina no tiene ruedas.");
            return null;
        }
        return wheels.get(clamp(pos, wheels.size()) - 1);
    }

    /**
     * Devuelve el color en minusculas, o null si no es un color CSS.
     */
    private String normalize(String color)
    {
        if(color == null || !Canvas.isCssColor(color))
        {
            return null;
        }
        return color.trim().toLowerCase();
    }

    /**
     * Indica si la rueda esta fija y, en ese caso, registra el error.
     * Se usa antes de cualquier accion que haga girar una rueda.
     */
    private boolean isLockedWheel(Wheel wheel)
    {
        if(wheel.isLocked())
        {
            fail("La rueda esta fija.");
            return true;
        }
        return false;
    }

    /**
     * Verifica que la maquina pueda quedar en la configuracion pedida, sin
     * cambiar nada. Registra el error si no es posible.
     */
    private boolean canSet(String[] wanted)
    {
        if(wanted == null || wanted.length != wheels.size())
        {
            fail("Debe indicar un simbolo por cada rueda.");
            return false;
        }
        for(int i = 0; i < wheels.size(); i++)
        {
            String color = normalize(wanted[i]);
            Wheel wheel = wheels.get(i);
            if(!wheel.hasSymbol(color))
            {
                fail("La rueda " + (i + 1) + " no tiene el simbolo pedido.");
                return false;
            }
            if(wheel.isLocked() && !color.equals(wheel.getCurrentColor()))
            {
                fail("La rueda " + (i + 1) + " esta fija y no muestra ese simbolo.");
                return false;
            }
        }
        return true;
    }

    /**
     * Indica si la rueda se deja intercambiar y, si no, registra el error.
     */
    private boolean canSwap(int index)
    {
        Wheel wheel = wheels.get(index);
        if(!wheel.canSwap())
        {
            fail("La rueda " + wheel.getKind() + " no se deja intercambiar.");
            return false;
        }
        return true;
    }

    /**
     * Gira una rueda de a un paso, esperando entre paso y paso para que el
     * movimiento se vea.
     */
    private void spinStepByStep(Wheel wheel, int steps)
    {
        for(int i = 0; i < steps; i++)
        {
            wheel.spin();
            Canvas.getCanvas().wait(STEP_DELAY);
        }
    }

    /**
     * Registra que la operacion fallo y avisa solo si la maquina es visible.
     */
    private void fail(String message)
    {
        ok = false;
        if(visible)
        {
            JOptionPane.showMessageDialog(null, message, "Slot Machine",
                                          JOptionPane.WARNING_MESSAGE);
        }
    }

    /**
     * Deja cada rueda en un simbolo al azar. Se repite si por casualidad
     * todas quedan iguales, para que la maquina no empiece ganando.
     */
    private void shuffle(int n)
    {
        do
        {
            for(int wheel = 1; wheel <= n; wheel++)
            {
                spin(wheel, RANDOM.nextInt(n));
            }
        }
        while(n > 1 && isWinning());
    }

    /**
     * Calcula si todas las ruedas muestran el mismo simbolo.
     */
    private boolean isWinning()
    {
        if(wheels.isEmpty() || wheels.get(0).getCurrentSymbol() == null)
        {
            return false;
        }
        String first = wheels.get(0).getCurrentSymbol();
        for(Wheel wheel : wheels)
        {
            if(!first.equals(wheel.getCurrentSymbol()))
            {
                return false;
            }
        }
        return true;
    }

    /**
     * Reacomoda las ruedas, ajusta el cuerpo y cambia su color segun el
     * estado ganador.
     */
    private void update()
    {
        for(int i = 0; i < wheels.size(); i++)
        {
            wheels.get(i).moveTo(i + 1);
            wheels.get(i).setLeft(i == 0 ? null : wheels.get(i - 1));
        }
        body.changeSize(BODY_HEIGHT,
                        Math.max(wheels.size(), 1) * Wheel.STEP + BODY_MARGIN);
        body.changeColor(isWinning() ? JACKPOT_COLOR : NORMAL_COLOR);
        if(visible)
        {
            paint();
        }
    }

    /**
     * Dibuja el cuerpo, la decoracion y luego las ruedas, para que las
     * ruedas queden encima del cuerpo.
     */
    private void paint()
    {
        body.makeVisible();
        decor.show(Math.max(wheels.size(), 1) * Wheel.STEP + BODY_MARGIN,
                   BODY_HEIGHT, isWinning());
        for(Wheel wheel : wheels)
        {
            wheel.makeVisible();
        }
    }
}
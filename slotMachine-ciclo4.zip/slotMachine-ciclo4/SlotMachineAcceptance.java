/**
 * Escenas para las pruebas de aceptacion del ciclo 4. Se ejecutan desde
 * BlueJ (clic derecho sobre la clase, metodo estatico). Cada una arma una
 * maquina visible y la devuelve para poder seguir probando con ella en el
 * banco de objetos.
 */
public class SlotMachineAcceptance
{
    private static final String[] COLORS = {"red", "green", "blue"};

    /**
     * Escena 1: una rueda de cada tipo (normal, lefty, rebel, reverse), con
     * los mismos simbolos. Sirve para ver el marco de cada tipo y para
     * probar que la rueda rebelde no se deja fijar, intercambiar ni eliminar.
     *
     * @return la maquina visible
     */
    public static SlotMachine wheelTypes()
    {
        SlotMachine machine = new SlotMachine();
        String[] types = {"normal", "lefty", "rebel", "reverse"};
        for(int i = 0; i < types.length; i++)
        {
            machine.addWheel(types[i], i + 1);
            for(String color : COLORS)
            {
                machine.addSymbol(i + 1, color);
            }
        }
        machine.placeSymbol(2, "green");
        machine.placeSymbol(3, "blue");
        machine.placeSymbol(4, "green");
        machine.makeVisible();
        return machine;
    }

    /**
     * Escena 2: tres ruedas normales; la 1 tiene simbolos normales, la 2
     * efimeros y la 3 timidos. Sirve para ver la figura de cada tipo de
     * simbolo (circulo, triangulo, cuadrado) y como cambian al girar.
     *
     * @return la maquina visible
     */
    public static SlotMachine symbolTypes()
    {
        SlotMachine machine = new SlotMachine();
        String[] types = {"normal", "ephemeral", "shy"};
        for(int i = 0; i < types.length; i++)
        {
            machine.addWheel(i + 1);
            for(String color : COLORS)
            {
                machine.addSymbol(types[i], i + 1, color);
            }
        }
        machine.makeVisible();
        return machine;
    }
}

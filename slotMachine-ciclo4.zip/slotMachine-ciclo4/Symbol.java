/**
 * Simbolo normal de una rueda: se identifica por un color CSS, siempre se
 * ve, siempre tiene el mismo tamano y se dibuja como un circulo.
 *
 * Es la clase base de los demas tipos de simbolos (EphemeralSymbol,
 * ShySymbol, ...). Cada tipo redefine solo lo que lo hace diferente:
 * su figura, su tamano, su visibilidad y que le pasa al ser seleccionado.
 * Para crear un tipo nuevo basta con extender esta clase y registrarlo en
 * SymbolFactory.
 */
public class Symbol
{
    /** Tamano (en pixeles) de un simbolo que no ha cambiado. */
    public static final int FULL_SIZE = 50;

    private final String color;

    /**
     * Crea un simbolo.
     *
     * @param color color CSS (ya validado y en minusculas)
     */
    public Symbol(String color)
    {
        this.color = color;
    }

    /**
     * Devuelve el color que identifica al simbolo.
     *
     * @return color CSS del simbolo
     */
    public String getColor()
    {
        return color;
    }

    /**
     * Nombre del tipo de simbolo.
     *
     * @return "normal"
     */
    public String getKind()
    {
        return "normal";
    }

    /**
     * Indica si el simbolo se ve en la rueda cuando es el seleccionado.
     *
     * @return true si se ve
     */
    public boolean isVisible()
    {
        return true;
    }

    /**
     * Tamano con el que se dibuja el simbolo.
     *
     * @return tamano en pixeles
     */
    public int getSize()
    {
        return FULL_SIZE;
    }

    /**
     * Figura con la que se dibuja el simbolo.
     *
     * @return figura del simbolo
     */
    public SymbolShape getShape()
    {
        return SymbolShape.CIRCLE;
    }

    /**
     * Avisa que la rueda dejo este simbolo como el mostrado, una o varias
     * veces. El simbolo normal no cambia.
     *
     * @param times numero de veces que fue seleccionado (mayor que 0)
     */
    public void select(int times)
    {
    }
}

/**
 * Simbolo efimero: cada vez que la rueda lo selecciona se hace mas pequeno,
 * hasta quedar como un punto. Se dibuja como un triangulo.
 */
public class EphemeralSymbol extends Symbol
{
    /** Pixeles que pierde en cada seleccion. */
    private static final int DECREMENT = 8;
    /** Tamano final: un punto. */
    private static final int DOT = 2;

    private int size;

    /**
     * Crea un simbolo efimero con su tamano completo.
     *
     * @param color color CSS del simbolo
     */
    public EphemeralSymbol(String color)
    {
        super(color);
        size = FULL_SIZE;
    }

    @Override
    public String getKind()
    {
        return "ephemeral";
    }

    @Override
    public int getSize()
    {
        return size;
    }

    @Override
    public SymbolShape getShape()
    {
        return SymbolShape.TRIANGLE;
    }

    @Override
    public void select(int times)
    {
        long reduced = (long) size - (long) times * DECREMENT;
        size = (int) Math.max(DOT, reduced);
    }
}

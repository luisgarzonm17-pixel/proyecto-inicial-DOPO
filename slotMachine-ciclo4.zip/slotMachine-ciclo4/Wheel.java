import java.util.ArrayList;

/**
 * Representa una rueda normal de la maquina tragamonedas.
 *
 * Una rueda guarda una lista circular de simbolos (objetos Symbol) y muestra
 * uno solo a la vez. Ademas puede estar fija (lock): una rueda fija se
 * dibuja con una barra roja debajo y SlotMachine no permite girarla.
 *
 * Es la clase base de los demas tipos de rueda (LeftyWheel, RebelWheel,
 * ReverseWheel, ...). Los tipos se diferencian redefiniendo unos pocos
 * metodos: rotate (como gira), direction (hacia donde gira) y canLock,
 * canSwap, canDelete (que se deja hacer). Su marco tiene un color propio.
 *
 * La rueda solo conoce su propia apariencia: no sabe si la maquina es
 * ganadora ni valida las reglas de la maquina (eso lo hace SlotMachine).
 */
public class Wheel
{
    /** Distancia horizontal entre dos ruedas consecutivas. */
    public static final int STEP = 90;
    /** Coordenada x del marco de la primera rueda. */
    public static final int FIRST_X = 90;

    private static final int FRAME_WIDTH = 80;
    private static final int FRAME_HEIGHT = 80;
    private static final int FRAME_Y = 50;
    private static final String FRAME_COLOR = "lightgray";

    // Marca que indica que la rueda esta fija (barra roja bajo el marco).
    private static final int MARK_WIDTH = 40;
    private static final int MARK_HEIGHT = 8;
    private static final int MARK_Y = FRAME_Y + FRAME_HEIGHT + 10;
    private static final String MARK_COLOR = "red";

    // Posicion por omision del Rectangle de shapes al crearse.
    private static final int DEFAULT_FRAME_X = 70;
    private static final int DEFAULT_FRAME_Y = 15;

    private Rectangle frame;
    private SymbolView view;
    private Rectangle lockMark;
    private ArrayList<Symbol> symbols;
    private Wheel left;
    private int position;
    private int frameX;
    private boolean visible;
    private boolean locked;

    /**
     * Crea una rueda normal, invisible, sin simbolos y suelta.
     *
     * @param order posicion de la rueda en la maquina, empezando en 1
     */
    public Wheel(int order)
    {
        this(order, FRAME_COLOR);
    }

    /**
     * Crea una rueda invisible, sin simbolos y suelta, con el marco del
     * color indicado. Lo usan los tipos de rueda para distinguirse.
     *
     * @param order posicion de la rueda en la maquina, empezando en 1
     * @param frameColor color CSS del marco
     */
    protected Wheel(int order, String frameColor)
    {
        frame = new Rectangle();
        frame.changeSize(FRAME_HEIGHT, FRAME_WIDTH);
        frame.changeColor(frameColor);
        frame.moveVertical(FRAME_Y - DEFAULT_FRAME_Y);

        view = new SymbolView(DEFAULT_FRAME_X + (FRAME_WIDTH - Symbol.FULL_SIZE) / 2,
                              FRAME_Y + (FRAME_HEIGHT - Symbol.FULL_SIZE) / 2);

        lockMark = new Rectangle();
        lockMark.changeSize(MARK_HEIGHT, MARK_WIDTH);
        lockMark.changeColor(MARK_COLOR);
        lockMark.moveVertical(MARK_Y - DEFAULT_FRAME_Y);
        lockMark.moveHorizontal((FRAME_WIDTH - MARK_WIDTH) / 2);

        frameX = DEFAULT_FRAME_X;
        symbols = new ArrayList<Symbol>();
        position = 0;
        visible = false;
        locked = false;
        moveTo(order);
    }

    /**
     * Nombre del tipo de rueda.
     *
     * @return "normal"
     */
    public String getKind()
    {
        return "normal";
    }

    /**
     * Indica si la rueda se deja fijar.
     *
     * @return true si se puede fijar
     */
    public boolean canLock()
    {
        return true;
    }

    /**
     * Indica si la rueda se deja intercambiar con otra.
     *
     * @return true si se puede intercambiar
     */
    public boolean canSwap()
    {
        return true;
    }

    /**
     * Indica si la rueda se deja eliminar.
     *
     * @return true si se puede eliminar
     */
    public boolean canDelete()
    {
        return true;
    }

    /**
     * Guarda la rueda que quedo a su izquierda en la maquina. SlotMachine lo
     * llama cada vez que se reorganizan las ruedas.
     *
     * @param neighbor rueda de la izquierda, o null si es la primera
     */
    void setLeft(Wheel neighbor)
    {
        left = neighbor;
    }

    /**
     * Devuelve la rueda que esta a su izquierda.
     *
     * @return la rueda de la izquierda, o null si no hay
     */
    protected Wheel getLeft()
    {
        return left;
    }

    /**
     * Mueve la rueda a la posicion indicada de la maquina.
     *
     * @param order nueva posicion de la rueda, empezando en 1
     */
    public void moveTo(int order)
    {
        int delta = FIRST_X + (order - 1) * STEP - frameX;
        if(delta != 0)
        {
            frame.moveHorizontal(delta);
            lockMark.moveHorizontal(delta);
            view.moveBox(delta);
            frameX += delta;
            refresh();
        }
    }

    /**
     * Hace visible la rueda. Se dibuja el marco y luego el simbolo, para que
     * el simbolo quede encima. La marca de fija solo se ve si la rueda esta fija.
     */
    public void makeVisible()
    {
        visible = true;
        frame.makeVisible();
        refresh();
        refreshMark();
    }

    /**
     * Hace invisible la rueda.
     */
    public void makeInvisible()
    {
        visible = false;
        frame.makeInvisible();
        view.hide();
        lockMark.makeInvisible();
    }

    /**
     * Fija la rueda.
     */
    public void lock()
    {
        locked = true;
        refreshMark();
    }

    /**
     * Suelta la rueda.
     */
    public void unlock()
    {
        locked = false;
        refreshMark();
    }

    /**
     * Indica si la rueda esta fija.
     *
     * @return true si la rueda esta fija
     */
    public boolean isLocked()
    {
        return locked;
    }

    /**
     * Indica si la rueda no tiene simbolos.
     *
     * @return true si la rueda esta vacia
     */
    public boolean isEmpty()
    {
        return symbols.isEmpty();
    }

    /**
     * Indica si la rueda tiene un simbolo.
     *
     * @param color color CSS del simbolo
     * @return true si la rueda tiene ese simbolo
     */
    public boolean hasSymbol(String color)
    {
        return indexOf(color) >= 0;
    }

    /**
     * Agrega un simbolo al final de la rueda.
     *
     * @param symbol simbolo a agregar
     * @return false si la rueda ya tenia un simbolo de ese color
     */
    public boolean addSymbol(Symbol symbol)
    {
        if(hasSymbol(symbol.getColor()))
        {
            return false;
        }
        symbols.add(symbol);
        if(symbols.size() == 1)
        {
            position = 0;
            refresh();
        }
        return true;
    }

    /**
     * Elimina un simbolo de la rueda. Si el simbolo eliminado no era el que
     * se mostraba, la rueda sigue mostrando el mismo.
     *
     * @param color color del simbolo que se quiere eliminar
     * @return false si la rueda no tenia ese simbolo
     */
    public boolean removeSymbol(String color)
    {
        int index = indexOf(color);
        if(index < 0)
        {
            return false;
        }
        symbols.remove(index);
        if(index < position)
        {
            position--;
        }
        else if(position >= symbols.size())
        {
            position = 0;
        }
        refresh();
        return true;
    }

    /**
     * Gira la rueda hasta que se muestre el simbolo indicado. Si ya era el
     * mostrado, no se mueve y el simbolo no es seleccionado de nuevo.
     *
     * @param color color del simbolo que debe quedar visible
     * @return false si la rueda no tiene ese simbolo
     */
    public boolean place(String color)
    {
        int index = indexOf(color);
        if(index < 0)
        {
            return false;
        }
        if(index != position)
        {
            position = index;
            symbols.get(index).select(1);
        }
        refresh();
        return true;
    }

    /**
     * Gira la rueda una posicion.
     *
     * @return false si la rueda no tiene simbolos
     */
    public boolean spin()
    {
        return rotate(1);
    }

    /**
     * Gira la rueda un numero de pasos de una sola vez, sin mostrar los
     * pasos intermedios. Como la rueda es circular, solo importa el resto
     * de dividir los pasos entre la cantidad de simbolos. Cada simbolo en el
     * que cae la rueda (incluso en las vueltas completas) es seleccionado.
     *
     * @param steps numero de pasos
     * @return false si la rueda no tiene simbolos
     */
    public boolean rotate(int steps)
    {
        if(symbols.isEmpty())
        {
            return false;
        }
        advance(steps);
        refresh();
        return true;
    }

    /**
     * Sentido en que gira la rueda: 1 hacia el siguiente simbolo, -1 hacia
     * el anterior. Los tipos de rueda lo redefinen.
     *
     * @return 1 o -1
     */
    protected int direction()
    {
        return 1;
    }

    /**
     * Devuelve el color del simbolo actual, se vea o no. Es el estado de la
     * rueda.
     *
     * @return color actual, o null si la rueda no tiene simbolos
     */
    public String getCurrentColor()
    {
        if(symbols.isEmpty())
        {
            return null;
        }
        return symbols.get(position).getColor();
    }

    /**
     * Devuelve el simbolo que se esta viendo.
     *
     * @return color visible, o null si la rueda no tiene simbolos o el
     * simbolo actual esta invisible
     */
    public String getCurrentSymbol()
    {
        if(symbols.isEmpty() || !symbols.get(position).isVisible())
        {
            return null;
        }
        return symbols.get(position).getColor();
    }

    /**
     * Devuelve el tamano del simbolo que se esta viendo.
     *
     * @return tamano en pixeles, o 0 si no se ve ningun simbolo
     */
    public int getCurrentSize()
    {
        if(getCurrentSymbol() == null)
        {
            return 0;
        }
        return symbols.get(position).getSize();
    }

    /**
     * Devuelve los simbolos de la rueda en el orden en que estan en ella.
     *
     * @return colores de la rueda
     */
    public String[] getSymbols()
    {
        String[] colors = new String[symbols.size()];
        for(int i = 0; i < colors.length; i++)
        {
            colors[i] = symbols.get(i).getColor();
        }
        return colors;
    }

    /**
     * Busca un simbolo por su color.
     */
    private int indexOf(String color)
    {
        for(int i = 0; i < symbols.size(); i++)
        {
            if(symbols.get(i).getColor().equals(color))
            {
                return i;
            }
        }
        return -1;
    }

    /**
     * Avanza la posicion y selecciona cada simbolo las veces que la rueda
     * cae en el. El simbolo a d pasos del actual (d entre 1 y n) es
     * seleccionado una vez en el paso d, otra en d + n, y asi: se calcula
     * sin recorrer los pasos uno por uno.
     */
    private void advance(int steps)
    {
        long size = symbols.size();
        long dir = direction();
        for(int i = 0; i < size; i++)
        {
            long distance = Math.floorMod((i - position) * dir, size);
            distance = (distance == 0) ? size : distance;
            if(steps >= distance)
            {
                symbols.get(i).select((int) ((steps - distance) / size + 1));
            }
        }
        position = (int) Math.floorMod((long) position + dir * steps, size);
    }

    /**
     * Actualiza el dibujo para que refleje el simbolo actual.
     */
    private void refresh()
    {
        Symbol current = symbols.isEmpty() ? null : symbols.get(position);
        view.render(current, visible);
    }

    /**
     * Muestra la marca de fija solo si la rueda es visible y esta fija.
     */
    private void refreshMark()
    {
        if(visible && locked)
        {
            lockMark.makeVisible();
        }
        else
        {
            lockMark.makeInvisible();
        }
    }
}
